import bpy
import os

bl_info = {
    "name": "Stylized Asset Suite for Blender",
    "author": "crzyzha <https://www.instagram.com/crzyzhaa/>",
    "version": (1, 0),
    "blender": (4, 3, 0),
    "category": "Object",
    "description": "Stylized Asset Suite for Blender -- Addon",
}

import addon_utils
import random
from bpy.app.handlers import persistent
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import StringProperty, PointerProperty, FloatProperty
import time
import webbrowser

#add effect enum items
def operator_items(self, context):
    return [
        ('CT_LIGHTING', "----LIGHTING & SHADING----", "Lighting Category"),
        ('DIFFUSELIGHTING', "Stylized 3D Lighting (Main) (Dynamic) (EEVEE)", "Add Diffuse Lighting. bake if you would like to use it in cycles"),
        # ('SPECULAR', "Add Specular Reflection (Dynamic) (EEVEE)", "Add Specular Reflection. bake if you would like to use it in cycles"),
        # ('MOODLIGHT', "Add Colored Circular Light", "Add a Colored Circular Light"),
        # ('CIRCULARLIGHTING', "Add Circular Lighting", "Add Circular Lighting"),
        ('FAKELIGHT', "Add Stylized 3D Light (Per Object)", "Add Stylized 3D Lighting (Eevee+Cycles) (Bake Easily)"),
        ('AO', "Add Ambient Occlusion", "Add Ambient Occlusion"),
        ('CURVATURE', "Add Curvature", "Add a Curvature Effect"),
        ('CROSSHATCHING', "Cross Hatch Lighting (EEVEE)", "Add Cross Hatch Lighting"),
        # ('FAKESUNLIGHT', "Add Stylized 3D Sun Lighting (Experimental, Old)", "Add Stylized 3D Sun Lighting (Eevee+Cycles)"),
        # ('HAIRCURVES', "Add Anisotropic Hair Reflection (For Curves)", "Add Anisotropic Hair Reflection (For Curves)"),

        (' ', " ", " "),
        ('CT_SPLS', "STYLIZED POINT LIGHTS", "Stylized Point Lights category"),
        ('SPLRed', "Add Stylized Point Light #1", "Add Stylized Point Lights #1"),

        (' ', " ", " "),
        ('CT_TEXTURING', "----HAND DRAWN TEXTURING----", "Texturing Category"),
        ('DRAWPAINT', "Texture Paint / Draw (All Colors)", "Paint / Draw on Your Model (UV, Texture Painting)"),
        ('DRAWONECOLOR', "Draw/Paint with a Single Color", "Draw/Paint with a Single Color"),
        ('WORLDSTROKES', "Add Simple Transparency / Strokes", "Add Simple Transparency / Strokes"),
        # ('VERTEXPAINT', "Draw with Vertex Paint", "Paint/Draw on your Model (Vertex Paint)"),
        ('TRANSPARENTPAINT', "Add Watercolor/Charcoal Effect", "Add Watercolor/Charcoal Effect"),

        

        (' ', " ", " "),
        (' ', " ", " "),
        ('CT_OUTLINING', "----OUTLINING----", "Texturing Category"),

        ('SOLIDIFYOUTLINE', "Add Object Outline", "Add Object Outline"),
        # ('EDGEDETECT', "Add Edge Detect", "Add Edge Detect"),
        # ('COLOREDEDGES', "Add Colored Edges", "Add Colored Edges"),
        
        (' ', " ", " "),
        ('CT_GRADIENTS', "----TEXTURES----", "Texturing Category"),

        ('LOCALGRADIENT', "Local Gradient (Rectangular)", "Add a Local Gradient"),
        ('INSTANTWATERCOLOR', "Stylized Grunge", "Add Stylized Grunge Effect"),
        ('EASYDT', "Add Dynamic Texture (Simple)", "Add Dynamic Texture (Simple)"),
        # ('NOISETEXTURE', "Add Dynamic Texture", "Add Dynamic Texture"),
        ('OVERALLTEXTURE', "Add Texture Overlay", "Add Texture Overlay"),
        # ('BRUSHSTROKES', "Add Dynamic Brush Strokes", "Add Dynamic Brush Strokes"),
        # ('STYLIZEDFOAM', "Add Stylized Foam", "Add Stylized Foam"),
        # ('TRANSPARENTNOISE', "Add Dynamic Texture (Transparent)", "Add Dynamic Texture (Transparent)"),

        (' ', " ", " "),
        (' ', " ", " "),
        ('CT_ADJUSTING', "----ADJUSTMENTS----", "Texturing Category"),
        ('CONTRAST', "Add Contrast", "Add Contrast"),
        ('HSL', "Add HSL Effect", "Add Hue/Saturation/Value Shift"),
        ('OBJECTRANDOMIZE', "Add Object Randomization", "Add Object Randomization"),

        # (' ', " ", " "),
        # ('CT_OBJECTS', "----OBJECTS----", "Texturing Category"),
        # ('FOG', "Add a Fog Object", "Add a Fog Object"),
        # ('STEAM', "Add a Steam Object", "Add a Steam Object"),
        # ('GODRAYS', "Add Godray Effect", "Add a Godray Effect"),


        
        # ('DISPLACE', "Add a Displace Effect", "Add a Displace Effect"),
        
        
        (' ', " ", " "),
        ('CT_EXPORTING', "----BAKING/EXPORTING----", "Export category"),
        # ('BAKE', "Bake Your Shader", "Bake Shader"),
        # ('BAKEANIMATED', "Bake Your Shader (Animated)", "Bake Your Shader (Animated)"),
        ('BAKENORMALS', "Bake Normals", "Bake Normals"),
    ]

bpy.types.Scene.my_directory_enum = bpy.props.StringProperty(
    name="Directory",
    description="Choose a Directory:",
    default="",
    maxlen=1024,
    subtype='DIR_PATH'
)


bpy.types.Scene.processing_speed = bpy.props.FloatProperty(
    name = "set processing speed for animated bake",
    description = "",
    default = 8.0,
    min = 1.0
)


#enum for the add effect enum
bpy.types.Scene.my_operator_enum = bpy.props.EnumProperty(
    name="Operator",
    description="Choose an operator",
    items=operator_items,
)

#enum for bake resolution
bpy.types.Scene.user_input_number = bpy.props.IntProperty(
    name="User Input Number",
    description="Enter a numerical value",
    default=2048
)

#enum for user naming of bake textures
bpy.types.Scene.bake_name = bpy.props.StringProperty(
    name="User Input Bake Name",
    description="Enter a string value",
    default=""
)

def mask_items(self, context):
    return [
        ('GRADIENTSPHERE', "Edit Sphere Gradient Mask", "Edit Sphere Gradient Mask"),
        ('GRADIENTRECT', "Edit Rectangle Gradient Mask", "Edit Rectangle Gradient Mask"),
        ('NOISE', "Edit Noise Mask", "Edit Noise Mask"),
        ('WAVE', "Edit Wave Mask", "Edit Wave Mask"),
        ('WAVE2', "Edit Wave 2 Mask", "Edit Wave 2 Mask"),
        ("VORONOI", "Edit Voronoi Mask", "Edit Voronoi Mask"),
        ('FOAM', "Edit Foam Tiles Mask", "Edit Foam Tiles Mask"),
        ('TILES', "Tiles/Brick Mask", "Edit Tiles/Brick Mask"),
    ]

#Masks
bpy.types.Scene.my_mask_enum = bpy.props.EnumProperty(
    name="Mask",
    description="Choose Mask to Edit",
    items=mask_items,
)

bpy.types.Scene.light_animate_enum = bpy.props.BoolProperty(
    name="Bool1",
    description="Select whether or not you animated light",
    default=False
)

bpy.types.Scene.curvaturelevels = bpy.props.IntProperty(
    name="User Input Number",
    description="Enter a numerical value",
    default=2
)

bpy.types.Scene.hardsurface = bpy.props.BoolProperty(
    name="Bool1.2",
    description="Is your model harder surface",
    default=False
)

bpy.types.Scene.applied_sld = bpy.props.BoolProperty(
    name="Bool1.5",
    description="Select whether or not you want stylized light dynamic applied.",
    default=False
)

bpy.types.Scene.specular_animate_enum = bpy.props.BoolProperty(
    name="Bool2",
    description="Select whether or not you animated speculars",
    default=False
)

bpy.types.Scene.transparent_map = bpy.props.BoolProperty(
    name="Bool2",
    description="Select whether or not you want to export alpha maps",
    default=False
)

bpy.types.Scene.painterlyfilter = bpy.props.FloatProperty(
    name="PainterlyFilter",
    description="Select whether or not you want painterly filter on bounced light. You can also manually paint over the bounced light texture",
    default=0.0,
    min=0.0,
    max=1.0
)

#for the delete feature
def get_node_group_items():
    try:
        obj = bpy.context.object
    except:
        return []
    
    items = []
    obj = bpy.context.object

    if not obj:
        return items

    tempobj = None
    if obj.type == 'EMPTY' and obj.name.startswith("SB"):
        tempobj = obj.parent
        obj = tempobj
    elif obj.type == 'MESH' and obj.name.startswith("SB"):
        tempobj = obj.parent
        obj = tempobj

    if obj and obj.active_material and obj.active_material.use_nodes:
        node_tree = obj.active_material.node_tree
        for node in node_tree.nodes:
            if node.name == "Base Color":
                continue
            if node.type == 'GROUP':
                items.append((node.name, node.name, ""))

    return items

#for the view feature instead of delete
def get_node_group_items_view():
    try:
        obj = bpy.context.object
    except:
        return []
    
    items = []
    obj = bpy.context.object

    if not obj:
        return items
    
    items.append(('SHOWALL', "Show all Items", "Show all Effects"))

    tempobj = None
    if obj.type == 'EMPTY' and obj.name.startswith("SB"):
        tempobj = obj.parent
        obj = tempobj
    elif obj.type == 'MESH' and obj.name.startswith("SB"):
        tempobj = obj.parent
        obj = tempobj

    if obj and obj.active_material and obj.active_material.use_nodes:
        node_tree = obj.active_material.node_tree
        for node in node_tree.nodes:
            if node.type == 'GROUP':
                items.append((node.name, node.name, ""))

    return items

@persistent
def timer_function():
    try:
        obj = bpy.context.object
    except:
        kasou = False


    if bpy.data.materials.get("layerednodegroups") is None:
            current_directory = ''
            for mod in addon_utils.modules():
                if mod.bl_info['name'] == "Stylized Asset Suite for Blender":
                    filepath = mod.__file__
                    current_directory = (os.path.dirname(filepath))
                else:
                    pass
            
            shader_builder_file_path = os.path.join(current_directory, "nodegroups.blend")
            print("Shader Builder File Path:", shader_builder_file_path)

            bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/Material/", filename="layerednodegroups")
            bpy.data.materials.get("layerednodegroups").use_fake_user = True
            if bpy.data.materials.get("solidifyoutline") is None:
                bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/Material/", filename="solidifyoutline")
                bpy.data.materials.get("solidifyoutline").use_fake_user = True
            if bpy.data.materials.get("SBfullblank") is None:
                bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/Material/", filename="SBfullblank")
                bpy.data.materials.get("SBfullblank").use_fake_user = True

    # if bpy.data.node_groups.get("InstantWatercolor") is None:
    #     bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/NodeTree/", filename="InstantWatercolor")
    # if bpy.data.node_groups.get("AddCurvature") is None:
    #     bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/NodeTree/", filename="AddCurvature")
    # if bpy.data.node_groups.get("RedLightSAS") is None:
    #     bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/NodeTree/", filename="AddCurvature")

    if bpy.data.node_groups.get("SB Light Creation") is None:
        current_directory = ''
        for mod in addon_utils.modules():
            if mod.bl_info['name'] == "Stylized Asset Suite for Blender":
                filepath = mod.__file__
                current_directory = (os.path.dirname(filepath))
            else:
                pass
            
        shader_builder_file_path = os.path.join(current_directory, "nodegroups.blend")
        print("Shader Builder File Path:", shader_builder_file_path)

        bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/NodeTree/", filename="SB Light Creation")
        bpy.data.node_groups.get("SB Light Creation").use_fake_user = True
        bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/NodeTree/", filename="SunPower")
        bpy.data.node_groups.get("SunPower").use_fake_user = True


    items = []

    if not obj:
        return items
    
    items.append(('SHOWALL', "Show all Items", "Show all Effects"))

    tempobj = None
    if obj.type == 'EMPTY' and obj.name.startswith("SB"):
        tempobj = obj.parent
        obj = tempobj
    elif obj.type == 'MESH' and obj.name.startswith("SB"):
        tempobj = obj.parent
        obj = tempobj
    

    if obj and obj.active_material and obj.active_material.use_nodes:
        node_tree = obj.active_material.node_tree
        for node in node_tree.nodes:
            if node.type == 'GROUP':
                items.append((node.name, node.name, ""))

    newlist = []
    newlistview = []
    newlistswap1 = []
    newlistswap2 = []
    newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

    if obj and obj.active_material and obj.active_material.use_nodes:
        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
                newlistswap1.append((node.name, node.name, ""))
                newlistswap2.append((node.name, node.name, ""))
        #heres where we look for displace and add it to the enum
        for modifier in obj.modifiers:
            if modifier.name.startswith("SB") and not modifier.name.startswith("SB Geono") and not modifier.name.startswith("SB Sun"):
                newlist.append((modifier.name, modifier.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlistswap2
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlistswap1,
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

    return 1.0

bpy.app.timers.register(timer_function)

bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
    name="Node Groups",
    description = "List of Node Groups",
    items = get_node_group_items(),
)

bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
    name="Node Groups",
    description = "List of Node Groups",
    items = get_node_group_items(),
)

bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
    name="Node Groups",
    description = "List of Node Groups",
    items = get_node_group_items(),
)

# bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
#     name="Node Groups View",
#     description = "List of Node Groups for effect viewer",
#     items = get_node_group_items_view(),
# )

bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
    name="Group to Duplicate",
    description = "Select an effect to duplicate",
    items = get_node_group_items(),
)

class AppendBrushes(bpy.types.Operator):
    bl_idname = "shaderaddon.appendbrushes"
    bl_label = "append brush pack to scene"

    def execute(self, context):
        current_directory = ''
        for mod in addon_utils.modules():
            if mod.bl_info['name'] == "Stylized Asset Suite for Blender":
                filepath = mod.__file__
                current_directory = (os.path.dirname(filepath))
            else:
                pass

        brushes_file_path = os.path.join(current_directory, "watercolorpainttest.blend")

        bpy.ops.wm.append(filepath="watercolorpainttest.blend", directory=brushes_file_path+"/Brush/", filename="Chalk")
        bpy.ops.wm.append(filepath="watercolorpainttest.blend", directory=brushes_file_path+"/Brush/", filename="Caligraphy Ink 1")
        bpy.ops.wm.append(filepath="watercolorpainttest.blend", directory=brushes_file_path+"/Brush/", filename="Caligraphy Ink Rake")
        bpy.ops.wm.append(filepath="watercolorpainttest.blend", directory=brushes_file_path+"/Brush/", filename="Gouache (Textured)")
        bpy.ops.wm.append(filepath="watercolorpainttest.blend", directory=brushes_file_path+"/Brush/", filename="Pastel")
        bpy.ops.wm.append(filepath="watercolorpainttest.blend", directory=brushes_file_path+"/Brush/", filename="Dotty Watercolor")
        
        try:
            brushes = bpy.data.brushes
        
            # First unmark all brushes as asset
            for brush in brushes:
                if brush.asset_data is not None:
                    brush.asset_clear()
                
            # Then mark them all as asset again
            for brush in brushes:
                brush.asset_mark()
        except:
            print("NO")


        return {'FINISHED'}

#Set up Fog








class WorldSetup(bpy.types.Operator):
    bl_idname = "shaderaddon.worldsetup"
    bl_label = "set up background colors"

    def execute(self, context):
        bpy.context.scene.view_settings.view_transform = 'Standard'

        if bpy.data.worlds.get("layeredworld") is None:
            current_directory = ''
            for mod in addon_utils.modules():
                if mod.bl_info['name'] == "Stylized Asset Suite for Blender":
                    filepath = mod.__file__
                    current_directory = (os.path.dirname(filepath))
                else:
                    pass
            
            shader_builder_file_path = os.path.join(current_directory, "nodegroups.blend")
            print("Shader Builder File Path:", shader_builder_file_path)

            bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/World/", filename="layeredworld")

        bpy.context.scene.world = bpy.data.worlds.get("layeredworld")

        return {'FINISHED'}




#Set up shader button
class ShaderSetup(bpy.types.Operator):
    bl_idname = "shaderaddon.objectsetup"
    bl_label = "set up base shader"

    def execute(self, context):

        if bpy.data.brushes.get("Thick Dry Oil Paint") is None:
            bpy.context.scene.view_settings.view_transform = 'Standard'

        if bpy.data.materials.get("layerednodegroups") is None:
            current_directory = ''
            for mod in addon_utils.modules():
                if mod.bl_info['name'] == "Stylized Asset Suite for Blender":
                    filepath = mod.__file__
                    current_directory = (os.path.dirname(filepath))
                else:
                    pass
            
            shader_builder_file_path = os.path.join(current_directory, "nodegroups.blend")
            print("Shader Builder File Path:", shader_builder_file_path)

            bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/Material/", filename="layerednodegroups")
            bpy.data.materials.get("layerednodegroups").use_fake_user = True
            if bpy.data.materials.get("solidifyoutline") is None:
                bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/Material/", filename="solidifyoutline")
                bpy.data.materials.get("solidifyoutline").use_fake_user = True
            if bpy.data.materials.get("SBfullblank") is None:
                bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/Material/", filename="SBfullblank")
                bpy.data.materials.get("SBfullblank").use_fake_user = True

        if bpy.data.node_groups.get("SB Light Creation") is None:
            current_directory = ''
            for mod in addon_utils.modules():
                if mod.bl_info['name'] == "Stylized Asset Suite for Blender":
                    filepath = mod.__file__
                    current_directory = (os.path.dirname(filepath))
                else:
                    pass
            
            shader_builder_file_path = os.path.join(current_directory, "nodegroups.blend")
            print("Shader Builder File Path:", shader_builder_file_path)

            bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/NodeTree/", filename="SB Light Creation")
            bpy.data.node_groups.get("SB Light Creation").use_fake_user = True
            bpy.ops.wm.append(filepath="nodegroups.blend", directory=shader_builder_file_path+"/NodeTree/", filename="SunPower")
            bpy.data.node_groups.get("SunPower").use_fake_user = True

        if bpy.data.brushes.get("Chalk") is None:
            bpy.ops.shaderaddon.appendbrushes()

        new_material = bpy.data.materials.new(name="NewMaterial")
        new_material.use_nodes = True
        new_material.surface_render_method = 'BLENDED'

        new_material.node_tree.nodes.clear()

        basecolor_group = bpy.data.node_groups.get("basecolor")

        selected_obj = bpy.context.active_object

        if selected_obj.type != 'MESH' and selected_obj.type != 'EMPTY' and selected_obj.type != 'CURVE':
            return {'FINISHED'}

        tempobj = None
        if selected_obj.type == 'EMPTY' and selected_obj.name.startswith("SB"):
            tempobj = selected_obj.parent
            selected_obj = tempobj
        elif selected_obj.type == 'MESH' and selected_obj.name.startswith("SB"):
            tempobj = obj.parent
            selected_obj = tempobj

        if selected_obj.data.materials:
            selected_obj.data.materials[selected_obj.active_material_index] = new_material
        else:
            selected_obj.data.materials.append(new_material)
    
        nodes = new_material.node_tree.nodes
        links = new_material.node_tree.links

        basecolor_group_copy = basecolor_group.copy()

        node_group = nodes.new(type='ShaderNodeGroup')
        node_group.node_tree = basecolor_group_copy
        node_group.location = (0,0)
        node_group.name = "Base Color"

        material_output = nodes.new(type='ShaderNodeOutputMaterial')
        material_output.location = (200,0)
        links.new(node_group.outputs[0], material_output.inputs[0])

        scene = bpy.context.scene

        if scene.eevee.use_gtao == False:
            scene.eevee.use_gtao = True
            print("Ambient Occlusion enabled.")
        else:
            print("Ambient Occlusion was already enabled")

        try:
            if scene.eevee.use_bloom == False:
                scene.eevee.use_bloom = True
        except:
            print("AO")

        

        return {'FINISHED'}






class BakeCurvature(bpy.types.Operator):
    bl_idname = "shaderaddon.bakecurvature"
    bl_label = "bake curvature"

    def execute(self, context):
        try:
            #disable in renders all hidden objects
            for obj in bpy.context.scene.objects:
                # Check if the object is hidden in the viewport
                if obj.hide_get():
                    # If hidden, disable it in render
                    obj.hide_render = True
                else:
                    # If not hidden, enable it in render
                    obj.hide_render = False
        except:
            joe = "lasoutis"

        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        try:
            bpy.ops.object.select_all(action="DESELECT")
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
        except:
            joe = None
        
        prevobj = obj
        bpy.ops.object.duplicate()
        obj = bpy.context.active_object
        subsurf = obj.modifiers.new(name="Subdivision", type='SUBSURF')
        if bpy.context.scene.hardsurface == True:
            subsurf.subdivision_type = 'SIMPLE'
        subsurf.levels = bpy.context.scene.curvaturelevels
        if obj and obj.data.shape_keys:
            obj.shape_key_clear()
        bpy.ops.object.modifier_apply(modifier=subsurf.name)

        node_tree = obj.active_material.node_tree


        diffuse_light_group = None
        for node in node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("AddCurvature"):
                diffuse_light_group = node
                break
        
        diffuse_light_group.node_tree.nodes.get("Color Attribute").layer_name = 'Color'

        # dirty vertex calculate
        color_attr = obj.data.color_attributes.new(
            name='Color',
            type='FLOAT_COLOR',
            domain='POINT'
        )

        bpy.ops.object.mode_set(mode='VERTEX_PAINT')
        obj.data.color_attributes.active_color = obj.data.color_attributes['Color']
        bpy.ops.paint.vertex_color_dirt()

        bpy.ops.object.mode_set(mode='OBJECT')

        # re_enable = []
        try:
            for modifier in obj.modifiers:
                if modifier.type == 'SOLIDIFY' and modifier.name.startswith("SB Out"):
                    #modifier.show_viewport = False
                    modifier.show_render = False
                    # re_enable.append(modifier)
                elif modifier.type == 'SOLIDIFY':
                    modifier.show_render = False
                    # re_enable.append(modifier)
        except:
            joe = None

        original_render_engine = bpy.context.scene.render.engine
        if original_render_engine != 'CYCLES':
            bpy.context.scene.render.engine = 'CYCLES'

        bpy.context.scene.cycles.samples = 4

        # Get the active material
        material = obj.active_material
        if not material:
            raise ValueError("The active object does not have a material.")

        # Get the node tree of the material
        
            
        diffuse_bsdf_node = None
        for node in diffuse_light_group.node_tree.nodes:
            if node.name == 'Diffuse BSDF':
                diffuse_bsdf_node = node
                break
        
        material_output_node = None
        current_output_node = None
        for node in node_tree.nodes:
            if node.name == 'Material Output':
                material_output_node = node
                for link in node.inputs['Surface'].links:
                    current_output_node = link.from_node
                break
        
        node_tree.links.new(diffuse_light_group.outputs['BSDF'], material_output_node.inputs['Surface'])


        image_texture_node = node_tree.nodes.new('ShaderNodeTexImage')

        tempimage = bpy.data.images.get(f"{obj.name} - Curvature")
        if tempimage is not None:
            tempimage.user_clear()
            bpy.data.images.remove(tempimage)

        new_image = bpy.data.images.new(f"{obj.name} - Curvature", width=bpy.context.scene.user_input_number, height=bpy.context.scene.user_input_number)
        image_texture_node.image = new_image

        bpy.context.view_layer.objects.active = obj
        bpy.context.object.active_material.node_tree.nodes.active = image_texture_node

        bpy.context.scene.cycles.bake_type = 'DIFFUSE'
        bpy.context.scene.render.bake.use_pass_direct = False
        bpy.context.scene.render.bake.use_pass_indirect = False
        bpy.context.scene.render.bake.use_pass_color = True

        # if diffuse_light_group.inputs[31].default_value > 0.75:
        #     diffuse_light_group.node_tree.nodes["quickmaths"].inputs[1].default_value = 0.09

        # Bake the texture
        bpy.ops.object.bake(type='DIFFUSE')

        # if diffuse_light_group.inputs[31].default_value > 0.75:
        #     diffuse_light_group.node_tree.nodes["quickmaths"].inputs[1].default_value = 0.00

        image_texture_node_group = None
        if diffuse_light_group.node_tree.nodes.get('CurvatureHelper') is None:
            image_texture_node_group = diffuse_light_group.node_tree.nodes.new('ShaderNodeTexImage')
        else:
            image_texture_node_group = diffuse_light_group.node_tree.nodes.get('CurvatureHelper')
        
        image_texture_node_group.image = new_image
        

        # map_range_node = None
        # for node in diffuse_light_group.node_tree.nodes:
        #     if node.type == 'MAP_RANGE' and node.name == 'ImportantRange':
        #         map_range_node = node
        #         break


            
        # map_range_node.inputs[2].default_value = 1.25
        
        # Connect the output of the image texture node to the 'Value' input of the 'Map Range' node
        # diffuse_light_group.node_tree.links.new(image_texture_node_group.outputs['Color'], map_range_node.inputs['Value'])
        # diffuse_light_group.node_tree.links.new(image_texture_node_group.outputs['Color'], diffuse_light_group.node_tree.nodes.get("ExtraRange").inputs[0])

        #restore painterly
        # diffuse_light_group.inputs[31].default_value = prevpainterly

        # Restore the original node connected to the material output
        if current_output_node:
            node_tree.links.new(current_output_node.outputs[0], material_output_node.inputs['Surface'])

        if original_render_engine != 'CYCLES':
            bpy.context.scene.render.engine = original_render_engine
        
        # diffuse_light_group.node_tree.nodes.remove(diffuse_bsdf_node)

        node_tree.nodes.remove(image_texture_node)

        bpy.ops.object.delete()
        bpy.context.view_layer.objects.active = prevobj
        prevobj.select_set(True)

        try:
            bpy.ops.image.save_all_modified()
        except:
            joe = 'KAsoutis'

        return {'FINISHED'}


class BakeNormals(bpy.types.Operator):
    bl_idname = "shaderaddon.bakenormals"
    bl_label = "bake normal map"

    def execute(self, context):
        try:
            #disable in renders all hidden objects
            for obj in bpy.context.scene.objects:
                # Check if the object is hidden in the viewport
                if obj.hide_get():
                    # If hidden, disable it in render
                    obj.hide_render = True
                else:
                    # If not hidden, enable it in render
                    obj.hide_render = False
        except:
            joe = "lasoutis"
        
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        try:
            bpy.ops.object.select_all(action="DESELECT")
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
        except:
            joe = None


        #disable other materials
        for material in bpy.data.materials:
            if material.name == obj.active_material.name:
                continue
            if material.use_nodes:
                # Get the node tree of the material
                nodes = material.node_tree.nodes
                
                # Loop through all nodes in the material
                for node in nodes:
                    # Exclude output nodes
                    if not node.name == 'Material Output':
                        if node.mute == False:
                            node.mute = True
                        else:
                            node.mute = False

        original_render_engine = bpy.context.scene.render.engine
        if original_render_engine != 'CYCLES':
            bpy.context.scene.render.engine = 'CYCLES'

        bpy.context.scene.cycles.samples = 2

        # Get the active material
        material = obj.active_material
        if not material:
            raise ValueError("The active object does not have a material.")

        # Get the node tree of the material
        node_tree = material.node_tree

        diffuse_light_group = None
        for node in node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("DiffuseL"):
                diffuse_light_group = node
                break
        

        #link stuff up
        
        

        #what does this even do??
        # diffuse_bsdf_node = None
        # for node in diffuse_light_group.node_tree.nodes:
        #     if node.name == 'Visibility':
        #         diffuse_bsdf_node = node
        #         break
        
        material_output_node = None
        current_output_node = None
        for node in node_tree.nodes:
            if node.name == 'Material Output':
                material_output_node = node
                for link in node.inputs['Surface'].links:
                    current_output_node = link.from_node
                break
        
        nodes = node_tree.nodes
        normalshelpergroup = bpy.data.node_groups.get("normalshelper")
        #Add the "bsdf" node to the material
        joekasou = normalshelpergroup
        normals_node = nodes.new(type='ShaderNodeGroup')
        normals_node.node_tree = joekasou

        node_tree = material.node_tree
        links = node_tree.links

        incoming_link = None
        for link in links:
            if link.to_node == material_output_node:
                incoming_link = link
                break

        #link up normals node
        links.new(diffuse_light_group.outputs[2], normals_node.inputs[0])
        links.new(normals_node.outputs[0], material_output_node.inputs[0])


        image_texture_node = node_tree.nodes.new('ShaderNodeTexImage')

        tempimage = bpy.data.images.get(f"{bpy.context.scene.bake_name} - Normals")
        if tempimage is not None:
            tempimage.user_clear()
            bpy.data.images.remove(tempimage)

        new_image = bpy.data.images.new(f"{bpy.context.scene.bake_name} - Normals", width=bpy.context.scene.user_input_number, height=bpy.context.scene.user_input_number)
        image_texture_node.image = new_image
        image_texture_node.image.use_fake_user = True
        image_texture_node.image.colorspace_settings.name = 'Non-Color'

        bpy.context.view_layer.objects.active = obj
        bpy.context.object.active_material.node_tree.nodes.active = image_texture_node

        bpy.context.scene.cycles.bake_type = 'NORMAL'
        bpy.context.scene.render.bake.normal_space = 'OBJECT'

        # Bake the texture
        bpy.ops.object.bake(type='NORMAL')

        # image_texture_node_group = node_tree.nodes.new('ShaderNodeTexImage')
        # image_texture_node_group.image = new_image
        # image_texture_node_group.name = "BakeAlpha"
        obj.active_material.node_tree.nodes.remove(image_texture_node)


        # Restore the original node connected to the material output
        if current_output_node:
            node_tree.links.new(current_output_node.outputs[0], material_output_node.inputs['Surface'])

        material.node_tree.nodes.remove(normals_node)

        if original_render_engine != 'CYCLES':
            bpy.context.scene.render.engine = original_render_engine

        #re enable all other materials.
        for material in bpy.data.materials:
            if material.name == obj.active_material.name:
                continue
            if material.use_nodes:
                # Get the node tree of the material
                nodes = material.node_tree.nodes
                
                # Loop through all nodes in the material
                for node in nodes:
                    # Exclude output nodes
                    if not node.name == 'Material Output':
                        if node.mute == False:
                            node.mute = True
                        else:
                            node.mute = False

        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        if nodes.get('NormalsTextureHelper') is None:
            tex_node = nodes.new('ShaderNodeTexImage')
            tex_node.name = 'NormalsTextureHelper'
            tex_node.image = new_image
        else:
            tex_node = nodes.get('NormalsTextureHelper')
            tex_node.image = new_image

        try:
            bpy.ops.image.save_all_modified()
        except:
            joe = 'KAsoutis'

        return {'FINISHED'}



class BakeAlphaAnimated(bpy.types.Operator):
    bl_idname = "shaderaddon.bakealphaanimated"
    bl_label = "bake animated transparent maps"

    def execute(self, context):
        try:
            #disable in renders all hidden objects
            for obj in bpy.context.scene.objects:
                # Check if the object is hidden in the viewport
                if obj.hide_get():
                    # If hidden, disable it in render
                    obj.hide_render = True
                else:
                    # If not hidden, enable it in render
                    obj.hide_render = False
        except:
            joe = "lasoutis"
        
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        try:
            bpy.ops.object.select_all(action="DESELECT")
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
        except:
            joe = None

        setto = True
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and (node.node_tree.name.startswith("TransparentNoise") or node.node_tree.name.startswith("TransparentWorldStrokes")):
                setto = False

        if setto:
            return {'FINISHED'}

        #disable other materials
        for material in bpy.data.materials:
            if material.name == obj.active_material.name:
                continue
            if material.use_nodes:
                # Get the node tree of the material
                nodes = material.node_tree.nodes
                
                # Loop through all nodes in the material
                for node in nodes:
                    # Exclude output nodes
                    if not node.name == 'Material Output':
                        if node.mute == False:
                            node.mute = True
                        else:
                            node.mute = False

        original_render_engine = bpy.context.scene.render.engine
        if original_render_engine != 'CYCLES':
            bpy.context.scene.render.engine = 'CYCLES'

        bpy.context.scene.cycles.samples = 2

        # Get the active material
        material = obj.active_material
        if not material:
            raise ValueError("The active object does not have a material.")

        # Get the node tree of the material
        node_tree = material.node_tree

        diffuse_light_group = None
        for node in node_tree.nodes:
            if node.type == 'GROUP' and (node.node_tree.name.startswith("TransparentNoise") or node.node_tree.name.startswith("TransparentWorld")):
                diffuse_light_group = node
                break

        #math maximize trick----
        node1 = node_tree.nodes.get("Base Color")
        noiselist = []
        maxlist = []
        index = 0
        while node1:
            if (node1.type == 'GROUP' and node1.node_tree.name.startswith("TransparentNoise")) or (node1.type == 'GROUP' and node1.node_tree.name.startswith("TransparentNoise")):
                noiselist.append(node1)
                index += 1
                if index > 1:
                    math_node = node_tree.nodes.new(type='ShaderNodeMath')
                    math_node.operation = 'MAXIMUM'
                    math_node.name = f"Max #{index-1}"
                    maxlist.append(math_node)
                    #set 'diffuse light group' to be whatever the final mathnode is. 'diffuse light group' was normally what we were using as the thing that gets connected to the diffuse bsdf bake node
                    diffuse_light_group = math_node
                    if index == 2:
                        node_tree.links.new(math_node.inputs[0], node1.outputs['Result'])
                        node_tree.links.new(math_node.inputs[1], noiselist[0].outputs['Result'])
                    if index > 2:
                        node_tree.links.new(math_node.inputs[1], node1.outputs['Result'])
                        node_tree.links.new(maxlist[index-3].outputs[0], math_node.inputs[0])
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break
        

        #link stuff up
        
        

        #what does this even do??
        # diffuse_bsdf_node = None
        # for node in diffuse_light_group.node_tree.nodes:
        #     if node.name == 'Visibility':
        #         diffuse_bsdf_node = node
        #         break
        
        material_output_node = None
        current_output_node = None
        for node in node_tree.nodes:
            if node.name == 'Material Output':
                material_output_node = node
                for link in node.inputs['Surface'].links:
                    current_output_node = link.from_node
                break
        
        nodes = node_tree.nodes
        #Add the "bsdf" node to the material
        joekasou = nodes.new(type='ShaderNodeBsdfDiffuse')
        diffuse_node = joekasou

        node_tree = material.node_tree
        links = node_tree.links

        incoming_link = None
        for link in links:
            if link.to_node == material_output_node:
                incoming_link = link
                break


        #check if we have one or multiple transparent noise nodes. if we have multiple, its the max node
        if diffuse_light_group.type == 'GROUP':
            links.new(diffuse_light_group.outputs['Result'], diffuse_node.inputs[0])
        else:
            links.new(diffuse_light_group.outputs[0], diffuse_node.inputs[0])
        links.new(diffuse_node.outputs[0], material_output_node.inputs[0])


        image_texture_node = node_tree.nodes.new('ShaderNodeTexImage')

        tempimage = bpy.data.images.get(f"{bpy.context.scene.bake_name} - Alpha Frame #{bpy.context.scene.frame_current}")
        if tempimage is not None:
            tempimage.user_clear()
            bpy.data.images.remove(tempimage)

        new_image = bpy.data.images.new(f"{bpy.context.scene.bake_name} - Alpha Frame #{bpy.context.scene.frame_current}", width=bpy.context.scene.user_input_number, height=bpy.context.scene.user_input_number)
        image_texture_node.image = new_image
        image_texture_node.image.use_fake_user = True

        bpy.context.view_layer.objects.active = obj
        bpy.context.object.active_material.node_tree.nodes.active = image_texture_node

        bpy.context.scene.cycles.bake_type = 'DIFFUSE'
        bpy.context.scene.render.bake.use_pass_direct = False
        bpy.context.scene.render.bake.use_pass_indirect = False
        bpy.context.scene.render.bake.use_pass_color = True

        # Bake the texture
        bpy.ops.object.bake(type='DIFFUSE')

        # image_texture_node_group = node_tree.nodes.new('ShaderNodeTexImage')
        # image_texture_node_group.image = new_image
        # image_texture_node_group.name = "BakeAlpha"
        obj.active_material.node_tree.nodes.remove(image_texture_node)


        # Restore the original node connected to the material output
        if current_output_node:
            node_tree.links.new(current_output_node.outputs[0], material_output_node.inputs['Surface'])

        material.node_tree.nodes.remove(diffuse_node)
        for node in material.node_tree.nodes:
            if node.name.startswith("Max #"):
                material.node_tree.nodes.remove(node)

        if original_render_engine != 'CYCLES':
            bpy.context.scene.render.engine = original_render_engine

        #re enable all other materials.
        for material in bpy.data.materials:
            if material.name == obj.active_material.name:
                continue
            if material.use_nodes:
                # Get the node tree of the material
                nodes = material.node_tree.nodes
                
                # Loop through all nodes in the material
                for node in nodes:
                    # Exclude output nodes
                    if not node.name == 'Material Output':
                        if node.mute == False:
                            node.mute = True
                        else:
                            node.mute = False

        try:
            bpy.ops.image.save_all_modified()
        except:
            joe = 'KAsoutis'

        return {'FINISHED'}


#BakingEEVEE test



#Remove material
class DeleteMaterial(bpy.types.Operator):
    bl_idname = "shaderaddon.deletematerial"
    bl_label = "remove / delete shader"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        if not obj.active_material:
            return {'FINISHED'}

        material = obj.active_material
        nodes = material.node_tree.nodes

        #handle empties and delete them for Rectangular Gradients
        for node in nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("LocalGradient"):
                delobj = node.node_tree.nodes["ZhaTexture Coordinate"].object
                if delobj is None:
                    continue

                delobj.hide_viewport = False
                delobj.hide_set(False)

                bpy.ops.object.select_all(action="DESELECT")
                try:
                    delobj.select_set(True)
                except:
                    continue
                bpy.context.view_layer.objects.active = delobj
                try:
                    bpy.context.view_layer.objects.active = delobj
                except:
                    break
                if bpy.context.active_object.name == delobj.name:
                    bpy.ops.object.delete()
            elif node.type == 'GROUP' and node.node_tree.name.startswith("ColoredCircular"):
                delobj = node.node_tree.nodes["ZhaTexture Coordinate"].object
                if delobj is None:
                    continue

                delobj.hide_viewport = False
                delobj.hide_set(False)

                bpy.ops.object.select_all(action="DESELECT")
                try:
                    delobj.select_set(True)
                except:
                    continue
                bpy.context.view_layer.objects.active = delobj
                try:
                    bpy.context.view_layer.objects.active = delobj
                except:
                    break
                if bpy.context.active_object.name == delobj.name:
                    bpy.ops.object.delete()
            elif node.type == 'GROUP' and node.node_tree.name.startswith("NoiseTexture"):
                delobj = node.node_tree.nodes["ZhaTexture Coordinate"].object
                if delobj is None:
                    continue

                delobj.hide_viewport = False
                delobj.hide_set(False)

                bpy.ops.object.select_all(action="DESELECT")
                try:
                    delobj.select_set(True)
                except:
                    continue
                bpy.context.view_layer.objects.active = delobj
                try:
                    bpy.context.view_layer.objects.active = delobj
                except:
                    break
                if bpy.context.active_object.name == delobj.name:
                    bpy.ops.object.delete()
            elif node.type == 'GROUP' and node.node_tree.name.startswith("TransparentNoiseTexture"):
                delobj = node.node_tree.nodes["ZhaTexture Coordinate"].object
                if delobj is None:
                    continue

                delobj.hide_viewport = False
                delobj.hide_set(False)

                bpy.ops.object.select_all(action="DESELECT")
                try:
                    delobj.select_set(True)
                except:
                    continue
                bpy.context.view_layer.objects.active = delobj
                try:
                    bpy.context.view_layer.objects.active = delobj
                except:
                    break
                if bpy.context.active_object.name == delobj.name:
                    bpy.ops.object.delete()


        #handle empties and delete them for Circular Lighting
        for node in nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("CircularLight"):
                delobj = node.node_tree.nodes["ZhaTexture Coordinate"].object
                if delobj is None:
                    continue

                delobj.hide_viewport = False
                delobj.hide_set(False)

                bpy.ops.object.select_all(action="DESELECT")
                try:
                    delobj.select_set(True)
                except:
                    continue
                bpy.context.view_layer.objects.active = delobj
                try:
                    bpy.context.view_layer.objects.active = delobj
                except:
                    break
                if bpy.context.active_object.name == delobj.name:
                    bpy.ops.object.delete()

        #handle fakelight
        for modifier in obj.modifiers:
            if modifier.type == 'NODES' and modifier.name.startswith("SB Geono"):
                delobj = modifier.node_group.nodes["Object Info"].inputs[0].default_value
                if delobj is None:
                    continue

                #check if any other objects are using this fakelight sphere
                timetobreak = False
                for objeto in bpy.data.objects:
                    if objeto == obj:
                        continue
                    if objeto.active_material and objeto.active_material == obj.active_material:
                        continue
                    if objeto.modifiers:
                        for mod in objeto.modifiers:
                            if mod.type == 'NODES' and mod.name.startswith("SB Geono"):
                                if mod.node_group.nodes["Object Info"].inputs[0].default_value == delobj:
                                    timetobreak = True

                if timetobreak:
                    continue

                delobj.hide_viewport = False
                delobj.hide_set(False)

                bpy.ops.object.select_all(action="DESELECT")
                try:
                    delobj.select_set(True)
                except:
                    continue
                bpy.context.view_layer.objects.active = delobj
                try:
                    bpy.context.view_layer.objects.active = delobj
                except:
                    break
                if bpy.context.active_object.name == delobj.name:
                    bpy.ops.object.delete()

        for modifier in obj.modifiers:
            if modifier.type == 'NODES' and modifier.name.startswith("SB") and not material.name.startswith("Outline for"):
                obj.select_set(True)
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.modifier_remove(modifier=modifier.name)

        #handle solidify outline
        for node in nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("basecolor_solidify"):
                for modifier in obj.modifiers:
                    if modifier.name.startswith("SB Outline"):
                        obj.select_set(True)
                        bpy.context.view_layer.objects.active = obj
                        bpy.ops.object.modifier_remove(modifier=modifier.name)
                        break




        if obj and obj.active_material:
            material_name = obj.active_material.name
            # Unlink the material from the object
            obj.active_material = None
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.material_slot_remove()
        
            # Delete the material from bpy.data.materials
        if material_name in bpy.data.materials:
            #bpy.data.materials.remove(bpy.data.materials[material_name])
            print(f"Material '{material_name}' deleted.")
        else:
            print("No active object or no material found.")


        
        return {'FINISHED'}

class OpenURLOperator(bpy.types.Operator):
    bl_idname = "shaderaddon.opensite"
    bl_label = "Open URL"
    
    
    def execute(self, context):
        webbrowser.open('https://ukiyogirls.io/')
        return {'FINISHED'}

class SwapNodes(bpy.types.Operator):
    bl_idname = "shaderaddon.swapnodesold"
    bl_label = "Swap positions of 2 nodes"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        node1 = nodes.get(obj.node_groups_enum_swap2)
        node2 = nodes.get(obj.node_groups_enum_swap1)

        if node1.node_tree.name.startswith("Transparent") or node2.node_tree.name.startswith("Transparent"):
            return {'FINISHED'}

        if node1 == node2:
            return {'FINISHED'}

        node1name = nodes.get(obj.node_groups_enum_swap2).name
        node2name = nodes.get(obj.node_groups_enum_swap1).name

        node1inputs = []
        node2inputs = []

        try:
            for index, input in enumerate(node1.inputs, start=1):
                if index == len(node1.inputs):
                    break
                node1inputs.append(node1.inputs[index].default_value)
            
            for index, input in enumerate(node2.inputs, start=1):
                if index == len(node2.inputs):
                    break
                node2inputs.append(node2.inputs[index].default_value)
        except:
            joe = "kasou"

        temptree = node1.node_tree
        tempname = node1name

        node2.name = "timmytimmytimmyturner"
        node1.name = node2name
        node1.node_tree = node2.node_tree

        node2.name = tempname
        node2.node_tree = temptree

        try:
            for index, input in enumerate(node1.inputs, start=1):
                if index == len(node1.inputs):
                    break
                node1.inputs[index].default_value = node2inputs[index-1]

            for index, input in enumerate(node2.inputs, start=1):
                if index == len(node2.inputs):
                    break
                node2.inputs[index].default_value = node1inputs[index-1]
        except:
            joe = "kasou"

        timer_function()

        return {'FINISHED'}
        

class SwapNodes2(bpy.types.Operator):
    bl_idname = "shaderaddon.swapnodes"
    bl_label = "Swap positions of 2 nodes"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        node1 = nodes.get(obj.node_groups_enum_swap1)
        node2 = nodes.get(obj.node_groups_enum_swap2)

        if node1.node_tree.name.startswith('RedL') or node2.node_tree.name.startswith('RedL') or node1.node_tree.name.startswith('GreenL') or node2.node_tree.name.startswith('GreenL') or node1.node_tree.name.startswith('BlueL') or node2.node_tree.name.startswith('BlueL'):
            trav = nodes.get('Base Color')
            seenDiffuse = False
            while trav:
                if trav == node1 or trav == node2:
                    if not seenDiffuse:
                        return {'FINISHED'}
                    else:
                        break
                else:
                    if trav.node_tree.name.startswith('DiffuseL'):
                        seenDiffuse = True
                    if trav.outputs and trav.outputs[0].is_linked:
                        trav = trav.outputs[0].links[0].to_node
                    else:
                        break

        if node1.node_tree.name.startswith("Transparent"):
            if node2.node_tree.name.startswith("Transparent"):
                print("do nothing")
            else:
                return {'FINISHED'}
        if node2.node_tree.name.startswith("Transparent"):
            if node1.node_tree.name.startswith("Transparent"):
                print("do nothing")
            else:
                return {'FINISHED'}

        if node1 == node2:
            return {'FINISHED'}


        links = obj.active_material.node_tree.links

        adjacent = False
        adjacentNode = None
        if node1.outputs[0].is_linked and node1.outputs[0].links[0].to_node == node2:
            adjacent = True
            adjacentNode = node1
            secondNode = node2
        if node2.outputs[0].is_linked and node2.outputs[0].links[0].to_node == node1:
            adjacent = True
            adjacentNode = node2
            secondNode = node1

        node1locationtemp = node1.location.copy()
        node1.location = node2.location
        node2.location = node1locationtemp
        #swap adjacent nodes
        if adjacent:
            adjacent_input_link = adjacentNode.inputs[0].links[0].from_socket
            adjacentPrev = adjacentNode.inputs[0].links[0].from_node
            secondNext = secondNode.outputs[0].links[0].to_node
            links.new(secondNode.outputs[0], adjacentNode.inputs[0])
            links.new(adjacentPrev.outputs[0], secondNode.inputs[0])
            links.new(adjacentNode.outputs[0], secondNext.inputs[0])
            
        if adjacent == False:
            node1Prev = node1.inputs[0].links[0].from_node
            node1Next = node1.outputs[0].links[0].to_node
            node2Prev = node2.inputs[0].links[0].from_node
            node2Next = node2.outputs[0].links[0].to_node
            links.new(node2Prev.outputs[0], node1.inputs[0])
            links.new(node1.outputs[0], node2Next.inputs[0])
            links.new(node2.inputs[0], node1Prev.outputs[0])
            links.new(node2.outputs[0], node1Next.inputs[0])
        

        timer_function()

        return {'FINISHED'}


class DeleteEffect(bpy.types.Operator):
    bl_idname = "shaderaddon.deleteeffect"
    bl_label = "Delete an Effect"

    arg1: bpy.props.StringProperty(name="Argument 1", default="Hello")

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        mat = obj.active_material

        if mat.name.startswith("Outline for"):
            bpy.ops.shaderaddon.deletematerial()
            return {'FINISHED'}

        if mat and mat.use_nodes:
            node_tree = mat.node_tree
            #get the enum value for deleting the object
            if self.arg1 == 'Hello':
                node_name = obj.node_groups_enum
            else:
                try:
                    node_name = self.arg1
                except:
                    node_name = obj.node_groups_enum

            # node_name = obj.node_groups_enum
            if node_name.startswith("SB Disp"):
                to_remove = obj.modifiers.get(node_name)
                object_to_delete = to_remove.texture_coords_object
                try: 
                    object_to_delete.hide_viewport = False
                    object_to_delete.hide_set(False)
                    bpy.ops.object.select_all(action="DESELECT")
                    object_to_delete.select_set(True)
                    bpy.context.view_layer.objects.active = object_to_delete
                    bpy.ops.object.delete()
                except:
                    joe = "kasou"
                obj.modifiers.remove(to_remove)
                return {'FINISHED'}
            if node_name.startswith("SB Out"):
                to_remove = obj.modifiers.get(node_name)
                obj.modifiers.remove(to_remove)
                return {'FINISHED'}
            node_to_delete = node_tree.nodes.get(node_name)

            if node_to_delete:
                # Store links to be reconnected
                input_link = node_to_delete.inputs[0].links[0].from_socket if node_to_delete.inputs[0].is_linked else None
                output_link = node_to_delete.outputs[0].links[0].to_socket if node_to_delete.outputs[0].is_linked else None
                
                # Remove any associated empties (fakelights), rename fakelight nodes
                if node_to_delete.node_tree.name.startswith("LightObject"):
                    # last_character = node_to_delete.name[-1]
                    # number = int(last_character)
                    for modifier in obj.modifiers:
                        if modifier.name.startswith("SB Geono"):
                            if node_to_delete.node_tree.nodes["Attribute"].attribute_name != modifier.node_group.nodes["Store Named Attribute"].inputs[2].default_value:
                                continue
                            number = 0
                            if number == 0:
                                delobj = modifier.node_group.nodes["Object Info"].inputs[0].default_value
                                #check if theres any other objects using the empty sphere
                                flag = True
                                remove_from_all_list = []
                                for objeto in bpy.data.objects:
                                    if objeto == obj:
                                        continue
                                    if objeto.modifiers:
                                        for mod in objeto.modifiers:
                                            if mod.type == 'NODES' and mod.name.startswith("SB Geono") and obj.active_material != objeto.active_material:
                                                if mod.node_group.nodes["Object Info"].inputs[0].default_value == delobj:
                                                    flag = False
                                            if mod.type == 'NODES' and mod.name.startswith("SB Geono") and obj.active_material == objeto.active_material:
                                                remove_from_all_list.append(objeto)
                                if flag:
                                    if delobj is not None:
                                        try:
                                            delobj.hide_viewport = False
                                            delobj.hide_set(False)
                                            bpy.ops.object.select_all(action="DESELECT")
                                            delobj.select_set(True)
                                            bpy.context.view_layer.objects.active = delobj
                                            if bpy.context.active_object.name == delobj.name:
                                                bpy.ops.object.delete()
                                        except:
                                            joe = "kasou"
                                for removable in remove_from_all_list:
                                    removable.select_set(True)
                                    bpy.context.view_layer.objects.active = removable
                                    bpy.ops.object.modifier_remove(modifier=modifier.name)
                                    
                                obj.select_set(True)
                                bpy.context.view_layer.objects.active = obj
                                bpy.ops.object.modifier_remove(modifier=modifier.name)
                                #rename fakelight nodes -- this style could be problematic now that i switched the menu compilation to a while(node)
                                light_object_count = 1
                                for node in obj.active_material.node_tree.nodes:
                                    if node.type == 'GROUP' and node.node_tree.name.startswith("LightObject"):
                                        node.name = f"Light Object #{light_object_count}"
                                        light_object_count += 1
                
                #Remove modifiers for sunobject
                if node_to_delete.node_tree.name.startswith("SunObject"):
                    # last_character = node_to_delete.name[-1]
                    # number = int(last_character)
                    for modifier in obj.modifiers:
                        if modifier.name.startswith("SB Sun"):
                            if node_to_delete.node_tree.nodes["Attribute"].attribute_name != modifier.node_group.nodes["Store Named Attribute"].inputs[2].default_value:
                                continue
                            number = 0
                            if number == 0:
                                obj.select_set(True)
                                bpy.context.view_layer.objects.active = obj
                                bpy.ops.object.modifier_remove(modifier=modifier.name)
                                #rename fakelight nodes
                                light_object_count = 1
                                for node in obj.active_material.node_tree.nodes:
                                    if node.type == 'GROUP' and node.node_tree.name.startswith("SunObject"):
                                        node.name = f"Baked Sun Light #{light_object_count}"
                                        light_object_count += 1
                


                # Remove any associated empties (everything except fakelights) -- if ur adding a new effect with empty just set text to "zhatexturecoordinate"
                for node in node_to_delete.node_tree.nodes:
                    if node.name == "ZhaTexture Coordinate":
                        delobj = node.object
                        if delobj is None:
                            continue

                        delobj.hide_viewport = False
                        delobj.hide_set(False)

                        bpy.ops.object.select_all(action="DESELECT")
                        try:
                            delobj.select_set(True)
                        except:
                            continue
                        bpy.context.view_layer.objects.active = delobj
                        try:
                            bpy.context.view_layer.objects.active = delobj
                        except:
                            break
                        if bpy.context.active_object.name == delobj.name:
                            bpy.ops.object.delete()
                


                # Remove the node group
                node_tree.nodes.remove(node_to_delete)

                # Reconnect links
                if input_link and output_link:
                    node_tree.links.new(input_link, output_link)

                obj.select_set(True)
                bpy.context.view_layer.objects.active = obj

                #update counts for transparent nodes
                tp_count = 1
                tn_count = 1
                for node in obj.active_material.node_tree.nodes:
                    if node.type == 'GROUP' and node.node_tree.name.startswith("TransparentPaint"):
                        node.name = f"Charcoal/Watercolor #{tp_count}"
                        tp_count += 1
                    if node.type == 'GROUP' and node.node_tree.name.startswith("TransparentNoi"):
                        node.name = f"Transparent Dynamic Texture #{tn_count}"
                        tn_count += 1

                #setup enums for the view and delete effects
                newlist = []
                newlistview = []
                newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

                for node in node_tree.nodes:
                    if node.name == "Base Color":
                        newlistview.append((node.name, node.name, ""))
                        continue
                    if node.type == 'GROUP':
                        newlist.append((node.name, node.name, ""))
                        newlistview.append((node.name, node.name, ""))
                bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
                    name="Node Groups",
                    description = "List of Node Groups",
                    items = newlist
                )
                # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
                #     name="Node Groups View",
                #     description = "List of Node Groups for effect viewer",
                #     items = newlistview
                # )
                bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
                    name="Node Groups",
                    description = "List of Node Groups",
                    items = newlist
                )

        timer_function()

        return {'FINISHED'}


class RefreshMaterial(bpy.types.Operator):
    bl_idname = "shaderaddon.refreshmaterial"
    bl_label = "refresh the material"

    def execute(self, context):
        try:
            bpy.app.timers.unregister(timer_function)
        except:
            joe = "kasou"
        
        bpy.app.timers.register(timer_function)

        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}
        


class AddTransparentPaint(bpy.types.Operator):
    bl_idname = "shaderaddon.addtransparentpaint"
    bl_label = "add Charcoal/Watercolor Effect"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        material.blend_method = 'HASHED'
        material.show_transparent_back = False

        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return
        
        # Create the "TransparentPaint" node group
        transparent_paint_group = bpy.data.node_groups.get("TransparentPaint")
        if not transparent_paint_group:
            print("Node group 'Transparent Paint' not found.")
            return
        
        # Add the "TransparentPaint" node to the material
        output_node.location.x += 400
        joekasou = transparent_paint_group.copy()
        transparent_paint_node = nodes.new(type='ShaderNodeGroup')
        transparent_paint_node.node_tree = joekasou
        transparent_paint_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], transparent_paint_node.inputs[0])
        links.new(transparent_paint_node.outputs[0], output_node.inputs[0])

        print("Transparent Paint Node node group added and connected.")

        output_node.location.x += 200

        tp_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("TransparentPaint"):
                node.name = f"Charcoal/Watercolor #{tp_count}"
                tp_count += 1
        
        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}




class SaveImageTextures(bpy.types.Operator):
    bl_idname = "shaderaddon.saveimagetextures"
    bl_label = "save image textures externally"

    def execute(self, context):

        for image in bpy.data.images:
            try:
                if image.name.startswith(f"{bpy.context.scene.bake_name}") and not image.name.endswith("Diffuse") and not image.name.endswith("AO") and not image.name.endswith("Specular"):
                    bpy.ops.file.unpack_item(method='WRITE_LOCAL', id_name=f"{image.name}", id_type=19785)
                    # image.use_fake_user = False
            except:
                joe = 'kasoutis'

        return {'FINISHED'}







class AddOverallTexture(bpy.types.Operator):
    bl_idname = "shaderaddon.addoveralltexture"
    bl_label = "add an overall texure to use as overlay"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "OverallTexture" node group
        overall_texture_group = bpy.data.node_groups.get("OverallTexture")
        if not overall_texture_group:
            print("Node group 'Overall Texture' not found.")
            return
        
        # Add the "TransparentPaint" node to the material
        output_node.location.x += 400
        joekasou = overall_texture_group.copy()
        overall_texture_node = nodes.new(type='ShaderNodeGroup')
        overall_texture_node.node_tree = joekasou
        overall_texture_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], overall_texture_node.inputs[0])
        links.new(overall_texture_node.outputs[0], output_node.inputs[0])

        print("Texture Paint Node node group added and connected.")

        output_node.location.x += 200

        overall_texture_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("OverallTexture"):
                node.name = f"Texture Overlay #{overall_texture_count}"
                overall_texture_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )


        return {'FINISHED'}


class AddVertexPaint(bpy.types.Operator):
    bl_idname = "shaderaddon.addvertexpaint"
    bl_label = "add nodes for vertex painting"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "VertexPaint" node group
        vertex_paint_group = bpy.data.node_groups.get("VertexPaint")
        if not vertex_paint_group:
            print("Node group 'Vertex Paint' not found.")
            return
        
        # Add the "TransparentPaint" node to the material
        output_node.location.x += 400
        joekasou = vertex_paint_group.copy()
        vertex_paint_node = nodes.new(type='ShaderNodeGroup')
        vertex_paint_node.node_tree = joekasou
        vertex_paint_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], vertex_paint_node.inputs[0])
        links.new(vertex_paint_node.outputs[0], output_node.inputs[0])

        print("vertex Paint Node node group added and connected.")

        output_node.location.x += 200

        vertex_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("VertexPaint"):
                node.name = f"Vertex Paint #{vertex_count}"
                vertex_count += 1


        #handle enums (not necessary because now we have a timer function)
        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )


        return {'FINISHED'}


class AddSingleColor(bpy.types.Operator):
    bl_idname = "shaderaddon.addsinglecolor"
    bl_label = "texture paint with only one color"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "SingleColor" node group
        texture_paint_group = bpy.data.node_groups.get("SingleColor")
        if not texture_paint_group:
            print("Node group 'Texture Paint' not found.")
            return
        
        # Add the "TransparentPaint" node to the material
        output_node.location.x += 400
        joekasou = texture_paint_group.copy()
        texture_paint_node = nodes.new(type='ShaderNodeGroup')
        texture_paint_node.node_tree = joekasou
        texture_paint_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], texture_paint_node.inputs[0])
        links.new(texture_paint_node.outputs[0], output_node.inputs[0])

        print("Texture Paint Node node group added and connected.")

        output_node.location.x += 200

        texture_paint_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("SingleColor"):
                node.name = f"Texture Paint (1 Color) #{texture_paint_count}"
                texture_paint_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )


        return {'FINISHED'}

class DuplicateEffect(bpy.types.Operator):
    bl_idname = "shaderaddon.duplicateeffect"
    bl_label = "duplicate effect"
    
    
    arg1: bpy.props.StringProperty(name="Argument 1", default="Hello")

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return {'FINISHED'}


        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        node_name = self.arg1
        if self.arg1 == 'Hello':
            node_name = obj.node_groups_enum
        else:
            try:
                node_name = self.arg1
            except:
                node_name = obj.node_groups_enum

        duplicate_group = nodes.get(node_name).node_tree
        if duplicate_group.name.startswith("Diffuse"):
            return {'FINISHED'}
        if duplicate_group.name.startswith("LightObject"):
            return {'FINISHED'}
        if duplicate_group.name.startswith("SunObject"):
            return {'FINISHED'}
        if duplicate_group.name.startswith("CrossHatch"):
            return {'FINISHED'}
        if duplicate_group.name.startswith("SpecularRef"):
            return {'FINISHED'}

        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        for node in nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("Transparent"):
                output_node = node

        if not output_node:
            print("No Material Output node found.")
            return {'FINISHED'}

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return {'FINISHED'}

        

        # Duplicate the selected node group
        duplicate_group = nodes.get(obj.duplicate_group_enum).node_tree


        if not duplicate_group:
            print("Node group not found.")
            return {'FINISHED'}

        # Add the "TransparentPaint" node to the material
        output_node.location.x += 400
        joekasou = duplicate_group.copy()
        duplicate_node = nodes.new(type='ShaderNodeGroup')
        duplicate_node.node_tree = joekasou
        duplicate_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], duplicate_node.inputs[0])
        links.new(duplicate_node.outputs[0], output_node.inputs[0])

        print("Texture Paint Node node group added and connected.")

        output_node.location.x += 200


        #rename
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name == duplicate_node.node_tree.name:
                node.name = f"{obj.duplicate_group_enum} Duplicate"

        for node in duplicate_node.node_tree.nodes:
            if node.name == 'ZhaTexture Coordinate':
                if node.object is None:
                    random_offset_x = random.uniform(-5, 5)
                    random_offset_y = random.uniform(-5, 5)
                    random_offset_z = random.uniform(0, 2)

                    bpy.ops.object.empty_add(type='SPHERE')
                    emptysphere = bpy.context.object
                    emptysphere.location.x += random_offset_x
                    emptysphere.location.y += random_offset_y
                    emptysphere.location.z += random_offset_z
                    emptysphere.name = "SB " + f"{duplicate_node.name} " + f"{obj.name}"
                    emptysphere.parent = obj
                else:
                    bpy.ops.object.empty_add(type='SPHERE')
                    emptysphere = bpy.context.object
                    emptysphere.location = node.object.location
                    emptysphere.scale = node.object.scale
                    emptysphere.rotation_quaternion = node.object.rotation_quaternion
                    emptysphere.name = "SB " + f"{duplicate_node.name} " + f"{obj.name}"
                    emptysphere.parent = obj

                duplicate_node.node_tree.nodes["ZhaTexture Coordinate"].object = emptysphere


        #transfer inputs

        node1inputs = []
        node2inputs = []

        node1 = nodes.get(obj.duplicate_group_enum)
        node2 = duplicate_node
        try:
            for index, input in enumerate(node1.inputs, start=1):
                if index == len(node1.inputs):
                    break
                node1inputs.append(node1.inputs[index].default_value)
                node2.inputs[index].default_value = node1.inputs[index].default_value
            
            for index, input in enumerate(node2.inputs, start=1):
                if index == len(node2.inputs):
                    break
                node2inputs.append(node2.inputs[index].default_value)
        except:
            joe = "kasou"

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )


        return {'FINISHED'}

class NormalsPaint(bpy.types.Operator):
    bl_idname = "shaderaddon.normalspaint"
    bl_label = "normals paint"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
            
        diffusenode = nodes.get('NormalsTextureHelper')
        if not diffusenode:
            return {'FINISHED'}


        node_before_output = output_node.inputs['Surface'].links[0].from_node

        if bpy.context.mode != 'PAINT_TEXTURE' and nodes.get('TempTemp') is None:
            bpy.ops.object.mode_set(mode='TEXTURE_PAINT')

            for i, slot in enumerate(material.texture_paint_images):
                if slot.name == nodes.get('NormalsTextureHelper').image.name:
                    material.paint_active_slot = i
                    print(f"Set paint active slot to")

            links.new(diffusenode.outputs[0], output_node.inputs['Surface'])
            math_node = nodes.new('ShaderNodeMath')
            math_node.name = 'TempTemp'
            math_node.label = node_before_output.name
        elif bpy.context.mode != 'PAINT_TEXTURE' and nodes.get('TempTemp') is not None:
            math_node = nodes.get('TempTemp')
            links.new(nodes.get(math_node.label).outputs[0], output_node.inputs['Surface'])
            nodes.remove(math_node)
        else:
            bpy.ops.object.mode_set(mode='OBJECT')
            
            math_node = nodes.get('TempTemp')
            links.new(nodes.get(math_node.label).outputs[0], output_node.inputs['Surface'])
            nodes.remove(math_node)
            

        

        return {'FINISHED'}

class AddBrushStrokes(bpy.types.Operator):
    bl_idname = "shaderaddon.addbrushstrokes"
    bl_label = "add nodes for dynamic brush strokes effect"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "TexturePaint" node group
        texture_paint_group = bpy.data.node_groups.get("BrushStrokes")
        if not texture_paint_group:
            print("Node group 'Texture Paint' not found.")
            return
        
        # Add the "TransparentPaint" node to the material
        output_node.location.x += 400
        joekasou = texture_paint_group.copy()
        texture_paint_node = nodes.new(type='ShaderNodeGroup')
        texture_paint_node.node_tree = joekasou
        texture_paint_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], texture_paint_node.inputs[0])
        links.new(texture_paint_node.outputs[0], output_node.inputs[0])

        print("Texture Paint Node node group added and connected.")

        output_node.location.x += 200

        texture_paint_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("BrushStrokes"):
                node.name = f"Brush Strokes #{texture_paint_count}"
                texture_paint_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}

class AddObjectRandomize(bpy.types.Operator):
    bl_idname = "shaderaddon.addobjectrandomize"
    bl_label = "add nodes for object randomization"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return
        
        # Create the "TexturePaint" node group
        texture_paint_group = bpy.data.node_groups.get("ObjectRandomize")
        if not texture_paint_group:
            print("Node group 'Texture Paint' not found.")
            return
        
        # Add the "TransparentPaint" node to the material
        output_node.location.x += 400
        joekasou = texture_paint_group.copy()
        texture_paint_node = nodes.new(type='ShaderNodeGroup')
        texture_paint_node.node_tree = joekasou
        texture_paint_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], texture_paint_node.inputs[0])
        links.new(texture_paint_node.outputs[0], output_node.inputs[0])

        print("Texture Paint Node node group added and connected.")

        output_node.location.x += 200

        texture_paint_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("ObjectRandomize"):
                node.name = f"Object Randomize #{texture_paint_count}"
                texture_paint_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )


        return {'FINISHED'}

class AddRGBCurves(bpy.types.Operator):
    bl_idname = "shaderaddon.addrgbcurves"
    bl_label = "add nodes for contrasts"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return
        
        # Create the "TexturePaint" node group
        texture_paint_group = bpy.data.node_groups.get("RGBContrast")
        if not texture_paint_group:
            print("Node group 'Texture Paint' not found.")
            return
        
        # Add the "TransparentPaint" node to the material
        output_node.location.x += 400
        joekasou = texture_paint_group.copy()
        texture_paint_node = nodes.new(type='ShaderNodeGroup')
        texture_paint_node.node_tree = joekasou
        texture_paint_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], texture_paint_node.inputs[0])
        links.new(texture_paint_node.outputs[0], output_node.inputs[0])

        print("Texture Paint Node node group added and connected.")

        output_node.location.x += 200

        texture_paint_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("RGBContrast"):
                node.name = f"Contrast #{texture_paint_count}"
                texture_paint_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )


        return {'FINISHED'}

class ExternalPaint(bpy.types.Operator):
    bl_idname = "shaderaddon.externalpaint"
    bl_label = "external painting"
    
    arg1: bpy.props.StringProperty(name="Argument 1", default="none")
    
    def execute(self, context):
        import bpy

        # Switch to Texture Paint mode
        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')

        material = bpy.context.object.active_material
        node_tree = material.node_tree

        # for node in node_tree.nodes:
        #     # Check if node is a group
        #     if node.type == 'GROUP':
        #         # Check if node group name starts with "TexturePaint"
        #         if node.node_tree.name.startswith("TexturePaint"):
        #             node.node_tree.nodes["Main"].select = True
        #             node.node_tree.nodes.active = node.node_tree.nodes['Main']
        
        for i, slot in enumerate(material.texture_paint_images):
            if slot.name == self.arg1:
                material.paint_active_slot = i
                print(f"Set paint active slot to")
                    
        bpy.ops.image.project_edit()
        
        return {'FINISHED'}

class AddTexturePaint(bpy.types.Operator):
    bl_idname = "shaderaddon.addtexturepaint"
    bl_label = "add nodes for drawing/texture painting"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return
        
        # Create the "TexturePaint" node group
        texture_paint_group = bpy.data.node_groups.get("TexturePaint")
        if not texture_paint_group:
            print("Node group 'Texture Paint' not found.")
            return
        
        # Add the "TransparentPaint" node to the material
        output_node.location.x += 400
        joekasou = texture_paint_group.copy()
        texture_paint_node = nodes.new(type='ShaderNodeGroup')
        texture_paint_node.node_tree = joekasou
        texture_paint_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], texture_paint_node.inputs[0])
        links.new(texture_paint_node.outputs[0], output_node.inputs[0])

        print("Texture Paint Node node group added and connected.")

        output_node.location.x += 200

        texture_paint_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("TexturePaint"):
                node.name = f"Texture Paint #{texture_paint_count}"
                texture_paint_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )


        return {'FINISHED'}



class AddSolidifyOutline(bpy.types.Operator):
    bl_idname = "shaderaddon.addsolidifyoutline"
    bl_label = "add solidify outline"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj:
            print("No active object or no material with nodes found.")
            return {'FINISHED'}
        

        outlinematerial = bpy.data.materials.get("solidifyoutline")
        if not outlinematerial:
            return

        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj

        duplicate_material = outlinematerial.copy()
        duplicate_material.name = f"Outline for {obj.name}"
        temptree = duplicate_material.node_tree.nodes[0].node_tree.copy()
        duplicate_material.node_tree.nodes[0].node_tree = temptree

        obj.data.materials.append(duplicate_material)

        num_slots = len(obj.material_slots)
        obj.active_material_index = num_slots - 1

        for _ in range(num_slots-1):
            bpy.ops.object.material_slot_move(direction='UP')
        
        solidify_modifier = obj.modifiers.new(name="Solidify", type='SOLIDIFY')
        solidify_modifier.name = f"SB Outline for {obj.name}"

        solidify_modifier.offset = 1
        solidify_modifier.use_rim = False
        solidify_modifier.use_flip_normals = True
        solidify_modifier.material_offset = -100

        return {'FINISHED'}
        


class AddColoredEdges(bpy.types.Operator):
    bl_idname = "shaderaddon.addcolorededges"
    bl_label = "add colored edges"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        output_node = None
        material_output_reference = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                material_output_reference = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "ColoredEdges" node group
        colored_edges_group = bpy.data.node_groups.get("ColoredEdges")
        if not colored_edges_group:
            print("Node group 'colored edges' not found.")
            return
        
        # Add the "AmbientOcclusion" node to the material
        output_node.location.x += 400
        joekasou = colored_edges_group.copy()
        colored_edges_node = nodes.new(type='ShaderNodeGroup')
        colored_edges_node.node_tree = joekasou
        colored_edges_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], colored_edges_node.inputs[0])
        links.new(colored_edges_node.outputs[0], output_node.inputs[0])

        print("colored edges Node node group added and connected.")

        output_node.location.x += 200

        if output_node.type == 'GROUP' and output_node.node_tree.name.startswith("Transparent"):
            material_output_reference.location.x += 200

        colored_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("ColoredEdges"):
                node.name = f"Colored Edges #{colored_count}"
                colored_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}
        

class AddRedLight(bpy.types.Operator):
    bl_idname = "shaderaddon.addredlight"
    bl_label = "add a 1 point light"

    def execute(self, context):
        edge_detect_group = bpy.data.node_groups.get("RedLightSAS")
        materiallist = []
        curcount = 0
        def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):
            def draw(self, context):
                self.layout.label(text=message)
                
            bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)
        for obj in bpy.data.objects:
            try:
                if obj.active_material.node_tree.nodes.get("SAS Point Lights Group #1") is not None:
                    curcount += 1
            except:
                continue
        if curcount >= 25:
            ShowMessageBox(message="Max Objects (25) for using the Stylized Point Light Reached. Please Upgrade to Pro or Join the Masterclass on ukiyogirls.io", title="Message Box", icon='INFO')
            return {'FINISHED'}
        objcount = curcount
        for obj in bpy.context.selected_objects:
            # obj = bpy.context.active_object
            if objcount >= 25:
                ShowMessageBox(message="Max Objects (25) for using the Stylized Point Light Reached. Please Upgrade to Pro or Join the Masterclass on ukiyogirls.io", title="Message Box", icon='INFO')
                return {'FINISHED'}

            tempobj = None
            if obj.type == 'EMPTY' and obj.name.startswith("SB"):
                tempobj = obj.parent
                obj = tempobj
            elif obj.type == 'MESH' and obj.name.startswith("SB"):
                tempobj = obj.parent
                obj = tempobj
            
            if not obj or not obj.active_material or not obj.active_material.use_nodes:
                print("No active object or no material with nodes found.")
                return {'FINISHED'}

            material = obj.active_material
            if material in materiallist:
                continue
            else:
                materiallist.append(material)
            
            nodes = material.node_tree.nodes
            links = material.node_tree.links

            if nodes.get('Base Color') is None:
                continue

            #check if theres a stylized light dynamic effect, if not, we have to continue
            if nodes.get('Stylized Light (Dynamic) - #1') is None:
                continue

            falseflag = False
            for node in nodes:
                if node.type == 'GROUP' and node.node_tree.name.startswith("RedLightSAS"):
                    falseflag = True
                    break

            if falseflag:
                continue

            output_node = None
            material_output_reference = None
            for node in nodes:
                if node.type == 'OUTPUT_MATERIAL':
                    output_node = node
                    material_output_reference = node
                    break
            
            node1 = nodes.get("Base Color")
            while node1:
                if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                    output_node = node1
                    break
                if node1.outputs and node1.outputs[0].is_linked:
                    node1 = node1.outputs[0].links[0].to_node
                else:
                    break

            if not output_node:
                print("No Material Output node found.")
                return



            incoming_link = None
            for link in links:
                if link.to_node == output_node:
                    incoming_link = link
                    break

            if not incoming_link:
                print("No link to the Material Output node found.")
                return

            # Create the "HSL" node group
            
            if not edge_detect_group:
                print("Node group 'edge detect' not found.")
                return
            
            # Add the "AmbientOcclusion" node to the material
            output_node.location.x += 400
            joekasou = edge_detect_group
            edge_detect_node = nodes.new(type='ShaderNodeGroup')
            edge_detect_node.node_tree = joekasou
            edge_detect_node.location = (output_node.location.x - 200, output_node.location.y)

            # Connect the new node
            links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], edge_detect_node.inputs[0])
            links.new(edge_detect_node.outputs[0], output_node.inputs[0])

            print("edge detect Node node group added and connected.")

            output_node.location.x += 200

            if output_node.type == 'GROUP' and output_node.node_tree.name.startswith("Transparent"):
                material_output_reference.location.x += 200

            edge_count = 1
            for node in obj.active_material.node_tree.nodes:
                if node.type == 'GROUP' and node.node_tree.name.startswith("RedLightSAS"):
                    node.name = f"SAS Point Lights Group #1"
                    edge_count += 1

            for node in obj.active_material.node_tree.nodes:
                if node.type == 'GROUP' and node.node_tree.name.startswith("DiffuseL"):
                    links.new(node.outputs['Custom'], edge_detect_node.inputs['Vector'])

            #add the point light
            if not 'SAS Point Light Group #1' in bpy.data.objects:
                bpy.ops.object.light_add(type='POINT')
                bpy.context.active_object.data.color = (1, 0, 0)
                bpy.context.active_object.name = 'SAS Point Light Group #1'
            # bpy.context.active_object.data.name = 'sasred'

            #update object count
            objcount += 1

            newlist = []
            newlistview = []
            newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

            for node in obj.active_material.node_tree.nodes:
                if node.name == "Base Color":
                    newlistview.append((node.name, node.name, ""))
                    continue
                if node.type == 'GROUP':
                    newlist.append((node.name, node.name, ""))
                    newlistview.append((node.name, node.name, ""))
            bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
                name="Node Groups",
                description = "List of Node Groups",
                items = newlist
            )
            # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
            #     name="Node Groups View",
            #     description = "List of Node Groups for effect viewer",
            #     items = newlistview
            # )
            bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
                name="Node Groups",
                description = "List of Node Groups",
                items = newlist
            )
            bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
                name="Node Groups",
                description = "List of Node Groups",
                items = newlist
            )
            bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
                name="Node Groups",
                description = "List of Node Groups",
                items = newlist
            )

        return {'FINISHED'}


class AddHSL(bpy.types.Operator):
    bl_idname = "shaderaddon.addhsl"
    bl_label = "add a hsl effect"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        output_node = None
        material_output_reference = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                material_output_reference = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        
        


        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "HSL" node group
        edge_detect_group = bpy.data.node_groups.get("FinalHSL")
        if not edge_detect_group:
            print("Node group 'edge detect' not found.")
            return
        
        # Add the "AmbientOcclusion" node to the material
        output_node.location.x += 400
        joekasou = edge_detect_group.copy()
        edge_detect_node = nodes.new(type='ShaderNodeGroup')
        edge_detect_node.node_tree = joekasou
        edge_detect_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], edge_detect_node.inputs[0])
        links.new(edge_detect_node.outputs[0], output_node.inputs[0])

        print("edge detect Node node group added and connected.")

        output_node.location.x += 200

        if output_node.type == 'GROUP' and output_node.node_tree.name.startswith("Transparent"):
            material_output_reference.location.x += 200

        edge_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("FinalHSL"):
                node.name = f"Hue/Saturation/Value Shift #{edge_count}"
                edge_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class AddCurvature(bpy.types.Operator):
    bl_idname = "shaderaddon.addcurvature"
    bl_label = "add a hsl effect"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        material_output_reference = None

        def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):
            def draw(self, context):
                self.layout.label(text=message)
                
            bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

        for node in nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("AddCurva"):
                ShowMessageBox("Max 1 Curvature Effect is possible currently", "My Title", 'ERROR')
                return {'FINISHED'}

        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                material_output_reference = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        
        


        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "HSL" node group
        edge_detect_group = bpy.data.node_groups.get("AddCurvature")
        if not edge_detect_group:
            print("Node group 'edge detect' not found.")
            return
        
        # Add the "AmbientOcclusion" node to the material
        output_node.location.x += 400
        joekasou = edge_detect_group.copy()
        edge_detect_node = nodes.new(type='ShaderNodeGroup')
        edge_detect_node.node_tree = joekasou
        edge_detect_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], edge_detect_node.inputs[0])
        links.new(edge_detect_node.outputs[0], output_node.inputs[0])

        print("edge detect Node node group added and connected.")

        output_node.location.x += 200

        if output_node.type == 'GROUP' and output_node.node_tree.name.startswith("Transparent"):
            material_output_reference.location.x += 200

        edge_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("AddCurvature"):
                node.name = f"Curvature #{edge_count}"
                edge_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}

class AddHairCurves(bpy.types.Operator):
    bl_idname = "shaderaddon.addhaircurves"
    bl_label = "add hair curves reflections"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        output_node = None
        material_output_reference = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                material_output_reference = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        
        


        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "HSL" node group
        edge_detect_group = bpy.data.node_groups.get("HairCurves")
        if not edge_detect_group:
            print("Node group 'edge detect' not found.")
            return
        
        # Add the "AmbientOcclusion" node to the material
        output_node.location.x += 400
        joekasou = edge_detect_group.copy()
        edge_detect_node = nodes.new(type='ShaderNodeGroup')
        edge_detect_node.node_tree = joekasou
        edge_detect_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], edge_detect_node.inputs[0])
        links.new(edge_detect_node.outputs[0], output_node.inputs[0])

        print("edge detect Node node group added and connected.")

        output_node.location.x += 200

        if output_node.type == 'GROUP' and output_node.node_tree.name.startswith("Transparent"):
            material_output_reference.location.x += 200

        edge_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("HairCurves"):
                node.name = f"Hair Curve Reflect #{edge_count}"
                edge_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class AddEdgeDetect(bpy.types.Operator):
    bl_idname = "shaderaddon.addedgedetect"
    bl_label = "add Edge Outline"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        output_node = None
        material_output_reference = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                material_output_reference = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        
        


        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "EdgeDetect" node group
        edge_detect_group = bpy.data.node_groups.get("EdgeDetect")
        if not edge_detect_group:
            print("Node group 'edge detect' not found.")
            return
        
        # Add the "AmbientOcclusion" node to the material
        output_node.location.x += 400
        joekasou = edge_detect_group.copy()
        edge_detect_node = nodes.new(type='ShaderNodeGroup')
        edge_detect_node.node_tree = joekasou
        edge_detect_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], edge_detect_node.inputs[0])
        links.new(edge_detect_node.outputs[0], output_node.inputs[0])

        print("edge detect Node node group added and connected.")

        output_node.location.x += 200

        if output_node.type == 'GROUP' and output_node.node_tree.name.startswith("Transparent"):
            material_output_reference.location.x += 200

        edge_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("EdgeDetect"):
                node.name = f"Edge Detect #{edge_count}"
                edge_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class AddAO(bpy.types.Operator):
    bl_idname = "shaderaddon.addao"
    bl_label = "add Ambient Occlusion"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        for node in nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("AmbientOcc"):
                return {'FINISHED'}

        output_node = None
        material_output_reference = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                material_output_reference = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return
        


        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return
        
        # Create the "AmbientOcclusion" node group
        ambient_occlusion_group = bpy.data.node_groups.get("AmbientOcclusion")
        if not ambient_occlusion_group:
            print("Node group 'Ambient Occlusion' not found.")
            return
        
        # Add the "AmbientOcclusion" node to the material
        output_node.location.x += 400
        joekasou = ambient_occlusion_group.copy()
        ambient_occlusion_node = nodes.new(type='ShaderNodeGroup')
        ambient_occlusion_node.node_tree = joekasou
        ambient_occlusion_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], ambient_occlusion_node.inputs[0])
        links.new(ambient_occlusion_node.outputs[0], output_node.inputs[0])

        print("Ambient Occlusion Node node group added and connected.")

        output_node.location.x += 200

        if output_node.type == 'GROUP' and output_node.node_tree.name.startswith("Transparent"):
            material_output_reference.location.x += 200

        ambient_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("AmbientOcclusion"):
                node.name = f"Ambient Occlusion #{ambient_count}"
                ambient_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}




class DuplicateMaterial(bpy.types.Operator):
    bl_idname = "shaderaddon.duplicatematerial"
    bl_label = "duplicate material"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        active_material = obj.active_material
        
        active_material_copy = active_material.copy()

        if active_material_copy.use_nodes:
            for node in active_material_copy.node_tree.nodes:
                if node.type == 'GROUP' and not node.node_tree.name.startswith("RedLight"):
                    node.node_tree = node.node_tree.copy()

        obj.active_material = active_material_copy

        #duplicate geonodes
        for modifier in obj.modifiers:
            if modifier.type == 'NODES' and modifier.name.startswith("SB"):
                node_tree = modifier.node_group
                if node_tree:
                    new_node_tree = node_tree.copy()
                    modifier.node_group = new_node_tree

        return {'FINISHED'}


class AddCrossHatch(bpy.types.Operator):
    bl_idname = "shaderaddon.addcrosshatch"
    bl_label = "add cross hatch lighting"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return {'FINISHED'}

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        for node in nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("Diffuse"):
                return {'FINISHED'}
            if node.type == 'GROUP' and node.node_tree.name.startswith("CrossHatch"):
                return {'FINISHED'}

        # Find the Material Output node
        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        # for node in nodes:
        #     if node.type == 'GROUP' and node.node_tree.name.startswith("Transparent") and node.name.endswith("1"):
        #         output_node = node
        #         break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return {'FINISHED'}

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return {'FINISHED'}
        
        # Create the "DiffuseLight" node group
        diffuse_light_group = bpy.data.node_groups.get("CrossHatch")
        if not diffuse_light_group:
            print("Node group 'Diffuse Light' not found.")
            return {'FINISHED'}
        
        # Add the "DiffuseLight" node to the material
        output_node.location.x += 400
        joekasou = diffuse_light_group.copy()
        diffuse_light_node = nodes.new(type='ShaderNodeGroup')
        diffuse_light_node.node_tree = joekasou
        diffuse_light_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], diffuse_light_node.inputs[0])
        links.new(diffuse_light_node.outputs[0], output_node.inputs[0])

        print("Diffuse Light Node node group added and connected.")

        output_node.location.x += 200

        diffuse_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("CrossHatch"):
                node.name = f"Cross Hatch Lighting (Dynamic)"
                diffuse_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class AddDiffuseLighting(bpy.types.Operator):
    bl_idname = "shaderaddon.adddiffuselighting"
    bl_label = "add diffuse lighting"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return {'FINISHED'}

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        for node in nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("Diffuse"):
                return {'FINISHED'}
            if node.type == 'GROUP' and node.node_tree.name.startswith("CrossHatch"):
                return {'FINISHED'}

        # Find the Material Output node
        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        # for node in nodes:
        #     if node.type == 'GROUP' and node.node_tree.name.startswith("Transparent") and node.name.endswith("1"):
        #         output_node = node
        #         break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return {'FINISHED'}

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return {'FINISHED'}
        
        # Create the "DiffuseLight" node group
        diffuse_light_group = bpy.data.node_groups.get("DiffuseLight")
        if not diffuse_light_group:
            print("Node group 'Diffuse Light' not found.")
            return {'FINISHED'}
        
        # Add the "DiffuseLight" node to the material
        output_node.location.x += 400
        joekasou = diffuse_light_group.copy()
        diffuse_light_node = nodes.new(type='ShaderNodeGroup')
        diffuse_light_node.node_tree = joekasou
        diffuse_light_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], diffuse_light_node.inputs[0])
        links.new(diffuse_light_node.outputs[0], output_node.inputs[0])

        print("Diffuse Light Node node group added and connected.")

        output_node.location.x += 200

        diffuse_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("DiffuseLight"):
                node.name = f"Stylized Light (Dynamic) - #{diffuse_count}"
                diffuse_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class AddFakeSun(bpy.types.Operator):
    bl_idname = "shaderaddon.addsunlight"
    bl_label = "Add Sun Light (Easily Bake)"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        for modifier in obj.modifiers:
            if modifier.name.startswith("SB Sun"):
                return {'FINISHED'}

        

        #handle geonodes

        fakesungeonode = bpy.data.node_groups.get("SunPower").copy()

        geomodifier = obj.modifiers.new(name="SB SunNodes", type='NODES')

        geomodifier.node_group = fakesungeonode

        #end geonodes


        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        # material.blend_method = 'BLEND'
        # material.show_transparent_back = False

        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "SunObject" node group
        sun_object_group = bpy.data.node_groups.get("SunObject")
        if not sun_object_group:
            print("Node group 'Sun Object' not found.")
            return
        
        # Add the "SunObject" node to the material
        output_node.location.x += 400
        joekasou = sun_object_group.copy()
        sun_object_node = nodes.new(type='ShaderNodeGroup')
        sun_object_node.node_tree = joekasou
        sun_object_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], sun_object_node.inputs[0])
        links.new(sun_object_node.outputs[0], output_node.inputs[0])

        print("Noise Texture Node node group added and connected.")

        output_node.location.x += 200

        currattrname = None
        #renaming
        light_object_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("SunObject"):
                node.name = f"Sun Light #{light_object_count}"
                node.node_tree.nodes["Attribute"].attribute_name = f"Light {light_object_count}"
                currattrname = node.node_tree.nodes["Attribute"].attribute_name
                number = light_object_count
                for modifier in obj.modifiers:
                    if modifier.type == 'NODES' and modifier.name.startswith("SB"):
                        number -= 1
                        if number == 0:
                            modifier.node_group.nodes["Store Named Attribute"].inputs[2].default_value = currattrname
                light_object_count += 1
        
        #add attributes
        
        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}




class AddFakeLight(bpy.types.Operator):
    bl_idname = "shaderaddon.addobjectlight"
    bl_label = "Add Object Light (Easily Bake)"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return


        #handle geonodes

        fakelightgeonode = bpy.data.node_groups.get("SB Light Creation").copy()

        geomodifier = obj.modifiers.new(name="SB Geonodes", type='NODES')

        geomodifier.node_group = fakelightgeonode

        #end geonodes


        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        # material.blend_method = 'BLEND'
        # material.show_transparent_back = False

        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "LightObject" node group
        light_object_group = bpy.data.node_groups.get("LightObject")
        if not light_object_group:
            print("Node group 'Light Object' not found.")
            return
        
        # Add the "NoiseTexture" node to the material
        output_node.location.x += 400
        joekasou = light_object_group.copy()
        light_object_node = nodes.new(type='ShaderNodeGroup')
        light_object_node.node_tree = joekasou
        light_object_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], light_object_node.inputs[0])
        links.new(light_object_node.outputs[0], output_node.inputs[0])

        print("Noise Texture Node node group added and connected.")

        output_node.location.x += 200

        currattrname = None
        #renaming
        light_object_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("LightObject"):
                node.name = f"Light (Object) #{light_object_count}"
                node.node_tree.nodes["Attribute"].attribute_name = f"Light {light_object_count}"
                currattrname = node.node_tree.nodes["Attribute"].attribute_name
                number = light_object_count
                for modifier in obj.modifiers:
                    if modifier.type == 'NODES' and modifier.name.startswith("SB"):
                        number -= 1
                        if number == 0:
                            modifier.node_group.nodes["Store Named Attribute"].inputs[2].default_value = currattrname
                light_object_count += 1

        # node1 = nodes.get("Base Color")
        # light_object_count = 1
        # while node1:
        #     if node1.type == 'GROUP' and node1.node_tree.name.startswith("LightObject"):
        #         node1.name = f"Light (Easy Bake) #{light_object_count}"
        #         node1.node_tree.nodes["Attribute"].attribute_name = f"Light {light_object_count}"
        #         currattrname = node1.node_tree.nodes["Attribute"].attribute_name
        #         number = light_object_count
        #         for modifier in obj.modifiers:
        #             if modifier.type == 'NODES' and modifier.name.startswith("SB"):
        #                 number -= 1
        #                 if number == 0:
        #                     modifier.node_group.nodes["Store Named Attribute"].inputs[2].default_value = currattrname
        #         light_object_count += 1
        #     if node1.outputs and node1.outputs[0].is_linked:
        #         node1 = node1.outputs[0].links[0].to_node
        #     else:
        #         break

        
        #check if theres other objects sharing this material
        for objeto in bpy.data.objects:
            if objeto == obj:
                continue
            if objeto.active_material == obj.active_material:
                objeto.modifiers.new(name="aloha", type='NODES')
                objeto.modifiers["aloha"].name = geomodifier.name
                objeto.modifiers[f"{geomodifier.name}"].node_group = geomodifier.node_group

        #add attributes
        

        random_offset_x = random.uniform(-5, 5)
        random_offset_y = random.uniform(-5, 5)
        random_offset_z = random.uniform(0, 2)


        bpy.ops.mesh.primitive_uv_sphere_add()
        emptysphere = bpy.context.object
        emptysphere.show_name = True
        emptysphere.display_type = 'BOUNDS'
        emptysphere.display_bounds_type = 'SPHERE'
        emptysphere.location.x += random_offset_x
        emptysphere.location.y += random_offset_y
        emptysphere.location.z += random_offset_z
        emptysphere.name = "SB " + f"{light_object_node.name} " + f"{obj.name}"
        emptysphere.parent = obj
        emptysphere.data.materials.append(None)
        emptysphere.data.materials[0] = bpy.data.materials.get("SBfullblank")

        geomodifier.node_group.nodes["Object Info"].inputs[0].default_value = emptysphere

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class MaskSpeculars(bpy.types.Operator):
    bl_idname = "shaderaddon.maskspeculars"
    bl_label = "mask speculars from dynamic noise"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return {'FINISHED'}
        
        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        specular_group = None

        for node in nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("SpecularRef"):
                specular_group = node

        try:
            for node in nodes:
                if node.type == 'GROUP' and node.node_tree.name.startswith("TransparentNoise"):
                    if node.inputs[70].default_value > 0.5:
                        links.new(specular_group.outputs[2], node.inputs[73])
        except:
            joe = "Kasoiu"

        return {'FINISHED'}


class AddTransparentWorldStrokes(bpy.types.Operator):
    bl_idname = "shaderaddon.addtransparentworldstrokes"
    bl_label = "add simple transparency, can also be used for floating strokes"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        if material.blend_method == 'HASHED':
            joe = "kasou"
        else:
            material.blend_method = 'BLEND'

        material.show_transparent_back = True

        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        # node1 = nodes.get("Base Color")
        # while node1:
        #     if node1.type == 'GROUP' and node1.node_tree.name.startswith("TransparentPa") and node1.name.endswith("1"):
        #         output_node = node1
        #         break
        #     if node1.outputs and node1.outputs[0].is_linked:
        #         node1 = node1.outputs[0].links[0].to_node
        #     else:
        #         break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "NoiseTexture" node group
        noise_texture_group = bpy.data.node_groups.get("TransparentWorldStrokes")
        if not noise_texture_group:
            print("Node group 'Noise Texture' not found.")
            return
        
        # Add the "NoiseTexture" node to the material
        output_node.location.x += 400
        joekasou = noise_texture_group.copy()
        noise_texture_node = nodes.new(type='ShaderNodeGroup')
        noise_texture_node.node_tree = joekasou
        noise_texture_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], noise_texture_node.inputs[0])
        links.new(noise_texture_node.outputs[0], output_node.inputs[0])

        print("Noise Texture Node node group added and connected.")

        output_node.location.x += 200

        noise_texture_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("TransparentWorldStrokes"):
                node.name = f"Simple Transparency #{noise_texture_count}"
                noise_texture_count += 1

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class AddTransparentNoise(bpy.types.Operator):
    bl_idname = "shaderaddon.addtransparentnoise"
    bl_label = "add transparent noise texture effect"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        if material.blend_method == 'HASHED':
            joe = "kasou"
        else:
            material.blend_method = 'BLEND'

        material.show_transparent_back = False

        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        # node1 = nodes.get("Base Color")
        # while node1:
        #     if node1.type == 'GROUP' and node1.node_tree.name.startswith("TransparentPa") and node1.name.endswith("1"):
        #         output_node = node1
        #         break
        #     if node1.outputs and node1.outputs[0].is_linked:
        #         node1 = node1.outputs[0].links[0].to_node
        #     else:
        #         break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "NoiseTexture" node group
        noise_texture_group = bpy.data.node_groups.get("TransparentNoiseTexture")
        if not noise_texture_group:
            print("Node group 'Noise Texture' not found.")
            return
        
        # Add the "NoiseTexture" node to the material
        output_node.location.x += 400
        joekasou = noise_texture_group.copy()
        noise_texture_node = nodes.new(type='ShaderNodeGroup')
        noise_texture_node.node_tree = joekasou
        noise_texture_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], noise_texture_node.inputs[0])
        links.new(noise_texture_node.outputs[0], output_node.inputs[0])

        print("Noise Texture Node node group added and connected.")

        output_node.location.x += 200

        noise_texture_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("TransparentNoiseTexture"):
                node.name = f"Transparent Dynamic Texture #{noise_texture_count}"
                noise_texture_count += 1

        random_offset_x = random.uniform(-5, 5)
        random_offset_y = random.uniform(-5, 5)
        random_offset_z = random.uniform(0, 2)


        bpy.ops.object.empty_add(type='SPHERE')
        emptysphere = bpy.context.object
        emptysphere.location.x += random_offset_x
        emptysphere.location.y += random_offset_y
        emptysphere.location.z += random_offset_z
        emptysphere.name = "SB " + f"{noise_texture_node.name} " + f"{obj.name}"
        emptysphere.parent = obj

        joekasou.nodes["ZhaTexture Coordinate"].object = emptysphere

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}

class AddStylizedFoam(bpy.types.Operator):
    bl_idname = "shaderaddon.addstylizedfoam"
    bl_label = "add stylized foam effect"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "StylizedFoam" node group
        noise_texture_group = bpy.data.node_groups.get("StylizedFoam")
        if not noise_texture_group:
            print("Node group 'Noise Texture' not found.")
            return
        
        # Add the "NoiseTexture" node to the material
        output_node.location.x += 400
        joekasou = noise_texture_group.copy()
        noise_texture_node = nodes.new(type='ShaderNodeGroup')
        noise_texture_node.node_tree = joekasou
        noise_texture_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], noise_texture_node.inputs[0])
        links.new(noise_texture_node.outputs[0], output_node.inputs[0])

        print("Noise Texture Node node group added and connected.")

        output_node.location.x += 200

        noise_texture_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("StylizedFoam"):
                node.name = f"Stylized Foam #{noise_texture_count}"
                noise_texture_count += 1

        random_offset_x = random.uniform(-5, 5)
        random_offset_y = random.uniform(-5, 5)
        random_offset_z = random.uniform(0, 2)


        bpy.ops.object.empty_add(type='SPHERE')
        emptysphere = bpy.context.object
        emptysphere.location.x += random_offset_x
        emptysphere.location.y += random_offset_y
        emptysphere.location.z += random_offset_z
        emptysphere.name = "SB " + f"{noise_texture_node.name} " + f"{obj.name}"
        emptysphere.parent = obj

        joekasou.nodes["ZhaTexture Coordinate"].object = emptysphere

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class AddNoiseTexture(bpy.types.Operator):
    bl_idname = "shaderaddon.addnoisetexture"
    bl_label = "add noise texture effect"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return
        
        # Create the "NoiseTexture" node group
        noise_texture_group = bpy.data.node_groups.get("NoiseTexture")
        if not noise_texture_group:
            print("Node group 'Noise Texture' not found.")
            return
        
        # Add the "NoiseTexture" node to the material
        output_node.location.x += 400
        joekasou = noise_texture_group.copy()
        noise_texture_node = nodes.new(type='ShaderNodeGroup')
        noise_texture_node.node_tree = joekasou
        noise_texture_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], noise_texture_node.inputs[0])
        links.new(noise_texture_node.outputs[0], output_node.inputs[0])

        print("Noise Texture Node node group added and connected.")

        output_node.location.x += 200

        noise_texture_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("NoiseTexture"):
                node.name = f"Dynamic Texture #{noise_texture_count}"
                noise_texture_count += 1

        random_offset_x = random.uniform(-5, 5)
        random_offset_y = random.uniform(-5, 5)
        random_offset_z = random.uniform(0, 2)


        bpy.ops.object.empty_add(type='SPHERE')
        emptysphere = bpy.context.object
        emptysphere.location.x += random_offset_x
        emptysphere.location.y += random_offset_y
        emptysphere.location.z += random_offset_z
        emptysphere.name = "SB " + f"{noise_texture_node.name} " + f"{obj.name}"
        emptysphere.parent = obj

        joekasou.nodes["ZhaTexture Coordinate"].object = emptysphere

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}
    

class AddEasyDT(bpy.types.Operator):
    bl_idname = "shaderaddon.addeasydt"
    bl_label = "add simple dynamic texture"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return
        
        # Create the "NoiseTexture" node group
        noise_texture_group = bpy.data.node_groups.get("EasyDT")
        if not noise_texture_group:
            print("Node group 'Noise Texture' not found.")
            return
        
        # Add the "NoiseTexture" node to the material
        output_node.location.x += 400
        joekasou = noise_texture_group.copy()
        noise_texture_node = nodes.new(type='ShaderNodeGroup')
        noise_texture_node.node_tree = joekasou
        noise_texture_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], noise_texture_node.inputs[0])
        links.new(noise_texture_node.outputs[0], output_node.inputs[0])

        print("Noise Texture Node node group added and connected.")

        output_node.location.x += 200

        noise_texture_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("EasyDT"):
                node.name = f"Simple Dynamic Texture #{noise_texture_count}"
                noise_texture_count += 1

        random_offset_x = random.uniform(-5, 5)
        random_offset_y = random.uniform(-5, 5)
        random_offset_z = random.uniform(0, 2)


        bpy.ops.object.empty_add(type='SPHERE')
        emptysphere = bpy.context.object
        emptysphere.location.x += random_offset_x
        emptysphere.location.y += random_offset_y
        emptysphere.location.z += random_offset_z
        emptysphere.name = "SB " + f"{noise_texture_node.name} " + f"{obj.name}"
        emptysphere.parent = obj

        joekasou.nodes["ZhaTexture Coordinate"].object = emptysphere

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class AddInstantWatercolor(bpy.types.Operator):
    bl_idname = "shaderaddon.addinstantwatercolor"
    bl_label = "add instant watercolor effect"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links


        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return
        
        # Create the "NoiseTexture" node group
        noise_texture_group = bpy.data.node_groups.get("InstantWatercolor")
        if not noise_texture_group:
            print("Node group 'Noise Texture' not found.")
            return
        
        # Add the "NoiseTexture" node to the material
        output_node.location.x += 400
        joekasou = noise_texture_group.copy()
        noise_texture_node = nodes.new(type='ShaderNodeGroup')
        noise_texture_node.node_tree = joekasou
        noise_texture_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], noise_texture_node.inputs[0])
        links.new(noise_texture_node.outputs[0], output_node.inputs[0])

        print("Noise Texture Node node group added and connected.")

        output_node.location.x += 200

        noise_texture_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("InstantWatercolor"):
                node.name = f"Stylized Grunge #{noise_texture_count}"
                noise_texture_count += 1

        # random_offset_x = random.uniform(-5, 5)
        # random_offset_y = random.uniform(-5, 5)
        # random_offset_z = random.uniform(0, 2)


        # bpy.ops.object.empty_add(type='SPHERE')
        # emptysphere = bpy.context.object
        # emptysphere.location.x += random_offset_x
        # emptysphere.location.y += random_offset_y
        # emptysphere.location.z += random_offset_z
        # emptysphere.name = "SB " + f"{noise_texture_node.name} " + f"{obj.name}"
        # emptysphere.parent = obj

        # joekasou.nodes["ZhaTexture Coordinate"].object = emptysphere

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class AddDisplace(bpy.types.Operator):
    bl_idname = "shaderaddon.adddisplace"
    bl_label = "add displace to model"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        
        if not obj:
            print("No active object or no material with nodes found.")
            return {'FINISHED'}

        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        
        displace_modifier = obj.modifiers.new(name="Displace", type='DISPLACE')

        displace_modifier.name = "SB Displace"
        displace_modifier.texture_coords = "OBJECT"

        random_offset_x = random.uniform(-5, 5)
        random_offset_y = random.uniform(-5, 5)
        random_offset_z = random.uniform(0, 2)


        bpy.ops.object.empty_add(type='SPHERE')
        emptysphere = bpy.context.object
        emptysphere.location.x += random_offset_x
        emptysphere.location.y += random_offset_y
        emptysphere.location.z += random_offset_z
        emptysphere.name = "SB " + f"Displace Effect " + f"{obj.name}"
        emptysphere.parent = obj

        displace_modifier.texture_coords_object = emptysphere

        timer_function()

        return {'FINISHED'}


# class AddMoodLight(bpy.types.Operator):
#     bl_idname = "shaderaddon.addcoloredcircularlight"
#     bl_label = "add colored circular light"

#     def execute(self, context):
#         obj = bpy.context.active_object

#         tempobj = None
#         if obj.type == 'EMPTY' and obj.name.startswith("SB"):
#             tempobj = obj.parent
#             obj = tempobj
#         elif obj.type == 'MESH' and obj.name.startswith("SB"):
#             tempobj = obj.parent
#             obj = tempobj

#         if not obj or not obj.active_material or not obj.active_material.use_nodes:
#             print("No active object or no material with nodes found.")
#             return

#         material = obj.active_material
#         nodes = material.node_tree.nodes
#         links = material.node_tree.links

#         # Find the Material Output node
#         output_node = None
#         for node in nodes:
#             if node.type == 'OUTPUT_MATERIAL':
#                 output_node = node
#                 break
        
#         node1 = nodes.get("Base Color")
#         while node1:
#             if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
#                 output_node = node1
#                 break
#             if node1.outputs and node1.outputs[0].is_linked:
#                 node1 = node1.outputs[0].links[0].to_node
#             else:
#                 break

#         if not output_node:
#             print("No Material Output node found.")
#             return

#         # Find the node that is currently connected to the Material Output node
#         incoming_link = None
#         for link in links:
#             if link.to_node == output_node:
#                 incoming_link = link
#                 break

#         if not incoming_link:
#             print("No link to the Material Output node found.")
#             return

#         # Create the "MoodLight" node group
#         mood_light_group = bpy.data.node_groups.get("ColoredCircular")
#         if not mood_light_group:
#             print("Node group 'ColoredCircular' not found.")
#             return
        
#         # Add the "LocalGradient" node to the material
#         output_node.location.x += 400
#         joekasou = mood_light_group.copy()
#         mood_light_node = nodes.new(type='ShaderNodeGroup')
#         mood_light_node.node_tree = joekasou
#         mood_light_node.location = (output_node.location.x - 200, output_node.location.y)

#         # Connect the new node
#         links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], mood_light_node.inputs[0])
#         links.new(mood_light_node.outputs[0], output_node.inputs[0])

#         print("Mood Light node group added and connected.")

#         output_node.location.x += 200

#         mood_count = 1
#         for node in obj.active_material.node_tree.nodes:
#             if node.type == 'GROUP' and node.node_tree.name.startswith("ColoredCircular"):
#                 node.name = f"Colored Light #{mood_count}"
#                 mood_count += 1


#         random_offset_x = random.uniform(-5, 5)
#         random_offset_y = random.uniform(-5, 5)
#         random_offset_z = random.uniform(0, 2)


#         bpy.ops.object.empty_add(type='SPHERE')
#         emptysphere = bpy.context.object
#         emptysphere.location.x += random_offset_x
#         emptysphere.location.y += random_offset_y
#         emptysphere.location.z += random_offset_z
#         emptysphere.name = "SB " + f"{mood_light_node.name} " + f"{obj.name}"
#         emptysphere.parent = obj

#         joekasou.nodes["ZhaTexture Coordinate"].object = emptysphere

#         newlist = []
#         newlistview = []
#         newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

#         for node in obj.active_material.node_tree.nodes:
#             if node.name == "Base Color":
#                 newlistview.append((node.name, node.name, ""))
#                 continue
#             if node.type == 'GROUP':
#                 newlist.append((node.name, node.name, ""))
#                 newlistview.append((node.name, node.name, ""))
#         bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
#             name="Node Groups",
#             description = "List of Node Groups",
#             items = newlist
#         )
#         # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
#         #     name="Node Groups View",
#         #     description = "List of Node Groups for effect viewer",
#         #     items = newlistview
#         # )
#         bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
#             name="Node Groups",
#             description = "List of Node Groups",
#             items = newlist
#         )
#         bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
#             name="Node Groups",
#             description = "List of Node Groups",
#             items = newlist
#         )
#         bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
#             name="Node Groups",
#             description = "List of Node Groups",
#             items = newlist
#         )

#         return {'FINISHED'}

class AddCircularLight(bpy.types.Operator):
    bl_idname = "shaderaddon.addcircularlight"
    bl_label = "add circular light"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        # Find the Material Output node
        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        # Find the node that is currently connected to the Material Output node
        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "LocalGradient" node group
        circular_light_group = bpy.data.node_groups.get("CircularLight")
        if not circular_light_group:
            print("Node group 'CircularLight' not found.")
            return
        
        # Add the "LocalGradient" node to the material
        output_node.location.x += 400
        joekasou = circular_light_group.copy()
        circular_light_node = nodes.new(type='ShaderNodeGroup')
        circular_light_node.node_tree = joekasou
        circular_light_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], circular_light_node.inputs[0])
        links.new(circular_light_node.outputs[0], output_node.inputs[0])

        print("Circular Light node group added and connected.")

        output_node.location.x += 200

        circular_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("CircularLight"):
                node.name = f"Circular Light #{circular_count}"
                circular_count += 1


        random_offset_x = random.uniform(-5, 5)
        random_offset_y = random.uniform(-5, 5)
        random_offset_z = random.uniform(0, 2)


        bpy.ops.object.empty_add(type='SPHERE')
        emptysphere = bpy.context.object
        emptysphere.location.x += random_offset_x
        emptysphere.location.y += random_offset_y
        emptysphere.location.z += random_offset_z
        emptysphere.name = "SB " + f"{circular_light_node.name} " + f"{obj.name}"
        emptysphere.parent = obj

        joekasou.nodes["ZhaTexture Coordinate"].object = emptysphere

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}


class AddLocalGradientSphere(bpy.types.Operator):
    bl_idname = "shaderaddon.addlocalgradientsphere"
    bl_label = "add local sphere gradient"

    
    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        # Find the Material Output node
        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        # Find the node that is currently connected to the Material Output node
        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "LocalGradient" node group
        local_gradient_group = bpy.data.node_groups.get("LocalGradientSphere")
        if not local_gradient_group:
            print("Node group 'LocalGradient' not found.")
            return

        # Add the "LocalGradient" node to the material
        output_node.location.x += 400
        joekasou = local_gradient_group.copy()
        local_gradient_node = nodes.new(type='ShaderNodeGroup')
        local_gradient_node.node_tree = joekasou
        local_gradient_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], local_gradient_node.inputs[0])
        links.new(local_gradient_node.outputs[0], output_node.inputs[0])

        print("LocalGradient node group added and connected.")

        output_node.location.x += 200

        gradient_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("LocalGradientSphere"):
                node.name = f"Sphere Gradient {gradient_count}"
                gradient_count += 1


        random_offset_x = random.uniform(-5, 5)
        random_offset_y = random.uniform(-5, 5)
        random_offset_z = random.uniform(0, 2)


        bpy.ops.object.empty_add(type='SPHERE')
        emptysphere = bpy.context.object
        emptysphere.location.x += random_offset_x
        emptysphere.location.y += random_offset_y
        emptysphere.location.z += random_offset_z
        emptysphere.name = "SB " + f"{local_gradient_node.name} " + f"{obj.name}"
        emptysphere.parent = obj

        joekasou.nodes["ZhaTexture Coordinate"].object = emptysphere

        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}

#Add Local Gradient
class AddLocalGradient(bpy.types.Operator):
    bl_idname = "shaderaddon.addlocalgradient"
    bl_label = "add local gradient"

    
    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        # Find the Material Output node
        output_node = None
        for node in nodes:
            if node.type == 'OUTPUT_MATERIAL':
                output_node = node
                break
        
        node1 = nodes.get("Base Color")
        while node1:
            if node1.type == 'GROUP' and node1.node_tree.name.startswith("Transparent"):
                output_node = node1
                break
            if node1.outputs and node1.outputs[0].is_linked:
                node1 = node1.outputs[0].links[0].to_node
            else:
                break

        if not output_node:
            print("No Material Output node found.")
            return

        # Find the node that is currently connected to the Material Output node
        incoming_link = None
        for link in links:
            if link.to_node == output_node:
                incoming_link = link
                break

        if not incoming_link:
            print("No link to the Material Output node found.")
            return

        # Create the "LocalGradient" node group
        local_gradient_group = bpy.data.node_groups.get("LocalGradient")
        if not local_gradient_group:
            print("Node group 'LocalGradient' not found.")
            return

        # Add the "LocalGradient" node to the material
        output_node.location.x += 400
        joekasou = local_gradient_group.copy()
        local_gradient_node = nodes.new(type='ShaderNodeGroup')
        local_gradient_node.node_tree = joekasou
        local_gradient_node.location = (output_node.location.x - 200, output_node.location.y)

        # Connect the new node
        links.new(incoming_link.from_node.outputs[incoming_link.from_socket.name], local_gradient_node.inputs[0])
        links.new(local_gradient_node.outputs[0], output_node.inputs[0])

        print("LocalGradient node group added and connected.")

        output_node.location.x += 200

        gradient_count = 1
        for node in obj.active_material.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree.name.startswith("LocalGradient"):
                node.name = f"Gradient {gradient_count}"
                gradient_count += 1


        random_offset_x = random.uniform(-5, 5)
        random_offset_y = random.uniform(-5, 5)
        random_offset_z = random.uniform(0, 2)


        bpy.ops.object.empty_add(type='SPHERE')
        emptysphere = bpy.context.object
        emptysphere.location.x += random_offset_x
        emptysphere.location.y += random_offset_y
        emptysphere.location.z += random_offset_z
        emptysphere.name = "SB " + f"{local_gradient_node.name} " + f"{obj.name}"
        emptysphere.parent = obj

        joekasou.nodes["ZhaTexture Coordinate"].object = emptysphere
       
        newlist = []
        newlistview = []
        newlistview.append(('SHOWALL', "Show all Items", "Show all Effects"))

        for node in obj.active_material.node_tree.nodes:
            if node.name == "Base Color":
                newlistview.append((node.name, node.name, ""))
                continue
            if node.type == 'GROUP':
                newlist.append((node.name, node.name, ""))
                newlistview.append((node.name, node.name, ""))
        bpy.types.Object.node_groups_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        # bpy.types.Object.node_groups_enum_view = bpy.props.EnumProperty(
        #     name="Node Groups View",
        #     description = "List of Node Groups for effect viewer",
        #     items = newlistview
        # )
        bpy.types.Object.node_groups_enum_swap2 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.node_groups_enum_swap1 = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )
        bpy.types.Object.duplicate_group_enum = bpy.props.EnumProperty(
            name="Node Groups",
            description = "List of Node Groups",
            items = newlist
        )

        return {'FINISHED'}

#World Panel

class WorldPanel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Stylized Asset Suite"
    bl_label = "Background Settings"

    def draw(self, context):
        
        layout = self.layout

        row = layout.row()
        row.operator("shaderaddon.worldsetup", text="Change Background Color")

        world = bpy.context.scene.world
        if world is not None and world.use_nodes:
            base_gradient_node = world.node_tree.nodes.get("Base Gradient")

            if base_gradient_node is not None:
                box = layout.box()
                row = box.row()
                row.label(text="Background Color Settings")

                material = bpy.data.worlds.get("layeredworld")
                nodes = material.node_tree.nodes

                row = layout.row()
                row.prop(nodes["Base Gradient"].node_tree.nodes["Map Range"], "interpolation_type", text="Style")
                row = layout.row()
                row.prop(nodes["Base Gradient"].node_tree.nodes["Gradient Texture"], "gradient_type", text="Gradient Type")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[14], "default_value", text="Steps")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[0], "default_value", text="Base Color")
                row = layout.row()
                row.label(text="Gradient Settings")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[1], "default_value", text="Top Value")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[17], "default_value", text="Colorize Top")
                row.prop(nodes["Base Gradient"].inputs[18], "default_value", text="Influence")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[4], "default_value", text="Bottom Value")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[15], "default_value", text="Colorize Bottom")
                row.prop(nodes["Base Gradient"].inputs[16], "default_value", text="Influence")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[8], "default_value", text="Gradient Location")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[9], "default_value", text="Gradient Rotation")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[10], "default_value", text="Gradient Scale")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[10], "default_value", text="Gradient Scale")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[7], "default_value", text="Painterly Distort")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[11], "default_value", text="Distort Scale (Uniform)")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[12], "default_value", text="Distort Scale")
                row = layout.row()
                row.prop(nodes["Base Gradient"].inputs[13], "default_value", text="Animate Distort")




#Panel

class ShaderPanel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Stylized Asset Suite"
    bl_label = "Stylized Asset Suite Lite Version by crzyzhaa"

    def draw(self, context):
        obj = bpy.context.active_object

        if not obj:
            return
        #check if empty
        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        #check too many redlightsas nodegroups
        count = 0
        for group in bpy.data.node_groups:
            if group.name.startswith("RedLightSAS"):
                count += 1
        if count > 1:
            return
        
        try:
            for node in obj.active_material.node_tree.nodes:
                if node.type == 'GROUP' and node.name.startswith("SAS Point Lights Group #1") and not node.node_tree.name == 'RedLightSAS':
                    return
        except:
            print('hello')

        #check if wisp light
        try:
            layout = self.layout
            if bpy.context.object.name.startswith("SAS Point Light Group #1"):
                row = layout.row()
                box = layout.box()
                row = box.row()
                row.label(text="SAS Point Light Group #1")
                node = bpy.data.node_groups['RedLightSAS']
                row = layout.row()
                light_data_name = obj.data.name
                row.prop(bpy.data.lights[light_data_name], "energy", text="POWER")
                row = layout.row()
                row.prop(bpy.data.lights[light_data_name], "use_shadow", text="Cast Shadows?")

                if node.nodes.get("Visibility") is not None:
                    # row = layout.row()
                    # row.prop(node.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    row = layout.row()
                    row.prop(node.nodes['zhaRange'], "interpolation_type", text="Blend Style")
                    if node.nodes['zhaRange'].interpolation_type == 'STEPPED':
                        row = layout.row()
                        row.prop(node.nodes['zhaXYZ3'].inputs[0], "default_value", text="Steps")
                    row = layout.row()
                    row.prop(node.nodes['zhaValue'].outputs[0], "default_value", text="Brightness")
                    row = layout.row()
                    row.prop(node.nodes['zhaHSV'].inputs[1], "default_value", text="Sat")
                    row.prop(node.nodes['zhaHSV'].inputs[0], "default_value", text="Hue")
                    row = layout.row()
                    row.prop(node.nodes['zhaMix'].inputs[7], "default_value", text="Color Tint")
                    row = layout.row()
                    row.prop(node.nodes['zhaMix'].inputs[0], "default_value", text="Color Tint Strength")
                    row = layout.row()
                    row.prop(node.nodes['zhaXYZ1'].inputs[0], "default_value", text="Spreading")
                    row.prop(node.nodes['zhaXYZ2'].inputs[0], "default_value", text="Sharpness")
                    row = layout.row()
                    row.prop(node.nodes['zhaRamp'].color_ramp.elements[0], "position", text="Occlude from Dark Areas (Increase This)")
                    row = layout.row()
                    row.prop(node.nodes['zhaRamp'].color_ramp.elements[1], "position", text="Sharpen Brighter Areas (Decrease This)")
                    return
        except:
            print('none')


        #material slots stuff
        layout = self.layout

        # row = layout.row()
        # row.prop(bpy.context.scene, "my_directory_enum", text="Hello")

        row = layout.row()
        row.template_ID(obj, "active_material", new="shaderaddon.objectsetup")
        row = layout.row()
        row.operator("shaderaddon.duplicatematerial", text="Make Material/Effects Single User Copy")
        row = layout.row()
        row.operator("object.material_slot_add", text="Add Material Slot")
        row.operator("object.material_slot_remove", text="Remove Material Slot")
        # Material slots management
        row = layout.row()
        row.template_list("MATERIAL_UL_matslots", "", obj, "material_slots", obj, "active_material_index")
        if bpy.context.mode == 'EDIT_MESH' or bpy.context.mode == 'EDIT_CURVE':
            row = layout.row()
            row.operator("object.material_slot_assign", text="Assign Material")
            row.operator("object.material_slot_select", text="Select Faces")
            row.operator("object.material_slot_deselect", text="Deselect Faces")

        if not obj.active_material:
            return

        try:
            row = layout.row()
            
            # row.prop(obj.active_material, "shadow_method", text="Shadow Mode")
            version = bpy.app.version
            if version < (4, 2, 0):
                row.prop(obj.active_material, "blend_method", text="Blend Mode")
                row.prop(obj.active_material, "shadow_method", text="Shadow Mode")
            else:
                row.prop(obj.active_material, "surface_render_method", text="Blend Mode")
                row.prop(obj, "visible_shadow", text="Cast Shadows")
            row.prop(obj.active_material, "show_transparent_back", text="Show Backface")
        except:
            row = layout.row()
            row.prop(obj.active_material, "blend_method", text="Blend Mode")
            row.prop(obj.active_material, "shadow_method", text="Shadow Mode")
            row.prop(obj.active_material, "show_transparent_back", text="Show Backface")


        #setup, removal
        row = self.layout.row()
        #row.operator("shaderaddon.objectsetup", text="Set Up SB Shader")
        row = self.layout.row()
        row.operator("shaderaddon.deletematerial", text="Fully Delete Selected Shader", icon='TRASH')
        # row = self.layout.row()
        # row.operator("shaderaddon.refreshmaterial", text="Refresh Drop Down Menus", icon='FILE_REFRESH')


        #check for steam/fog objects

        if bpy.context.object.active_material:
            if bpy.context.object.active_material.node_tree.nodes.get("SB Fog") is not None or bpy.context.object.active_material.name.startswith("SB Fog"):
                row = layout.row()
                box = layout.box()
                row = box.row()
                row.label(text="Fog")
                row = layout.row()
                fognode = bpy.context.object.active_material.node_tree.nodes.get("SB Fog")
                row.prop(fognode.inputs[0], "default_value", text="Scale (Uniform)")
                row = layout.row()
                row.prop(fognode.inputs[1], "default_value", text="Scale")
                row = layout.row()
                row.prop(fognode.inputs[7], "default_value", text="Fog Location")
                row = layout.row()
                row.prop(fognode.inputs[9], "default_value", text="Detail")
                row.prop(fognode.inputs[10], "default_value", text="Roughness")
                row = layout.row()
                row.prop(fognode.inputs[11], "default_value", text="Lacunarity")
                row.prop(fognode.inputs[12], "default_value", text="Distortion")
                row = layout.row()
                row.prop(fognode.inputs[2], "default_value", text="Clamp Fog (Min)")
                row = layout.row()
                row.prop(fognode.inputs[3], "default_value", text="Clamp Fog (Max)")
                row = layout.row()
                row.prop(fognode.inputs[4], "default_value", text="Color")
                row = layout.row()
                row.prop(fognode.inputs[5], "default_value", text="Mask Location")
                row = layout.row()
                row.prop(fognode.inputs[6], "default_value", text="Mask Clamp")
                row = layout.row()
                row.prop(fognode.inputs[8], "default_value", text="Mask Distortion")
                row = layout.row()
                row.prop(fognode.inputs[13], "default_value", text="Distort Location")
                row = layout.row()
                row.prop(fognode.inputs[13], "default_value", text="Distort Scale")
            if bpy.context.object.active_material.node_tree.nodes.get("SB Steam") is not None or bpy.context.object.active_material.name.startswith("SB Steam"):
                row = layout.row()
                box = layout.box()
                row = box.row()
                row.label(text="Steam")
                row = layout.row()
                steamnode = bpy.context.object.active_material.node_tree.nodes.get("SB Steam")
                row.prop(steamnode.inputs[0], "default_value", text="Color")
                row = layout.row()
                row.prop(steamnode.inputs[9], "default_value", text="Steam Location")
                row = layout.row()
                row.prop(steamnode.inputs[4], "default_value", text="Scale (Uniform)")
                row = layout.row()
                row.prop(steamnode.inputs[3], "default_value", text="Scale")
                row = layout.row()
                row.prop(steamnode.inputs[1], "default_value", text="Steam Fade")
                row = layout.row()
                row.prop(steamnode.inputs[5], "default_value", text="Detail")
                row = layout.row()
                row.prop(steamnode.inputs[6], "default_value", text="Roughness")
                row = layout.row()
                row.prop(steamnode.inputs[7], "default_value", text="Spreading")
                row = layout.row()
                row.prop(steamnode.inputs[8], "default_value", text="Bottom")
            if bpy.context.object.active_material.node_tree.nodes.get("SB Godrays") is not None or bpy.context.object.active_material.name.startswith("SB Godrays"):
                row = layout.row()
                box = layout.box()
                row = box.row()
                row.label(text="Godray")
                row = layout.row()
                godnode = bpy.context.object.active_material.node_tree.nodes.get("SB Godrays")
                row.prop(godnode.inputs[10], "default_value", text="Color")
                row = layout.row()
                row.prop(godnode.inputs[0], "default_value", text="Bottom Fade")
                row.prop(godnode.inputs[7], "default_value", text="Top Fade")
                row = layout.row()
                row.prop(godnode.inputs[1], "default_value", text="Center Loc")
                row = layout.row()
                row.prop(godnode.inputs[5], "default_value", text="Density 1")
                row.prop(godnode.inputs[3], "default_value", text="Density 2")
                row = layout.row()
                row.prop(godnode.inputs[2], "default_value", text="Clamp Spread")
                row = layout.row()
                row.prop(godnode.inputs[16], "default_value", text="Beam Detail")
                row = layout.row()
                row.label(text="---Dust&Detail---")
                row = layout.row()
                row.prop(godnode.inputs[12], "default_value", text="Enable Dust Particles?")
                if godnode.inputs[12].default_value > 0.01:
                    row = layout.row()
                    row.prop(godnode.inputs[13], "default_value", text="Particle Scale")
                    row.prop(godnode.inputs[15], "default_value", text="Particle Size")
                    row = layout.row()
                    row.prop(godnode.inputs[14], "default_value", text="Particle Location")
                row = layout.row()
                row.label(text="------Animation Settings-------")
                row = layout.row()
                row.prop(godnode.inputs[8], "default_value", text="Animation Seed")
                row = layout.row()
                row.prop(godnode.inputs[11], "default_value", text="Delay Between Fades")
                row = layout.row()
                row.prop(godnode.inputs[9], "default_value", text="Animate")




        if not obj or not obj.active_material:
            return
        

        #check nodes in chain
        nodes = obj.active_material.node_tree.nodes
        if not nodes or nodes[0].type != 'GROUP' or not nodes[0].node_tree.name.startswith("basecolor"):
            return
        

        row = layout.row()
        
        
        row.operator("shaderaddon.opensite", text="Check Out The Ukiyo Models & Animation Masterclass on ukiyogirls.io", icon='SCENE')
        row = layout.row()
        row.label(text='--------')
        row = layout.row()
        row.label(text="Build Your Stylized Shader", icon='WORLD_DATA')

        

        if not obj.active_material.name.startswith("Outline for"):
            #delete effect
            # row = layout.row()
            # row.prop(obj, "node_groups_enum", text="Delete Effect")
            # row.operator("shaderaddon.deleteeffect", text="Delete Effect")

            #view effect
            # row = layout.row()
            # row.prop(obj, "node_groups_enum_view", text="Viewing")

            # Add the drop-down menu
            row = layout.row()
            row.prop(context.scene, "my_operator_enum", text="Select Effect to Add")

            if context.scene.my_operator_enum == 'SPLRed' or context.scene.my_operator_enum == 'SPLGreen' or context.scene.my_operator_enum == 'SPLBlue':
                if obj.active_material.node_tree.nodes.get("Stylized Light (Dynamic) - #1") is None:
                    row = layout.row()
                    row.label(text="WARNING: You must have a Stylized Light Dynamic Effect Before Adding this ")

            if context.scene.my_operator_enum == 'BAKE':
                row = layout.row()
                row.label(text="------------")
                row = layout.row()
                row.label(text="Make Sure your Model is UV Unwrapped")
                row = layout.row()
                row.prop(context.scene, "bake_name", text="Bake Image Texture Name")
                row = layout.row()
                row.prop(context.scene, "user_input_number", text="Resolution")
                row = layout.row()
                row.label(text="Jobs Needed to be Performed:")
                
                for node in obj.active_material.node_tree.nodes:
                    if node.type == 'GROUP' and (node.node_tree.name.startswith("TransparentNoise") or node.node_tree.name.startswith("TransparentWorldStrokes")):
                            row = layout.row()
                            row.operator("shaderaddon.baketransparent", text="Bake Alpha (Transparency) - will be separate from final bake")
                            break
                breakvar = False
                for node in obj.active_material.node_tree.nodes:
                    if node.type == 'GROUP' and node.node_tree.name.startswith("SpecularRef"):
                        for subnode in node.node_tree.nodes:
                            if subnode.name == 'Glossy BSDF':
                                row = layout.row()
                                row.operator("shaderaddon.bakespecular", text="Bake Specular Reflection")
                for node in obj.active_material.node_tree.nodes:
                    if node.type == 'GROUP' and node.node_tree.name.startswith("AmbientOcclusion"):
                        for subnode in node.node_tree.nodes:
                            if subnode.name == 'Ambient Occlusion':
                                row = layout.row()
                                row.operator("shaderaddon.bakeao", text="Bake Ambient Occlusion")
                for node in obj.active_material.node_tree.nodes:
                    if node.type == 'GROUP' and node.node_tree.name.startswith("Diffuse"):
                        for subnode in node.node_tree.nodes:
                            if subnode.name == 'Diffuse BSDF':
                                row = layout.row()
                                row.prop(context.scene, "applied_sld", text="Apply Stylized Light (Dynamic) Upon Baking?")
                                row = layout.row()
                                row.operator("shaderaddon.bakediffuse", text="Bake Diffuse Lighting")
                row = layout.row()
                row.operator("shaderaddon.bakeall", text="Start Final Bake!")
                for node in obj.active_material.node_tree.nodes:
                    if node.type == 'GROUP' and node.node_tree.name.startswith("CrossHatch"):
                        row = layout.row()
                        row.label(text=f"WARNING: {node.name} is unbakeable, will be removed upon baking")
                    if node.type == 'GROUP' and node.node_tree.name.startswith("TransparentPaint"):
                        row = layout.row()
                        row.label(text=f"WARNING: {node.name} is unbakeable, will be removed upon baking")
                row = layout.row()
                row.label(text="---------")
                row = layout.row()
                row.operator("shaderaddon.saveimagetextures", text=f"Save & Export  '{bpy.context.scene.bake_name}'  Image Textures")
            elif context.scene.my_operator_enum == 'BAKEANIMATED':
                row = layout.row()
                row.prop(context.scene, "bake_name", text="Bake Image Texture Name")
                row = layout.row()
                row.prop(context.scene, "user_input_number", text="Resolution")
                # row = layout.row()
                # row.label(text="Jobs Needed to be Performed:")
                # for node in obj.active_material.node_tree.nodes:
                #     if node.type == 'GROUP' and node.node_tree.name.startswith("SpecularRef"):
                #         for subnode in node.node_tree.nodes:
                #             if subnode.name == 'Glossy BSDF':
                #                 row = layout.row()
                #                 row.operator("shaderaddon.bakespecular", text="Bake Specular Reflection")
                # for node in obj.active_material.node_tree.nodes:
                #     if node.type == 'GROUP' and node.node_tree.name.startswith("AmbientOcclusion"):
                #         for subnode in node.node_tree.nodes:
                #             if subnode.name == 'Ambient Occlusion':
                #                 row = layout.row()
                #                 row.operator("shaderaddon.bakeao", text="Bake Ambient Occlusion")
                row = layout.row()
                row.label(text="--------------")
                row = layout.row()
                row.prop(context.scene, "frame_start", text="Start Frame")
                row = layout.row()
                row.prop(context.scene, "frame_end", text="End Frame")
                row = layout.row()
                row.prop(context.scene, "light_animate_enum", text="Animated Diffuse Light?")
                row = layout.row()
                row.prop(context.scene, "specular_animate_enum", text="Animated Specular Reflection?")
                row = layout.row()
                row.prop(context.scene, "processing_speed", text="Processing Speed (Use Higher Value for Worse CPUs, lower for better ones)")
                row = layout.row()
                row.operator("shaderaddon.bakeanimationprotocol", text="Start Final Bake!")
                for node in obj.active_material.node_tree.nodes:
                    if node.type == 'GROUP' and node.node_tree.name.startswith("CrossHatch"):
                        row = layout.row()
                        row.label(text=f"WARNING: {node.name} is unbakeable, will be removed upon baking")
                    if node.type == 'GROUP' and node.node_tree.name.startswith("TransparentPaint"):
                        row = layout.row()
                        row.label(text=f"WARNING: {node.name} is unbakeable, will be removed upon baking")
                row = layout.row()
                row.label(text="---------")
                row = layout.row()
                row.operator("shaderaddon.saveimagetextures", text=f"Save & Export  '{bpy.context.scene.bake_name}'  Image Textures")
            elif context.scene.my_operator_enum == 'BAKENORMALS':
                row = layout.row()
                row.prop(context.scene, "bake_name", text="Bake Image Texture Name")
                row = layout.row()
                row.prop(context.scene, "user_input_number", text="Resolution")
                row = layout.row()
                row.label(text="Bake Normals Requires Stylized Light (Main) Effect")
                for node in obj.active_material.node_tree.nodes:
                    if node.type == 'GROUP' and node.node_tree.name.startswith("Diffuse"): 
                        row = layout.row()
                        row.operator("shaderaddon.bakenormals", text="Start Final Bake!")
                        break

                if nodes.get('NormalsTextureHelper') is not None:
                    row = layout.row()
                    if nodes.get("Material Output").inputs['Surface'].links[0].from_node.name == 'NormalsTextureHelper':
                        row.operator("shaderaddon.normalspaint", text="Stop Painting Normals")
                    else:
                        row.operator("shaderaddon.normalspaint", text="Paint Normals")
                
            else:
                # Add a button to execute the selected operator
                row = layout.row()
                row.operator("shaderaddon.execute_operator", text="Add Effect")


        # is_show = False
        # if obj.node_groups_enum_view == 'SHOWALL':
        #     is_show = True

        #start traversal
        node = nodes[0]
        nodecount = 0
        while node:
            if node.type == 'OUTPUT_MATERIAL':
                break
            if node.type == 'GROUP':
                nodecount += 1
                group_name = node.name
                prop_name = f"show_{group_name}_section"
                box = layout.box()
                row = box.row()
                row.prop(node, "use_custom_color", text="", icon="TRIA_DOWN" if node.use_custom_color else "TRIA_RIGHT", emboss=False)
                row.label(text=group_name)

                if node.name == 'Base Color':
                    if node.use_custom_color:
                        rgb_node = None
                        for nestednode in node.node_tree.nodes:
                            if nestednode.type == 'RGB':
                                rgb_node = nestednode
                                break
                        if rgb_node.outputs[0].links[0].to_node.name != 'Group Output':
                            return
                        row = layout.row()
                        row.prop(rgb_node.outputs[0], "default_value", text="Base Color")
                        row = layout.row()
                        

                if node.name == 'Outline Color':
                    if node.use_custom_color:
                        row = layout.row()
                        rgb_node2 = node.node_tree.nodes['RGB']
                        row.prop(rgb_node2.outputs[0], "default_value", text="Outline Color")
                        outlinemodifier = None
                        for modifier in obj.modifiers:
                            if modifier.name.startswith("SB Outline"):
                                outlinemodifier = modifier
                                break

                        row = layout.row()
                        row.prop(outlinemodifier, "thickness", text="Thickness")
                        row = layout.row()
                        row.prop(outlinemodifier, "vertex_group", text="Vertex Group")

                if node.node_tree.name.startswith("LocalGradient"):
                    lgdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    lgdupe.arg1 = node.name
                    localgradienttrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    localgradienttrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Gradient Color")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["realmix"], "blend_type", text="Blending Mode")
                        row = layout.row()
                        row.prop(node.inputs[18], "default_value", text="INVERT?")
                        maprange = node.node_tree.nodes["Map Range"]
                        row = layout.row()
                        row.prop(maprange, "interpolation_type", text="Gradient Style")
                        row = layout.row()
                        row.prop(node.inputs[12], "default_value", text="Toon Steps")

                        #painterly stuff
                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown1"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown1"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Painterly/Distort Settings")
                                
                            if node.node_tree.nodes["DropDown1"].use_custom_color:
                                row = layout.row()
                                distortmix = node.node_tree.nodes["DistortMix"]
                                row.prop(node.inputs[8], "default_value", text="Painterly Effect/Distort")
                                row = layout.row()
                                row.prop(node.inputs[17], "default_value", text="Noise/Voronoi Switch")
                                row = layout.row()
                                row.prop(node.inputs[9], "default_value", text="Painterly Distory Scale")
                                row = layout.row()
                                row.prop(node.inputs[16], "default_value", text="Painterly Scale (Uniform)")
                                
                                row = layout.row()
                                row.prop(node.inputs[10], "default_value", text="Painterly Location")
                        except:
                            row = layout.row()
                            distortmix = node.node_tree.nodes["DistortMix"]
                            row.prop(node.inputs[8], "default_value", text="Painterly Effect/Distort")
                            row = layout.row()
                            row.prop(node.inputs[17], "default_value", text="Noise/Voronoi Switch")
                            row = layout.row()
                            row.prop(node.inputs[9], "default_value", text="Painterly Distory Scale")
                            row = layout.row()
                            row.prop(node.inputs[16], "default_value", text="Painterly Scale (Uniform)")
                            
                            row = layout.row()
                            row.prop(node.inputs[10], "default_value", text="Painterly Location")


                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown2"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown2"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Texture Coordinate Settings")
                            if node.node_tree.nodes["DropDown2"].use_custom_color:
                                #COORDINATES stuff
                                row = layout.row()
                                row.prop(node.inputs[13], "default_value", text="Gradient Location")
                                row = layout.row()
                                row.prop(node.inputs[14], "default_value", text="Gradient Rotation")
                                row = layout.row()
                                row.prop(node.inputs[15], "default_value", text="Gradient Scale")
                                row = layout.row()
                                row.prop(node.inputs[23], "default_value", text="Clamp")
                                row = layout.row()
                                row.prop(node.inputs[4], "default_value", text="Object Coordinates (Default) %")
                                row = layout.row()
                                row.prop(node.inputs[6], "default_value", text="UV Coordinates %")
                        except:
                            #COORDINATES stuff
                            row = layout.row()
                            row.label(text="------Texture Coordinate Settings-----")
                            row = layout.row()
                            row.prop(node.inputs[13], "default_value", text="Gradient Location")
                            row = layout.row()
                            row.prop(node.inputs[14], "default_value", text="Gradient Rotation")
                            row = layout.row()
                            row.prop(node.inputs[15], "default_value", text="Gradient Scale")
                            row = layout.row()
                            row.prop(node.inputs[23], "default_value", text="Clamp")
                            row = layout.row()
                            row.prop(node.inputs[4], "default_value", text="Object Coordinates (Default) %")
                            row = layout.row()
                            row.prop(node.inputs[6], "default_value", text="UV Coordinates %")

                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown3"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown3"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Mask Settings")
                            if node.node_tree.nodes["DropDown3"].use_custom_color:
                                row = layout.row()
                                row.template_ID(node.node_tree.nodes["Image Texture"], "image", new="image.new", open="image.open", text="Mask")
                                row = layout.row()
                                row.prop(node.inputs[19], "default_value", text="Enable Mask?")
                                if node.inputs[19].default_value > 0.01:
                                    row = layout.row()
                                    row.prop(node.inputs[21], "default_value", text="Mask Location")
                                    row = layout.row()
                                    row.prop(node.inputs[20], "default_value", text="Mask Scale")
                                    row = layout.row()
                                    row.prop(node.inputs[22], "default_value", text="Mask Rotation")
                        except:
                            row = layout.row()
                            row.template_ID(node.node_tree.nodes["Image Texture"], "image", new="image.new", open="image.open", text="Mask")
                            row = layout.row()
                            row.prop(node.inputs[19], "default_value", text="Enable Mask?")
                            if node.inputs[19].default_value > 0.01:
                                row = layout.row()
                                row.prop(node.inputs[21], "default_value", text="Mask Location")
                                row = layout.row()
                                row.prop(node.inputs[20], "default_value", text="Mask Scale")
                                row = layout.row()
                                row.prop(node.inputs[22], "default_value", text="Mask Rotation")

                        #find texture coordinate node
                        tex_coord_node = node.node_tree.nodes["ZhaTexture Coordinate"]
                        
                        # row = layout.row()
                        # row.prop(node.inputs[7], "default_value", text="Window Coordinates %")
                        row = layout.row()
                        row.prop(tex_coord_node, "object", text="Gradient Object")
                        
                
                if node.node_tree.name.startswith("CrossHatch"):
                    # chdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    # chdupe.arg1 = node.name
                    crosshatchtrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    crosshatchtrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        maprange2 = node.node_tree.nodes["Map Range"]
                        row = layout.row()
                        row.prop(maprange2, "interpolation_type", text="Blend Style")
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Light Slider/Controller")
                        row = layout.row()
                        row.prop(node.inputs[6], "default_value", text="Toon Steps")
                        row = layout.row()
                        row.label(text="----Highlight Settings----")
                        row = layout.row()
                        row.prop(node.inputs[3], "default_value", text="Light Value")
                        row = layout.row()
                        row.prop(node.inputs[21], "default_value", text="Colorize Highlight")
                        row = layout.row()
                        row.prop(node.inputs[23], "default_value", text="Colorize Highlight Influence")
                        row = layout.row()
                        row.label(text="----Shadow Settings----")
                        row = layout.row()
                        row.prop(node.inputs[9], "default_value", text="Shadow Value")
                        row = layout.row()
                        row.prop(node.inputs[20], "default_value", text="Colorize Shadow")
                        row = layout.row()
                        row.prop(node.inputs[22], "default_value", text="Colorize Shadow Influence")
                        row = layout.row()
                        row.label(text="---Crosshatch Settings---")
                        row = layout.row()
                        row.prop(node.inputs[10], "default_value", text="Crosshatch Strength")
                        row = layout.row()
                        row.prop(node.inputs[12], "default_value", text="Scale (Uniform)")
                        row = layout.row()
                        row.prop(node.inputs[14], "default_value", text="Location")
                        row = layout.row()
                        row.prop(node.inputs[15], "default_value", text="Detail")
                        row = layout.row()
                        row.prop(node.inputs[16], "default_value", text="Roughness")
                        row = layout.row()
                        row.label(text="---Dotted Tone Settings---")
                        row = layout.row()
                        row.prop(node.inputs[30], "default_value", text="Enable Dotted Tone?")
                        if node.inputs[30].default_value > 0.01:
                            row = layout.row()
                            row.prop(node.inputs[31], "default_value", text="Invert?")
                            row = layout.row()
                            row.prop(node.inputs[32], "default_value", text="Scale (Uniform)")
                            row = layout.row()
                            row.prop(node.inputs[35], "default_value", text="Scale")
                            row = layout.row()
                            row.prop(node.inputs[33], "default_value", text="Dot Randomness")
                            row = layout.row()
                            row.prop(node.inputs[34], "default_value", text="Detail")
                            row = layout.row()
                            row.prop(node.inputs[36], "default_value", text="Dot Clamp")
                        row = layout.row()
                        row.label(text="------------------")
                        row = layout.row()
                        row.prop(node.inputs[24], "default_value", text="UV Coords")
                        row = layout.row()
                        row.prop(node.inputs[25], "default_value", text="Window Coords")
                        # row = layout.row()
                        # row.template_ID(node.node_tree.nodes["Normal"], "image", new="image.new", open="image.open", text="Normal Map")
                        # row = layout.row()
                        # row.prop(node.inputs[18], "default_value", text="Enable Normal Map?")
                        # row = layout.row()
                        # row.prop(node.inputs[19], "default_value", text="Normal Map Strength")
                        # row = layout.row()
                        # row.prop(node.inputs[26], "default_value", text="Map Location")
                        # row = layout.row()
                        # row.prop(node.inputs[26], "default_value", text="Map Rotation")
                        # row = layout.row()
                        # row.prop(node.inputs[26], "default_value", text="Map Scale")
                        if node.node_tree.nodes.get("Diffuse BSDF") is None:
                            row = layout.row()
                            row.operator("shaderaddon.unbakediffuse", text="Unbake Diffuse Lighting")

                if node.node_tree.name.startswith("DiffuseLight") or node.node_tree.name.startswith("AppliedDiff"):
                    # dldupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    # dldupe.arg1 = node.name
                    diffusetrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    diffusetrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        maprange2 = node.node_tree.nodes["Map Range"]
                        row = layout.row()
                        row.prop(maprange2, "interpolation_type", text="Blend Style")
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Light Slider/Controller")
                        try:
                            if maprange2.interpolation_type == 'LINEAR':
                                row = layout.row()
                                row.prop(node.inputs[42], "default_value", text="Sharpen Light")
                        except:
                            row = layout.row()
                        if maprange2.interpolation_type != 'LINEAR':
                            row = layout.row()
                            row.prop(node.inputs[6], "default_value", text="Toon Steps")
                        
                        if 1+1 == 2:
                            row = layout.row()
                            row.prop(node.inputs[30], "default_value", text="Darken Edge")
                            row.prop(node.inputs[29], "default_value", text="Distance")

                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown1"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown1"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Highlight Settings")
                            
                            if node.node_tree.nodes["DropDown1"].use_custom_color:
                                row = layout.row()
                                row.label(text="----Highlight Settings----")
                                row = layout.row()
                                row.prop(node.inputs[3], "default_value", text="Light Value")
                                row = layout.row()
                                row.prop(node.inputs[21], "default_value", text="Colorize Highlight")
                                row = layout.row()
                                row.prop(node.inputs[23], "default_value", text="Colorize Highlight Influence")
                                row = layout.row()
                                row.prop(node.inputs[1], "default_value", text="Hue")
                                row.prop(node.inputs[2], "default_value", text="Saturation")
                                row = layout.row()
                                row.prop(node.inputs[44], "default_value", text="Subsurface")
                        except:
                            row = layout.row()
                            row.label(text="----Highlight Settings----")
                            row = layout.row()
                            row.prop(node.inputs[3], "default_value", text="Light Value")
                            row = layout.row()
                            row.prop(node.inputs[21], "default_value", text="Colorize Highlight")
                            row = layout.row()
                            row.prop(node.inputs[23], "default_value", text="Colorize Highlight Influence")
                            row = layout.row()
                            row.prop(node.inputs[1], "default_value", text="Hue")
                            row.prop(node.inputs[2], "default_value", text="Saturation")
                        
                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown2"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown2"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Shadow Settings")
                            if node.node_tree.nodes["DropDown2"].use_custom_color:
                                row = layout.row()
                                row.prop(node.inputs[9], "default_value", text="Shadow Value")
                                row = layout.row()
                                row.prop(node.inputs[20], "default_value", text="Colorize Shadow")
                                row = layout.row()
                                row.prop(node.inputs[22], "default_value", text="Colorize Shadow Influence")
                                row = layout.row()
                                row.prop(node.inputs[7], "default_value", text="Hue")
                                row.prop(node.inputs[8], "default_value", text="Saturation")
                        except:
                            row = layout.row()
                            row.label(text="----Shadow Settings----")
                            row = layout.row()
                            row.prop(node.inputs[9], "default_value", text="Shadow Value")
                            row = layout.row()
                            row.prop(node.inputs[20], "default_value", text="Colorize Shadow")
                            row = layout.row()
                            row.prop(node.inputs[22], "default_value", text="Colorize Shadow Influence")
                            row = layout.row()
                            row.prop(node.inputs[7], "default_value", text="Hue")
                            row.prop(node.inputs[8], "default_value", text="Saturation")

                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown9"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown9"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Bounced Light Settings")
                            if node.node_tree.nodes["DropDown9"].use_custom_color:
                                row = layout.row()
                                row.operator("shaderaddon.opensite", text="Please Upgrade to Pro or Join the Ukiyo Masterclass to Use this.")
                        except:
                            print('HI')
                        
                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown3"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown3"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Rim Light Settings")
                            if node.node_tree.nodes["DropDown3"].use_custom_color:
                                # row = layout.row()
                                # row.label(Text="Upgrade to Pro to use this feature")
                                row = layout.row()
                                row.prop(node.inputs[45], "default_value", text="Enable Rim Light (Only Anime Style)")
                                row = layout.row()
                                row.prop(node.inputs[43], "default_value", text="Rim Light Color")
                                row = layout.row()
                                row.prop(node.inputs[50], "default_value", text="Size")
                                row = layout.row()
                                row.prop(node.inputs[47], "default_value", text="Rim Light Spreading")
                                row = layout.row()
                                row.prop(node.inputs[51], "default_value", text="Softness")
                        except:
                            print("hi")
                            
                        # try:
                        #     row = layout.row()
                        #     row.prop(node.inputs[43], "default_value", text="Rim Light Color")
                        #     row = layout.row()
                        #     row.prop(node.inputs[44], "default_value", text="Subsurface")
                        #     row = layout.row()
                        #     row.prop(node.inputs[45], "default_value", text="ENable Rim Light")
                        #     row = layout.row()
                        #     row.prop(node.inputs[46], "default_value", text="ENable Metallic")
                        #     row = layout.row()
                        #     row.prop(node.inputs[47], "default_value", text="Rim Light Spreading")
                        #     row = layout.row()
                        #     row.prop(node.inputs[48], "default_value", text="Metallic Steps")
                        #     row = layout.row()
                        #     row.prop(node.inputs[49], "default_value", text="Metallic Spreading")
                        # except:
                        #     row = layout.row()

                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown4"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown4"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Metallic Settings")
                            if node.node_tree.nodes["DropDown4"].use_custom_color:
                                row = layout.row()
                                row.prop(node.inputs[46], "default_value", text="Metallic %")
                                row = layout.row()
                                row.prop(node.inputs[48], "default_value", text="Metallic Steps")
                                row = layout.row()
                                row.prop(node.inputs[49], "default_value", text="Metallic Spreading")
                        except:
                            print("hi")
                        
                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown5"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown5"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Distort Settings")
                            if node.node_tree.nodes["DropDown5"].use_custom_color:
                                row = layout.row()
                                row.prop(node.inputs[10], "default_value", text="Distort Strength")
                                row = layout.row()
                                row.prop(node.inputs[11], "default_value", text="Noise/Voronoi Switch")
                                row = layout.row()
                                row.prop(node.inputs[12], "default_value", text="Scale (Uniform)")
                                row = layout.row()
                                row.prop(node.inputs[13], "default_value", text="Scale")
                                row = layout.row()
                                row.prop(node.inputs[17], "default_value", text="Rotation")
                                row = layout.row()
                                row.prop(node.inputs[14], "default_value", text="Location")
                                row = layout.row()
                                row.prop(node.inputs[15], "default_value", text="Detail")
                                row = layout.row()
                                row.prop(node.inputs[16], "default_value", text="Roughness")
                                row = layout.row()
                                row.prop(node.inputs[24], "default_value", text="Use Object Coords (Distortion)")
                                row = layout.row()
                                row.prop(node.inputs[25], "default_value", text="Use UV Coords (Distortion)")
                        except:
                            row = layout.row()
                            row.label(text="Distort Settings")
                            row = layout.row()
                            row.prop(node.inputs[10], "default_value", text="Distort Strength")
                            row = layout.row()
                            row.prop(node.inputs[11], "default_value", text="Noise/Voronoi Switch")
                            row = layout.row()
                            row.prop(node.inputs[12], "default_value", text="Scale (Uniform)")
                            row = layout.row()
                            row.prop(node.inputs[13], "default_value", text="Scale")
                            row = layout.row()
                            row.prop(node.inputs[17], "default_value", text="Rotation")
                            row = layout.row()
                            row.prop(node.inputs[14], "default_value", text="Location")
                            row = layout.row()
                            row.prop(node.inputs[15], "default_value", text="Detail")
                            row = layout.row()
                            row.prop(node.inputs[16], "default_value", text="Roughness")
                            row = layout.row()
                        
                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown6"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown6"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Painterly Effect Settings")
                            if node.node_tree.nodes["DropDown6"].use_custom_color:
                                if 1+1 == 2:
                                    row.label(text="-------PAINTERLY EFFECT--------")
                                    row = layout.row()
                                    row.prop(node.inputs[31], "default_value", text="Enable Painterly Effect?")
                                    if node.inputs[31].default_value > 0.01:
                                        row = layout.row()
                                        row.prop(node.inputs[41], "default_value", text="Stroke Scale (Uniform)")
                                        row = layout.row()
                                        row.prop(node.inputs[33], "default_value", text="Stroke Scale")
                                        row = layout.row()
                                        row.prop(node.inputs[34], "default_value", text="Distort #1")
                                        row.prop(node.inputs[40], "default_value", text="Distort #2")
                                        row = layout.row()
                                        row.prop(node.inputs[35], "default_value", text="Smooth Strokes")
                                        row.prop(node.inputs[36], "default_value", text="Strokes Contrast")
                                        row = layout.row()
                                        row.template_ID(node.node_tree.nodes["Image Texture"], "image", new="image.new", open="image.open", text="Strokes Map")
                                        row = layout.row()
                                        row.prop(node.inputs[37], "default_value", text="Strokes Map Scale")
                                        try:
                                            row = layout.row()
                                            row.label(text="Extra Breakups")
                                            row.prop(node.inputs[52], "default_value", text=" ")
                                            row.prop(node.inputs[53], "default_value", text=" ")
                                        except:
                                            print('none')
                        except:
                            row.label(text="-------PAINTERLY EFFECT--------")
                            row = layout.row()
                            row.prop(node.inputs[31], "default_value", text="Enable Painterly Effect?")
                            if node.inputs[31].default_value > 0.01:
                                row = layout.row()
                                row.prop(node.inputs[41], "default_value", text="Stroke Scale (Uniform)")
                                row = layout.row()
                                row.prop(node.inputs[33], "default_value", text="Stroke Scale")
                                row = layout.row()
                                row.prop(node.inputs[34], "default_value", text="Distort #1")
                                row.prop(node.inputs[40], "default_value", text="Distort #2")
                                row = layout.row()
                                row.prop(node.inputs[35], "default_value", text="Smooth Strokes")
                                row.prop(node.inputs[36], "default_value", text="Strokes Contrast")
                                row = layout.row()
                                row.template_ID(node.node_tree.nodes["Image Texture"], "image", new="image.new", open="image.open", text="Strokes Map")
                                row = layout.row()
                                row.prop(node.inputs[37], "default_value", text="Strokes Map Scale")

                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown7"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown7"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Coordinates & Normal Maps")
                            if node.node_tree.nodes["DropDown7"].use_custom_color:
                                row = layout.row()
                                row.template_ID(node.node_tree.nodes["Normal"], "image", new="image.new", open="image.open", text="Normal Map")
                                row = layout.row()
                                row.prop(node.inputs[18], "default_value", text="Enable Normal Map?")
                                if node.inputs[18].default_value > 0.01:
                                    row = layout.row()
                                    row.prop(node.inputs[19], "default_value", text="Normal Map Strength")
                                    row = layout.row()
                                    row.prop(node.inputs[26], "default_value", text="Map Location")
                                    row = layout.row()
                                    row.prop(node.inputs[27], "default_value", text="Map Rotation")
                                    row = layout.row()
                                    row.prop(node.inputs[28], "default_value", text="Map Scale")
                        except:
                            row = layout.row()
                            row.label(text="----------------------")
                            row = layout.row()
                            row.prop(node.inputs[24], "default_value", text="Object Coords (Bump)")
                            row = layout.row()
                            row.prop(node.inputs[25], "default_value", text="UV Coords (Bump)")
                            row = layout.row()
                            row.template_ID(node.node_tree.nodes["Normal"], "image", new="image.new", open="image.open", text="Normal Map")
                            row = layout.row()
                            row.prop(node.inputs[18], "default_value", text="Enable Normal Map?")
                            if node.inputs[18].default_value > 0.01:
                                row = layout.row()
                                row.prop(node.inputs[19], "default_value", text="Normal Map Strength")
                                row = layout.row()
                                row.prop(node.inputs[26], "default_value", text="Map Location")
                                row = layout.row()
                                row.prop(node.inputs[27], "default_value", text="Map Rotation")
                                row = layout.row()
                                row.prop(node.inputs[28], "default_value", text="Map Scale")
                        
                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown8"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown8"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Masks")
                            if node.node_tree.nodes["DropDown8"].use_custom_color:
                                row = layout.row()
                                row.label(text="Masks")
                                row = layout.row()
                                row.template_ID(node.node_tree.nodes["SubtractLight"], "image", new="image.new", open="image.open", text="Remove Light")
                                row.prop(node.inputs[39], "default_value", text="Enable?")
                                row = layout.row()
                                row.template_ID(node.node_tree.nodes["AddLight"], "image", new="image.new", open="image.open", text="Add Light")
                                row.prop(node.inputs[38], "default_value", text="Enable?")
                        except:
                            row = layout.row()
                            row.label(text="Masks")
                            row = layout.row()
                            row.template_ID(node.node_tree.nodes["SubtractLight"], "image", new="image.new", open="image.open", text="Remove Light")
                            row.prop(node.inputs[39], "default_value", text="Enable?")
                            row = layout.row()
                            row.template_ID(node.node_tree.nodes["AddLight"], "image", new="image.new", open="image.open", text="Add Light")
                            row.prop(node.inputs[38], "default_value", text="Enable?")
                        
                        if node.node_tree.nodes.get("Diffuse BSDF") is None and not node.node_tree.name.startswith("AppliedDiff"):
                            row = layout.row()
                            row.operator("shaderaddon.unbakediffuse", text="Unbake Diffuse Lighting")

                if node.node_tree.name.startswith("SpecularReflection"):
                    return
                
                
                if node.node_tree.name.startswith("EdgeDetect"):
                    return
                    

                if node.node_tree.name.startswith("ColoredEdges"):
                    return
                    

                if node.node_tree.name.startswith("SunObject"):
                    # sodupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    # sodupe.arg1 = node.name
                    sunobjecttrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    sunobjecttrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.node_tree.nodes["Map Range"], "interpolation_type", text="Style")
                        row = layout.row()
                        row.prop(node.inputs[6], "default_value", text="Steps")
                        # last_character = node.name[-1]
                        # number = int(last_character)
                        for modifier in obj.modifiers:
                            if modifier.name.startswith("SB Sun"):
                                if node.node_tree.nodes["Attribute"].attribute_name != modifier.node_group.nodes["Store Named Attribute"].inputs[2].default_value:
                                    continue
                                number = 0
                                if number == 0:
                                    subd = modifier.node_group.nodes["Subdivision Surface"]
                                    row = layout.row()
                                    row.prop(subd.inputs[1], "default_value", text="Subdivision Surface Levels")
                                    row = layout.row()
                                    row.prop(modifier.node_group.nodes["Subdivide Mesh"].inputs[1], "default_value", text="Subdivide Mesh")
                                    row = layout.row()
                                    row.prop(modifier.node_group.nodes["Combine XYZ"].inputs[0], "default_value", text="X Sun Direction")
                                    row = layout.row()
                                    row.prop(modifier.node_group.nodes["Combine XYZ"].inputs[1], "default_value", text="Y Sun Direction")
                                    row = layout.row()
                                    row.prop(modifier.node_group.nodes["Combine XYZ"].inputs[2], "default_value", text="Z Sun Direction")
                        row = layout.row()
                        row.prop(node.inputs[7], "default_value", text="Shadow Value")
                        row = layout.row()
                        row.prop(node.inputs[8], "default_value", text="Highlight Value")
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Strength (Chaotic)")
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Strength (Stable)")
                        row = layout.row()
                        row.prop(node.inputs[13], "default_value", text="Shadow Colorize")
                        row = layout.row()
                        row.prop(node.inputs[14], "default_value", text="Shadow Colorize Strength")
                        row = layout.row()
                        row.prop(node.inputs[15], "default_value", text="Highlight Colorize")
                        row = layout.row()
                        row.prop(node.inputs[16], "default_value", text="Highlight Colorize Strength")
                        row = layout.row()
                        row.prop(node.inputs[9], "default_value", text="Shadow Hue")
                        row = layout.row()
                        row.prop(node.inputs[10], "default_value", text="Shadow Saturation")
                        row = layout.row()
                        row.prop(node.inputs[11], "default_value", text="Highlight Hue")
                        row = layout.row()
                        row.prop(node.inputs[12], "default_value", text="Highlight Saturation")
                        row = layout.row()
                        row.prop(node.inputs[5], "default_value", text="Roughness")
                        row.template_ID(node.node_tree.nodes["Image Texture"], "image", new="image.new", open="image.open", text="Mask")
                        row = layout.row()
                        row.prop(node.inputs[17], "default_value", text="Enable Mask?")


                if node.node_tree.name.startswith("LightObject"):
                    # lodupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    # lodupe.arg1 = node.name
                    lightobjecttrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    lightobjecttrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        # row = layout.row()
                        # row.prop(node.inputs[9], "default_value", text="Light Range")
                        # last_character = node.name[-1]
                        # number = int(last_character)
                        row = layout.row()
                        row.prop(node.node_tree.nodes["Map Range"], "interpolation_type", text="Style")
                        try:
                            for modifier in obj.modifiers:
                                if modifier.name.startswith("SB Geono"):
                                    if node.node_tree.nodes["Attribute"].attribute_name != modifier.node_group.nodes["Store Named Attribute"].inputs[2].default_value:
                                        continue
                                    number = 0
                                    if number == 0:
                                        row = layout.row()
                                        row.prop(modifier.node_group.nodes["IMPORTANT MATH"].inputs[1], "default_value", text="Light Slider")
                                        if node.node_tree.nodes["Map Range"].interpolation_type == 'LINEAR':
                                            row = layout.row()
                                            row.prop(node.inputs[12], "default_value", text="Sharpness")
                                        else:
                                            row = layout.row()
                                            row.prop(node.inputs[7], "default_value", text="Steps")
                                        row = layout.row()
                                        row.prop(modifier.node_group.nodes["Subdivision Surface"].inputs[1], "default_value", text="Subdivison Surface Levels")
                                        row = layout.row()
                                        row.prop(modifier.node_group.nodes["Subdivide Mesh"].inputs[1], "default_value", text="Subdivide Mesh Levels")
                                        row = layout.row()
                                        row.prop(modifier.node_group.nodes["Object Info"].inputs[0], "default_value", text="Light Object (must be a mesh)")
                        except:
                            joe = 'lol'

                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown2"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown2"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Highlight Settings")
                        if node.node_tree.nodes["DropDown2"].use_custom_color:
                            row = layout.row()
                            row.prop(node.inputs[1], "default_value", text="Highlight Value")
                            row = layout.row()
                            row.prop(node.inputs[13], "default_value", text="Colorize Highlight")
                            row = layout.row()
                            row.prop(node.inputs[14], "default_value", text="Colorize Highlight")
                            row = layout.row()
                            row.prop(node.inputs[2], "default_value", text="Hue")
                            row.prop(node.inputs[3], "default_value", text="Sat")


                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown1"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown1"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Shadow Settings")
                        if node.node_tree.nodes["DropDown1"].use_custom_color:
                            
                            row = layout.row()
                            row.prop(node.inputs[4], "default_value", text="Shadow Value")
                            row = layout.row()
                            row.prop(node.inputs[16], "default_value", text="Colorize Shadow")
                            row = layout.row()
                            row.prop(node.inputs[17], "default_value", text="Colorize Shadow Influence")
                            row = layout.row()
                            row.prop(node.inputs[5], "default_value", text="Hue")
                            row.prop(node.inputs[6], "default_value", text="Sat")

                        
                        
                        # row = layout.row()
                        # row.prop(node.inputs[8], "default_value", text="Roughness")
                        # row = layout.row()
                        
                        # row.prop(node.inputs[10], "default_value", text="Strength (Chaotic)")
                        # last_character = node.name[-1]
                        # number = int(last_character)
                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown3"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown3"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Painterly Settings")
                        if node.node_tree.nodes["DropDown3"].use_custom_color:
                            try:
                                for modifier in obj.modifiers:
                                    if modifier.name.startswith("SB Geono"):
                                        if node.node_tree.nodes["Attribute"].attribute_name != modifier.node_group.nodes["Store Named Attribute"].inputs[2].default_value:
                                            continue
                                        number = 0
                                        if number == 0:
                                            # row = layout.row()
                                            # row.prop(modifier.node_group.nodes["Object Info"].inputs[0], "default_value", text="Light Object (must be a mesh)")
                                            # row = layout.row()
                                            # row.prop(modifier.node_group.nodes["Mix"].inputs[0], "default_value", text="Distort")
                                            # row = layout.row()
                                            # row.prop(modifier.node_group.nodes["Noise Texture"].inputs[2], "default_value", text="Scale")
                                            # row = layout.row()
                                            # row.prop(modifier.node_group.nodes["Noise Texture"].inputs[3], "default_value", text="Detail")
                                            # row = layout.row()
                                            # row.prop(modifier.node_group.nodes["Noise Texture"].inputs[4], "default_value", text="Roughness")
                                            row = layout.row()
                                            row = layout.row()
                                            row.prop(modifier.node_group.nodes["painterlymix"].inputs[0], "default_value", text="Enable Painterly Effect?")
                                            if modifier.node_group.nodes["painterlymix"].inputs[0].default_value > 0.01:
                                                row = layout.row()
                                                row.label(text="------PAINTERLY EFFECT------")
                                                row = layout.row()
                                                row.prop(modifier.node_group.nodes["Voronoi Texture"].inputs[2], "default_value", text="Scale")
                                                row = layout.row()
                                                row.prop(modifier.node_group.nodes["Mix.002"].inputs[0], "default_value", text="Breakup")
                                                row = layout.row()
                                                row.prop(modifier.node_group.nodes["timmy"].inputs[2], "default_value", text="Breakup 2")
                                                row = layout.row()
                                                row.label(text="-----------------------------")
                            except:
                                joe = 'lasoutis'
                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown4"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown4"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Mask Settings")
                        if node.node_tree.nodes["DropDown4"].use_custom_color:
                            row = layout.row()
                            row.template_ID(node.node_tree.nodes["Image Texture"], "image", new="image.new", open="image.open", text="Remove Light")
                            row = layout.row()
                            row.prop(node.inputs[15], "default_value", text="Enable Mask?")
                            try:
                                row = layout.row()
                                row.template_ID(node.node_tree.nodes["ImgTex2"], "image", new="image.new", open="image.open", text="Add Light")
                                row = layout.row()
                                row.prop(node.inputs[18], "default_value", text="Enable Mask?")
                            except:
                                print("DONE")






                if node.node_tree.name.startswith("CircularLight"):
                    return
                
                if node.node_tree.name.startswith("RedLightSAS"):
                    redlightdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    redlightdupe.arg1 = node.name
                    redlighttrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    redlighttrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.node_tree.nodes['zhaRange'], "interpolation_type", text="Blend Style")
                        if node.node_tree.nodes['zhaRange'].interpolation_type == 'STEPPED':
                            row = layout.row()
                            row.prop(node.node_tree.nodes['zhaXYZ3'].inputs[0], "default_value", text="Steps")
                        row = layout.row()
                        row.prop(node.node_tree.nodes['zhaValue'].outputs[0], "default_value", text="Brightness")
                        row = layout.row()
                        row.prop(node.node_tree.nodes['zhaHSV'].inputs[1], "default_value", text="Sat")
                        row.prop(node.node_tree.nodes['zhaHSV'].inputs[0], "default_value", text="Hue")
                        row = layout.row()
                        row.prop(node.node_tree.nodes['zhaMix'].inputs[7], "default_value", text="Color Tint")
                        row = layout.row()
                        row.prop(node.node_tree.nodes['zhaMix'].inputs[0], "default_value", text="Color Tint Strength")
                        row = layout.row()
                        row.prop(node.node_tree.nodes['zhaXYZ1'].inputs[0], "default_value", text="Spreading")
                        row.prop(node.node_tree.nodes['zhaXYZ2'].inputs[0], "default_value", text="Sharpness")
                        row = layout.row()
                        row.prop(node.node_tree.nodes['zhaRamp'].color_ramp.elements[0], "position", text="Occlude from Dark Areas (Increase This)")
                        row = layout.row()
                        row.prop(node.node_tree.nodes['zhaRamp'].color_ramp.elements[1], "position", text="Sharpen Brighter Areas (Decrease This)")
                
                if node.node_tree.name.startswith("ColoredCircular"):
                    return
                    

                if node.node_tree.name.startswith("TransparentPaint"):
                    tpdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    tpdupe.arg1 = node.name
                    transparentpainttrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    transparentpainttrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        overlaytexture = node.node_tree.nodes["Important Texture"]
                        row.template_ID(overlaytexture, "image", open="image.open", text="Texture")
                        row = layout.row()
                        row.prop(node.inputs[6], "default_value", text="Affect Edges?")
                        row = layout.row()
                        row.prop(node.inputs[5], "default_value", text="Overall Blend (Edges)")
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Overall Strength (Edges)")
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Overall Transparency")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["Important Ramp"].color_ramp.elements[0], "position", text="Clamp (Min)")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["Important Ramp"].color_ramp.elements[1], "position", text="Clamp (Max)")
                        row = layout.row()
                        row.prop(node.inputs[9], "default_value", text="Texture Scale (X)")
                        row = layout.row()
                        row.prop(node.inputs[10], "default_value", text="Texture Scale (Y)")
                        row = layout.row()
                        row.prop(node.inputs[11], "default_value", text="Texture Scale (Z)")
                        row = layout.row()
                        row.prop(node.inputs[7], "default_value", text="Texture Location")
                        row = layout.row()
                        row.prop(node.inputs[8], "default_value", text="Texture Rotation")
                        row = layout.row()
                        row.prop(node.inputs[12], "default_value", text="Window/UV Coordinate Switch")
                        row = layout.row()
                        row.label(text="Mask:")
                        row = layout.row()
                        row.template_ID(node.node_tree.nodes["Mask"], "image", new="image.new", open="image.open")
                        row = layout.row()
                        row.prop(node.inputs[13], "default_value", text="Mask Enable")
                        row = layout.row()
                        row.label(text="---Hair Settings---")
                        row = layout.row()
                        row.prop(node.inputs[14], "default_value", text="Hair Enable?")
                        if node.inputs[14].default_value > 0.01:
                            row = layout.row()
                            row.prop(node.inputs[16], "default_value", text="Strand Scale")
                            row = layout.row()
                            row.prop(node.inputs[17], "default_value", text="Strand Distortion")
                            row = layout.row()
                            row.prop(node.inputs[15], "default_value", text="Strand Clamp (1)")
                            row = layout.row()
                            row.prop(node.inputs[24], "default_value", text="Strand Clamp (2)")
                            row = layout.row()
                            row.prop(node.inputs[25], "default_value", text="Strand Clamp (3)")
                            row = layout.row()
                            row.prop(node.inputs[26], "default_value", text="Strand Clamp (4)")
                            row = layout.row()
                            row.prop(node.inputs[18], "default_value", text="Specular Enable?")
                            row = layout.row()
                            row.prop(node.inputs[23], "default_value", text="Specular Color")
                            row = layout.row()
                            row.prop(node.inputs[19], "default_value", text="Roughness")
                            row = layout.row()
                            row.prop(node.inputs[20], "default_value", text="Specular Strand Scale")
                            row = layout.row()
                            row.prop(node.inputs[21], "default_value", text="Specular Strength")
                            row = layout.row()
                            row.prop(node.inputs[22], "default_value", text="Specular Strand Distortion")

                

                if node.node_tree.name.startswith("AmbientOcclusion"):
                    aodupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    aodupe.arg1 = node.name
                    aotrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    aotrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        if obj.active_material.blend_method == 'BLEND':
                            row = layout.row()
                            row.label(text="WARNING: Blend Mode Must be Switched to Alpha Hashed or Opaque, Alpha Blend does not work with AO Effect")
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="AO Strength")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["ZhaRamp"].color_ramp.elements[1], "position", text="AO Ramp Slider")
                        if node.node_tree.nodes.get("Ambient Occlusion") is not None:
                            row = layout.row()
                            row.prop(node.inputs[2], "default_value", text="AO Distance*")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["ImportantRange"].inputs[1], "default_value", text="Harshness")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["ZhaRamp"].color_ramp.elements[0], "color", text="AO Color")
                        drawmaskAO = node.node_tree.nodes["Mask"]
                        row = layout.row()
                        row.template_ID(drawmaskAO, "image", new="image.new", open="image.open", text="Mask")
                        row = layout.row()
                        row.prop(node.inputs[3], "default_value", text="AO Mask Influence")
                        if node.node_tree.nodes.get("Ambient Occlusion") is None:
                            row = layout.row()
                            row.operator("shaderaddon.unbakeao", text="Unbake AO")

                if node.node_tree.name.startswith("VertexPaint"):
                    vpdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    vpdupe.arg1 = node.name
                    vertextrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    vertextrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.operator("geometry.color_attribute_add", text="Add Color Group")
                        row.prop(node.node_tree.nodes["Color Attribute"], "layer_name", text="Color Attributes")
                        row = layout.row()
                        imgtexture = node.node_tree.nodes["ImportantTexture"]
                        row.template_ID(imgtexture, "image", open="image.open", text="Select Painting Texture")
                        row = layout.row()
                        row.prop(node.inputs[8], "default_value", text="Painting Texture Influence")
                        row = layout.row()
                        row.prop(node.inputs[3], "default_value", text="X Scale")
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Y Scale")
                        row = layout.row()
                        row.prop(node.inputs[5], "default_value", text="Z Scale")
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Location")
                        row = layout.row()
                        row.prop(node.inputs[2], "default_value", text="Rotation")
                        row = layout.row()
                        row.prop(node.inputs[9], "default_value", text="UV Coordinates")
                        row = layout.row()
                        row.prop(node.inputs[10], "default_value", text="Window Coordinates")
                        
                if node.node_tree.name.startswith("SingleColor"):
                    scdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    scdupe.arg1 = node.name
                    singlecolortrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    singlecolortrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.node_tree.nodes["Mix"], "blend_type", text="Blend Mode")
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Color")
                        row = layout.row()
                        row.template_ID(node.node_tree.nodes["Image Texture"], "image", new="image.new", open="image.open", text="Draw")

                if node.node_tree.name.startswith("AddCurvature"):
                    curvdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    curvdupe.arg1 = node.name
                    curvtrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    curvtrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.label(text="Make sure your model is UV Unwrapped")
                        row = layout.row()
                        row.prop(context.scene, "user_input_number", text="Resolution")
                        row = layout.row()
                        row.prop(context.scene, "hardsurface", text="Is your model Hard Surface?")
                        row = layout.row()
                        row.prop(context.scene, "curvaturelevels", text="Detail Levels")
                        if node.node_tree.nodes.get("CurvatureHelper").image is not None:
                            row = layout.row()
                            row.operator("shaderaddon.bakecurvature", text="Re-Calculate Curvature")
                        else:
                            row = layout.row()
                            row.operator("shaderaddon.bakecurvature", text="Calculate Curvature")
                        if node.node_tree.nodes.get("CurvatureHelper").image is not None:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown1"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown1"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Curvature Main Settings")
                            if node.node_tree.nodes["DropDown1"].use_custom_color:
                                row = layout.row()
                                row.prop(node.inputs[4], "default_value", text="Value (Bright)")
                                row = layout.row()
                                row.prop(node.inputs[1], "default_value", text="Value (Dark)")
                                row = layout.row()
                                row.prop(node.inputs[5], "default_value", text="Sat")
                                row.prop(node.inputs[6], "default_value", text="Hue")
                                row = layout.row()
                                row.prop(node.inputs[7], "default_value", text="Spreading")
                                row = layout.row()
                                row.prop(node.inputs[8], "default_value", text="Sharpness")
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown2"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown2"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Painterly Distort")
                            if node.node_tree.nodes["DropDown2"].use_custom_color:
                                row = layout.row()
                                row.operator("shaderaddon.opensite", text="To use, Please Upgrade to Pro or Join the Masterclass on ukiyogirls.io!")
                                    

                if node.node_tree.name.startswith("ObjectRandomize"):
                    ordupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    ordupe.arg1 = node.name
                    randomizetrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    randomizetrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.label(text="Randomize HSV on different objects with this material.")
                        row = layout.row()
                        row.prop(node.inputs[2], "default_value", text="Hue (Min)")
                        row.prop(node.inputs[3], "default_value", text="Hue (Max)")
                        row = layout.row()
                        row.prop(node.inputs[8], "default_value", text="Hue Seed")
                        row = layout.row()
                        row.prop(node.inputs[6], "default_value", text="Value (Min)")
                        row.prop(node.inputs[7], "default_value", text="Value (Max)")
                        row = layout.row()
                        row.prop(node.inputs[9], "default_value", text="Value Seed")
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Saturation (Min)")
                        row.prop(node.inputs[5], "default_value", text="Saturation (Max)")
                        row = layout.row()
                        row.prop(node.inputs[10], "default_value", text="Saturation Seed")

                if node.node_tree.name.startswith("FinalHSL"):
                    hsldupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    hsldupe.arg1 = node.name
                    hsltrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    hsltrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Hue")
                        row = layout.row()
                        row.prop(node.inputs[2], "default_value", text="Saturation")
                        row = layout.row()
                        row.prop(node.inputs[3], "default_value", text="Value")
                        row = layout.row()
                        row.template_ID(node.node_tree.nodes["Image Texture"], "image", new="image.new", open="image.open")
                        row = layout.row()
                        row.prop(node.inputs[5], "default_value", text="Enable Mask?")
                        row = layout.row()
                        row.prop(node.inputs[6], "default_value", text="Invert Mask?")
                        # if node.inputs[5].default_value > 0.0:
                        #     try:
                        #         row = layout.row()
                        #         row.prop(node.node_tree.nodes["Map Range"].inputs[1], "default_value", text="Harshness")
                        #     except:
                        #         print("Done")

                if node.node_tree.name.startswith("HairCurves"):
                    return
                    hairtrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    hairtrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.node_tree.nodes["Important Range"], "interpolation_type", text="Style")
                        if node.node_tree.nodes["Important Range"].interpolation_type == 'STEPPED':
                            row = layout.row()
                            row.prop(node.inputs[16], "default_value", text="Steps")
                        row = layout.row()
                        row.prop(node.inputs[15], "default_value", text="Spreading")
                        row = layout.row()
                        row.prop(node.inputs[2], "default_value", text="Position")
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Scale")
                        row = layout.row()
                        row.label(text="Colors:")
                        row = layout.row()
                        row.prop(node.inputs[5], "default_value", text="Brightness")
                        row = layout.row()
                        row.prop(node.inputs[6], "default_value", text="Hue")
                        row.prop(node.inputs[7], "default_value", text="Saturation")
                        row = layout.row()
                        if node.node_tree.nodes["Color Ramp"].color_ramp.interpolation == 'CONSTANT':
                            row.prop(node.node_tree.nodes["Color Ramp"].color_ramp.elements[1], "position", text="Clamp Bottom")
                        else:
                            row.prop(node.node_tree.nodes["Color Ramp"].color_ramp.elements[0], "position", text="Clamp Bottom")
                        row.prop(node.node_tree.nodes["Color Ramp"].color_ramp.elements[2], "position", text="Clamp Top")
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Rotation")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown1"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown1"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Distortion/Lines")
                        if node.node_tree.nodes["DropDown1"].use_custom_color:
                            row = layout.row()
                            row.prop(node.inputs[9], "default_value", text="Line Clamp")
                            row = layout.row()
                            row.prop(node.inputs[11], "default_value", text="Scale")
                            row = layout.row()
                            row.prop(node.inputs[10], "default_value", text="Scale (Uniform)")
                            row = layout.row()
                            row.prop(node.inputs[12], "default_value", text="Detail")
                            row = layout.row()
                            row.prop(node.inputs[13], "default_value", text="Roughness")
                            row = layout.row()
                            row.prop(node.inputs[14], "default_value", text="Distortion")


                if node.node_tree.name.startswith("BrushStrokes"):
                    return
                    

                if node.node_tree.name.startswith("RGBContrast"):
                    rgbdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    rgbdupe.arg1 = node.name
                    rgbtrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    rgbtrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Dark Contrast")
                        row = layout.row()
                        row.prop(node.inputs[2], "default_value", text="Regular Contrast")
                        row = layout.row()
                        row.prop(node.inputs[3], "default_value", text="Bright Contrast")

                if node.node_tree.name.startswith("TexturePaint"):
                    paintdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    paintdupe.arg1 = node.name
                    texturepainttrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    texturepainttrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.label(text=("MAKE SURE ALPHA COLOR IS SET TO 0 WHEN ADDING TEXTURE"))
                        drawtexture1 = node.node_tree.nodes["Main"]
                        drawmask1 = node.node_tree.nodes["Mask"]
                        row = layout.row()
                        row.template_ID(drawtexture1, "image", new="image.new", open="image.open", text="Drawing texture")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["ImportantMix"], "blend_type", text="Blend Mode")
                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown1"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown1"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Mask Settings")
                            if node.node_tree.nodes["DropDown1"].use_custom_color:
                                row = layout.row()
                                row.template_ID(drawmask1, "image", new="image.new", open="image.open", text="Mask")
                                row = layout.row()
                                row.prop(node.inputs[2], "default_value", text="Enable Mask?")
                                # row = layout.row()
                                # row.prop(node.inputs[3], "default_value", text="Mask Location")
                                # row = layout.row()
                                # row.prop(node.inputs[4], "default_value", text="Mask Rotation")
                                # row = layout.row()
                                # row.prop(node.inputs[5], "default_value", text="Mask Scale")
                        except:
                            print("failed")
                            
                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown2"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown2"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Paint in Softwares")
                            if node.node_tree.nodes["DropDown2"].use_custom_color:
                                row = layout.row()
                                row.prop(context.preferences.filepaths, "image_editor")
                                row = layout.row()
                                row.prop(context.scene.tool_settings.image_paint, "screen_grab_size")
                                row = layout.row()
                                expaint = row.operator("shaderaddon.externalpaint", text="Open Software")
                                expaint.arg1 = node.node_tree.nodes['Main'].image.name
                                row.operator("image.project_apply", text="Apply")
                        except:
                            print("failed")
                                
                
                if node.node_tree.name.startswith("OverallTexture"):
                    otdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    otdupe.arg1 = node.name
                    overalltrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    overalltrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.node_tree.nodes["ImportantMix"], "blend_type", text="Blend Mode")
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Strength")
                        row = layout.row()
                        row.template_ID(node.node_tree.nodes["Image Texture"], "image", open="image.open", text="Texture")
                        row = layout.row()
                        row.prop(node.inputs[3], "default_value", text="Location")
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Rotation")
                        row = layout.row()
                        row.prop(node.inputs[5], "default_value", text="X Scale")
                        row = layout.row()
                        row.prop(node.inputs[6], "default_value", text="Y Scale")
                        row = layout.row()
                        row.prop(node.inputs[7], "default_value", text="Z Scale")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["Vect"].inputs[0], "default_value", text="UV/Window Coordinates Switch")
                        row = layout.row()
                        row.template_ID(node.node_tree.nodes["ImportantTexture"], "image", new="image.new", open="image.open", text="Mask")
                        row = layout.row()
                        row.prop(node.inputs[2], "default_value", text="Enable Mask?")

                if node.node_tree.name.startswith("StylizedFoam"):
                    return
                    stfoamdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    stfoamdupe.arg1 = node.name
                    stfoamtrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    stfoamtrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.node_tree.nodes["ImportantRange"], "interpolation_type", text="Style")
                        row = layout.row()
                        row.prop(node.inputs[10], "default_value", text="Steps")
                        row = layout.row()
                        row.prop(node.inputs[8], "default_value", text="Foam Spreading")
                        row = layout.row()
                        row.prop(node.inputs[6], "default_value", text="Foam Color")
                        row = layout.row()
                        row.prop(node.inputs[9], "default_value", text="To Max")
                        row = layout.row()
                        row.prop(node.inputs[2], "default_value", text="Foam Location")
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Foam Scale")
                        row = layout.row()
                        row.prop(node.inputs[3], "default_value", text="Foam Detail")
                        row = layout.row()
                        row.prop(node.inputs[12], "default_value", text="Painterly Distort Influence")
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Distort Scale (Uniform)")
                        row = layout.row()
                        row.prop(node.inputs[5], "default_value", text="Distort Scale")
                        row = layout.row()
                        row.prop(node.inputs[7], "default_value", text="Animate Painterly Distort")
                        row = layout.row()
                        row.prop(node.inputs[11], "default_value", text="UV/Generated Coordinates Switch")
                        row = layout.row()
                        row.template_ID(node.node_tree.nodes["Image Texture"], "image", new="image.new", open="image.open", text="Mask")
                        row = layout.row()
                        row.prop(node.inputs[13], "default_value", text="Enable Mask?")
                        row = layout.row()
                        row.prop(node.inputs[14], "default_value", text="Mask Location")
                        row = layout.row()
                        row.prop(node.inputs[15], "default_value", text="Mask Rotation")
                        row = layout.row()
                        row.prop(node.inputs[16], "default_value", text="Mask Scale")

                if node.node_tree.name.startswith("TransparentWorld"):
                    twdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    twdupe.arg1 = node.name
                    twtrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    twtrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.inputs[2], "default_value", text="Transparency Amount")
                        row = layout.row()
                        row.prop(node.inputs[3], "default_value", text="Invert?")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown1"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown1"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Masking")
                        if node.node_tree.nodes["DropDown1"].use_custom_color:
                            row = layout.row()
                            row.template_ID(node.node_tree.nodes["Mask"], "image", new="image.new", open="image.open")
                            row = layout.row()
                            row.prop(node.inputs[1], "default_value", text="Enable Mask?")

                if node.node_tree.name.startswith("InstantWatercolor"):
                    iwdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    iwdupe.arg1 = node.name
                    twtrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    twtrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Dark Areas")
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Bright Areas")
                        row = layout.row()
                        row.prop(node.inputs[7], "default_value", text="Scale (Uniform)")
                        row = layout.row()
                        row.prop(node.inputs[18], "default_value", text="Contrast")
                        row = layout.row()
                        row.prop(node.inputs[11], "default_value", text="Use UV Coords Instead?")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown1"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown1"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Positioning")
                        if node.node_tree.nodes["DropDown1"].use_custom_color:
                            row = layout.row()
                            row.prop(node.inputs[8], "default_value", text="Location")
                            row = layout.row()
                            row.prop(node.inputs[9], "default_value", text="Rotation")
                            row = layout.row()
                            row.prop(node.inputs[10], "default_value", text="Scale")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown2"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown2"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Details")
                        if node.node_tree.nodes["DropDown2"].use_custom_color:
                            row = layout.row()
                            row.prop(node.inputs[12], "default_value", text="Distort Amt")
                            row = layout.row()
                            row.prop(node.inputs[13], "default_value", text="Overall Detail")
                            row = layout.row()
                            row.prop(node.inputs[14], "default_value", text="Interstitial Scale")
                            row = layout.row()
                            row.prop(node.inputs[15], "default_value", text="Interstitial Detail")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown3"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown3"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Style")
                        if node.node_tree.nodes["DropDown3"].use_custom_color:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["Map Range"], "interpolation_type", text="Style")
                            row = layout.row()
                            row.prop(node.node_tree.nodes["Map Range"].inputs[5], "default_value", text="Steps")

                if node.node_tree.name.startswith("EasyDT"):
                    edtdupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    edtdupe.arg1 = node.name
                    edttrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    edttrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.inputs[13], "default_value", text="Noise Color")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["ImportantMix"], "blend_type", text="Blend Mode")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["MapRangeMask"], "interpolation_type", text="Toon/Linear Switch")
                        row = layout.row()
                        row.prop(node.inputs[14], "default_value", text="Steps")
                        row = layout.row()
                        row.prop(node.inputs[12], "default_value", text="Spreading (Clamp)")
                        row = layout.row()
                        row.prop(node.inputs[15], "default_value", text="Invert?")
                        row = layout.row()
                        row.prop(node.inputs[5], "default_value", text="Noise Scale (Uniform)")
                        row = layout.row()
                        row.prop(node.inputs[6], "default_value", text="Detail")
                        row = layout.row()
                        row.prop(node.inputs[7], "default_value", text="Roughness")
                        row = layout.row()
                        row.prop(node.inputs[16], "default_value", text="Lacunarity")
                        row = layout.row()
                        row.prop(node.inputs[17], "default_value", text="Distortion")
                        row = layout.row()
                        row.prop(node.inputs[2], "default_value", text="Position")
                        row = layout.row()
                        row.prop(node.inputs[4], "default_value", text="Scale")
                        row = layout.row()
                        row.prop(node.inputs[3], "default_value", text="Rotation")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown1"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown1"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Mask Distortion")
                        if node.node_tree.nodes["DropDown1"].use_custom_color:
                            row = layout.row()
                            row.prop(node.inputs[8], "default_value", text="Mask Distort / Make Painterly")
                            row = layout.row()
                            row.prop(node.inputs[9], "default_value", text="Painterly Distort Scale (Uniform)")
                            row = layout.row()
                            row.prop(node.inputs[19], "default_value", text="Painterly Distort Scale")
                            row = layout.row()
                            row.prop(node.inputs[18], "default_value", text="Painterly Distort Location")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["DropDown2"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown2"].use_custom_color else "TRIA_RIGHT", emboss=False)
                        row.label(text="Coordinate Settings")
                        if node.node_tree.nodes["DropDown2"].use_custom_color:
                            row = layout.row()
                            row.prop(node.inputs[20], "default_value", text="Object Coordinates")
                            row = layout.row()
                            row.prop(node.inputs[1], "default_value", text="UV Coordinates")




                if node.node_tree.name.startswith("NoiseTexture") or node.node_tree.name.startswith("TransparentNoise"):
                    return
                    tndupe = row.operator("shaderaddon.duplicateeffect", text="", icon='DUPLICATE')
                    tndupe.arg1 = node.name
                    noisetrash = row.operator("shaderaddon.deleteeffect", text="", icon='TRASH')
                    noisetrash.arg1 = node.name
                    if node.node_tree.nodes.get("Visibility") is not None:
                        row.prop(node.node_tree.nodes.get("Visibility").inputs[0], "default_value", text="Visibility")
                    if node.use_custom_color:
                        row = layout.row()
                        row.prop(node.inputs[1], "default_value", text="Noise Color")
                        # row = layout.row()
                        # row.prop(node.node_tree.nodes["Noise Range"], "interpolation_type", text="Toon/Linear Switch")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["ImportantMix"], "blend_type", text="Blend Mode")
                        row = layout.row()
                        row.prop(node.node_tree.nodes["MapRangeMask"], "interpolation_type", text="Toon/Linear Switch")
                        row = layout.row()
                        row.prop(node.inputs[29], "default_value", text="Steps")
                        row = layout.row()
                        row.prop(node.inputs[69], "default_value", text="Invert?")
                        row = layout.row()
                        row.label(text="Mask Options - Mask Will Constrict Texture to Certain Area".upper())
                        row = layout.row()
                        row = layout.row()
                        row.prop(node.inputs[2], "default_value", text="Mask Influence")
                        row = layout.row()
                        row.prop(node.inputs[55], "default_value", text="Mask Clamp Min")
                        row.prop(node.inputs[56], "default_value", text="Mask Clamp Max")
                        if node.node_tree.name.startswith("TransparentNoise"):
                            try:
                                row = layout.row()
                                row.prop(node.node_tree.nodes["AddTransparency"].inputs[0], "default_value", text="Transparency Amount")
                            except:
                                print("err")
                            row = layout.row()
                            row.prop(node.inputs[68], "default_value", text="Bright Value Clamp")
                        else:
                            row = layout.row()
                            row.prop(node.inputs[68], "default_value", text="Bright Value Clamp")

                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown1"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown1"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Mask Selector")
                            if node.node_tree.nodes["DropDown1"].use_custom_color:
                                row = layout.row()
                                row.label(text="Mask Selector")
                                row = layout.row()
                                row.prop(node.inputs[3], "default_value", text="Gradient (Sphere) Mask %")
                                row = layout.row()
                                row.prop(node.inputs[4], "default_value", text="Gradient (Rectangle) Mask %")
                                row = layout.row()
                                row.prop(node.inputs[5], "default_value", text="Noise Mask %")
                                row = layout.row()
                                row.prop(node.inputs[6], "default_value", text="Wave Mask %")
                                row = layout.row()
                                row.prop(node.inputs[57], "default_value", text="Wave2 Mask %")
                                row = layout.row()
                                row.prop(node.inputs[7], "default_value", text="Voronoi Mask %")
                                row = layout.row()
                                row.prop(node.inputs[49], "default_value", text="Tile/Brick Factor")
                                row = layout.row()
                                row.prop(node.inputs[48], "default_value", text="Foam Factor")
                                
                                # row.prop(node.inputs[24], "default_value", text="Noise Scale (Uniform)")
                                # row = layout.row()
                                # row.prop(node.inputs[25], "default_value", text="Noise Detail")
                                
                                # row.prop(node.inputs[26], "default_value", text="Noise Roughness")
                                # row = layout.row()
                                # row.prop(node.inputs[27], "default_value", text="Noise Distortion")
                                
                                # row.prop(node.inputs[28], "default_value", text="Noise Lacunarity")
                                # row = layout.row()
                                # row.prop(node.inputs[35], "default_value", text="Displace Noise")
                                # row = layout.row()
                                # row.prop(node.inputs[36], "default_value", text="Animate Displace")
                                # row = layout.row()
                                # row.prop(node.inputs[38], "default_value", text="Scale of Displace (Uniform)")
                                # row = layout.row()
                                # row.prop(node.inputs[39], "default_value", text="Scale of Displace")
                                # row = layout.row()
                                # row.label(text="TEXTURE COORDINATE OPTIONS")
                                
                                # row = layout.row()
                                # row.prop(node.inputs[19], "default_value", text="Generated Coords")
                                # row = layout.row()
                                # row.prop(node.inputs[20], "default_value", text="Object Coords")
                                # row = layout.row()
                                # row.prop(node.inputs[21], "default_value", text="UV Coords")
                                # row = layout.row()
                                # row.prop(node.inputs[22], "default_value", text="Window Coords")
                                # row = layout.row()
                                # row.prop(node.inputs[13], "default_value", text="Noise Location")
                                # row = layout.row()
                                # row.prop(node.inputs[14], "default_value", text="Noise Rotation")
                                # row = layout.row()
                                # row.prop(node.inputs[15], "default_value", text="Noise Scale")
                                row = layout.row()
                                row.label(text="--------------")
                                row = layout.row()
                                row.prop(context.scene, "my_mask_enum", text="Select Mask to Edit")
                                row = layout.row()
                                row.label(text="--------------")
                                if context.scene.my_mask_enum == 'TILES':
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["TileZha"].inputs[2], "default_value", text="Scale (Uniform)")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["TileRange"].inputs[1], "default_value", text="Clamp")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["TileZha"].inputs[3], "default_value", text="Detail")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["TileZha"].inputs[4], "default_value", text="Roughness")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["TileZha"].inputs[5], "default_value", text="Lacunarity")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["TileZha"].inputs[8], "default_value", text="Randomness")
                                    row = layout.row()
                                    row.prop(node.inputs[51], "default_value", text="Position")
                                    row = layout.row()
                                    row.prop(node.inputs[50], "default_value", text="Scale")
                                    row = layout.row()
                                    row.prop(node.inputs[67], "default_value", text="Rotation")

                                if context.scene.my_mask_enum == 'FOAM':
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["FoamRange"].inputs[1], "default_value", text="Clamp")
                                    row = layout.row()
                                    row.prop(node.inputs[54], "default_value", text="Foam Detail")
                                    row = layout.row()
                                    row.prop(node.inputs[52], "default_value", text="Position")
                                    row = layout.row()
                                    row.prop(node.inputs[53], "default_value", text="Scale")
                                    row = layout.row()
                                    row.prop(node.inputs[66], "default_value", text="Rotation")

                                if context.scene.my_mask_enum == 'WAVE':
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha"], "wave_type", text="Type")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha"], "bands_direction", text="Band Direction")
                                    row = layout.row()
                                    row.prop(node.inputs[31], "default_value", text="Wave Scale")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveRange"].inputs[1], "default_value", text="Clamp")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha"].inputs[2], "default_value", text="Distortion")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha"].inputs[3], "default_value", text="Detail")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha"].inputs[6], "default_value", text="Offset/Location")
                                    row = layout.row()
                                    row.prop(node.inputs[58], "default_value", text="Rotation")
                                    # row = layout.row()
                                    # row.prop(node.inputs[60], "default_value", text="Location")
                                if context.scene.my_mask_enum == 'WAVE2':
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha2"], "wave_type", text="Type")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha2"], "bands_direction", text="Band Direction")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha2"].inputs[1], "default_value", text="Scale")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveRange2"].inputs[1], "default_value", text="Clamp")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha2"].inputs[2], "default_value", text="Distortion")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha2"].inputs[3], "default_value", text="Detail")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["WaveZha2"].inputs[6], "default_value", text="Offset/Location")
                                    row = layout.row()
                                    row.prop(node.inputs[59], "default_value", text="Rotation")
                                if context.scene.my_mask_enum == 'NOISE':
                                    row = layout.row()
                                    row.prop(node.inputs[30], "default_value", text="Noise Scale")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["NoiseRange"].inputs[2], "default_value", text="Clamp")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["NoiseZha"].inputs[3], "default_value", text="Detail")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["NoiseZha"].inputs[4], "default_value", text="Roughness")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["NoiseZha"].inputs[5], "default_value", text="Lacunarity")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["NoiseZha"].inputs[6], "default_value", text="Distortion")
                                    row = layout.row()
                                    row.prop(node.inputs[42], "default_value", text="Position")
                                    row = layout.row()
                                    row.prop(node.inputs[45], "default_value", text="Scale")
                                    row = layout.row()
                                    row.prop(node.inputs[65], "default_value", text="Rotation")
                                    
                                if context.scene.my_mask_enum == 'VORONOI':
                                    row = layout.row()
                                    row.prop(node.inputs[32], "default_value", text="Scale (Uniform)")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["VoronoiRange"].inputs[1], "default_value", text="Clamp")
                                    row = layout.row()
                                    row.prop(node.inputs[33], "default_value", text="Invert")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["VoronoiZha"].inputs[3], "default_value", text="Detail")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["VoronoiZha"].inputs[4], "default_value", text="Roughness")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["VoronoiZha"].inputs[5], "default_value", text="Lacunarity")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["VoronoiZha"].inputs[8], "default_value", text="Randomness")
                                    row = layout.row()
                                    row.prop(node.inputs[43], "default_value", text="Position")
                                    row = layout.row()
                                    row.prop(node.inputs[44], "default_value", text="Scale")

                                
                                if context.scene.my_mask_enum == 'GRADIENTSPHERE':
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["SphereRange"].inputs[1], "default_value", text="Clamp")
                                    row = layout.row()
                                    row.prop(node.inputs[47], "default_value", text="Scale")
                                    row = layout.row()
                                    row.prop(node.inputs[61], "default_value", text="Position")
                                    row = layout.row()
                                    row.prop(node.inputs[62], "default_value", text="Rotation")

                                if context.scene.my_mask_enum == 'GRADIENTRECT':
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["RectRange"].inputs[1], "default_value", text="Clamp")
                                    row = layout.row()
                                    row.prop(node.inputs[46], "default_value", text="Scale")
                                    row = layout.row()
                                    row.prop(node.inputs[63], "default_value", text="Position")
                                    row = layout.row()
                                    row.prop(node.inputs[64], "default_value", text="Rotation")
                                    
                                row = layout.row()
                                row.label(text="----------------------")
                        except:
                            row = layout.row()
                            row.label(text="Mask Selector")
                            row = layout.row()
                            row.prop(node.inputs[3], "default_value", text="Gradient (Sphere) Mask %")
                            row = layout.row()
                            row.prop(node.inputs[4], "default_value", text="Gradient (Rectangle) Mask %")
                            row = layout.row()
                            row.prop(node.inputs[5], "default_value", text="Noise Mask %")
                            row = layout.row()
                            row.prop(node.inputs[6], "default_value", text="Wave Mask %")
                            row = layout.row()
                            row.prop(node.inputs[57], "default_value", text="Wave2 Mask %")
                            row = layout.row()
                            row.prop(node.inputs[7], "default_value", text="Voronoi Mask %")
                            row = layout.row()
                            row.prop(node.inputs[49], "default_value", text="Tile/Brick Factor")
                            row = layout.row()
                            row.prop(node.inputs[48], "default_value", text="Foam Factor")
                            
                            # row.prop(node.inputs[24], "default_value", text="Noise Scale (Uniform)")
                            # row = layout.row()
                            # row.prop(node.inputs[25], "default_value", text="Noise Detail")
                            
                            # row.prop(node.inputs[26], "default_value", text="Noise Roughness")
                            # row = layout.row()
                            # row.prop(node.inputs[27], "default_value", text="Noise Distortion")
                            
                            # row.prop(node.inputs[28], "default_value", text="Noise Lacunarity")
                            # row = layout.row()
                            # row.prop(node.inputs[35], "default_value", text="Displace Noise")
                            # row = layout.row()
                            # row.prop(node.inputs[36], "default_value", text="Animate Displace")
                            # row = layout.row()
                            # row.prop(node.inputs[38], "default_value", text="Scale of Displace (Uniform)")
                            # row = layout.row()
                            # row.prop(node.inputs[39], "default_value", text="Scale of Displace")
                            # row = layout.row()
                            # row.label(text="TEXTURE COORDINATE OPTIONS")
                            
                            # row = layout.row()
                            # row.prop(node.inputs[19], "default_value", text="Generated Coords")
                            # row = layout.row()
                            # row.prop(node.inputs[20], "default_value", text="Object Coords")
                            # row = layout.row()
                            # row.prop(node.inputs[21], "default_value", text="UV Coords")
                            # row = layout.row()
                            # row.prop(node.inputs[22], "default_value", text="Window Coords")
                            # row = layout.row()
                            # row.prop(node.inputs[13], "default_value", text="Noise Location")
                            # row = layout.row()
                            # row.prop(node.inputs[14], "default_value", text="Noise Rotation")
                            # row = layout.row()
                            # row.prop(node.inputs[15], "default_value", text="Noise Scale")
                            row = layout.row()
                            row.label(text="--------------")
                            row = layout.row()
                            row.prop(context.scene, "my_mask_enum", text="Select Mask to Edit")
                            row = layout.row()
                            row.label(text="--------------")
                            if context.scene.my_mask_enum == 'TILES':
                                row = layout.row()
                                row.prop(node.node_tree.nodes["TileZha"].inputs[2], "default_value", text="Scale (Uniform)")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["TileRange"].inputs[1], "default_value", text="Clamp")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["TileZha"].inputs[3], "default_value", text="Detail")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["TileZha"].inputs[4], "default_value", text="Roughness")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["TileZha"].inputs[5], "default_value", text="Lacunarity")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["TileZha"].inputs[8], "default_value", text="Randomness")
                                row = layout.row()
                                row.prop(node.inputs[51], "default_value", text="Position")
                                row = layout.row()
                                row.prop(node.inputs[50], "default_value", text="Scale")
                                row = layout.row()
                                row.prop(node.inputs[67], "default_value", text="Rotation")

                            if context.scene.my_mask_enum == 'FOAM':
                                row = layout.row()
                                row.prop(node.node_tree.nodes["FoamRange"].inputs[1], "default_value", text="Clamp")
                                row = layout.row()
                                row.prop(node.inputs[54], "default_value", text="Foam Detail")
                                row = layout.row()
                                row.prop(node.inputs[52], "default_value", text="Position")
                                row = layout.row()
                                row.prop(node.inputs[53], "default_value", text="Scale")
                                row = layout.row()
                                row.prop(node.inputs[66], "default_value", text="Rotation")

                            if context.scene.my_mask_enum == 'WAVE':
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha"], "wave_type", text="Type")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha"], "bands_direction", text="Band Direction")
                                row = layout.row()
                                row.prop(node.inputs[31], "default_value", text="Wave Scale")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveRange"].inputs[1], "default_value", text="Clamp")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha"].inputs[2], "default_value", text="Distortion")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha"].inputs[3], "default_value", text="Detail")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha"].inputs[6], "default_value", text="Offset/Location")
                                row = layout.row()
                                row.prop(node.inputs[58], "default_value", text="Rotation")
                                # row = layout.row()
                                # row.prop(node.inputs[60], "default_value", text="Location")
                            if context.scene.my_mask_enum == 'WAVE2':
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha2"], "wave_type", text="Type")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha2"], "bands_direction", text="Band Direction")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha2"].inputs[1], "default_value", text="Scale")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveRange2"].inputs[1], "default_value", text="Clamp")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha2"].inputs[2], "default_value", text="Distortion")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha2"].inputs[3], "default_value", text="Detail")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["WaveZha2"].inputs[6], "default_value", text="Offset/Location")
                                row = layout.row()
                                row.prop(node.inputs[59], "default_value", text="Rotation")
                            if context.scene.my_mask_enum == 'NOISE':
                                row = layout.row()
                                row.prop(node.inputs[30], "default_value", text="Noise Scale")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["NoiseRange"].inputs[2], "default_value", text="Clamp")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["NoiseZha"].inputs[3], "default_value", text="Detail")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["NoiseZha"].inputs[4], "default_value", text="Roughness")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["NoiseZha"].inputs[5], "default_value", text="Lacunarity")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["NoiseZha"].inputs[6], "default_value", text="Distortion")
                                row = layout.row()
                                row.prop(node.inputs[42], "default_value", text="Position")
                                row = layout.row()
                                row.prop(node.inputs[45], "default_value", text="Scale")
                                row = layout.row()
                                row.prop(node.inputs[65], "default_value", text="Rotation")
                                
                            if context.scene.my_mask_enum == 'VORONOI':
                                row = layout.row()
                                row.prop(node.inputs[32], "default_value", text="Scale (Uniform)")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["VoronoiRange"].inputs[1], "default_value", text="Clamp")
                                row = layout.row()
                                row.prop(node.inputs[33], "default_value", text="Invert")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["VoronoiZha"].inputs[3], "default_value", text="Detail")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["VoronoiZha"].inputs[4], "default_value", text="Roughness")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["VoronoiZha"].inputs[5], "default_value", text="Lacunarity")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["VoronoiZha"].inputs[8], "default_value", text="Randomness")
                                row = layout.row()
                                row.prop(node.inputs[43], "default_value", text="Position")
                                row = layout.row()
                                row.prop(node.inputs[44], "default_value", text="Scale")

                            
                            if context.scene.my_mask_enum == 'GRADIENTSPHERE':
                                row = layout.row()
                                row.prop(node.node_tree.nodes["SphereRange"].inputs[1], "default_value", text="Clamp")
                                row = layout.row()
                                row.prop(node.inputs[47], "default_value", text="Scale")
                                row = layout.row()
                                row.prop(node.inputs[61], "default_value", text="Position")
                                row = layout.row()
                                row.prop(node.inputs[62], "default_value", text="Rotation")

                            if context.scene.my_mask_enum == 'GRADIENTRECT':
                                row = layout.row()
                                row.prop(node.node_tree.nodes["RectRange"].inputs[1], "default_value", text="Clamp")
                                row = layout.row()
                                row.prop(node.inputs[46], "default_value", text="Scale")
                                row = layout.row()
                                row.prop(node.inputs[63], "default_value", text="Position")
                                row = layout.row()
                                row.prop(node.inputs[64], "default_value", text="Rotation")
                                
                            row = layout.row()
                            row.label(text="----------------------")
                        row = layout.row()
                        try:
                            row.prop(node.node_tree.nodes["DropDown2"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown2"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Mask Distortion")
                            if node.node_tree.nodes["DropDown2"].use_custom_color:
                                
                                row = layout.row()
                                row.prop(node.inputs[12], "default_value", text="Mask Distort / Make Painterly")
                                row = layout.row()
                                row.prop(node.inputs[34], "default_value", text="Painterly Distort Scale (Uniform)")
                                row = layout.row()
                                row.prop(node.inputs[41], "default_value", text="Painterly Distort Scale")
                                row = layout.row()
                                row.prop(node.inputs[37], "default_value", text="Animate Painterly Distort")
                        except:
                            row = layout.row()
                            row.label(text="Distort Mask Settings")
                            row = layout.row()
                            row.prop(node.inputs[12], "default_value", text="Mask Distort / Make Painterly")
                            row = layout.row()
                            row.prop(node.inputs[34], "default_value", text="Painterly Distort Scale (Uniform)")
                            row = layout.row()
                            row.prop(node.inputs[41], "default_value", text="Painterly Distort Scale")
                            row = layout.row()
                            row.prop(node.inputs[37], "default_value", text="Animate Painterly Distort")


                        if node.node_tree.name.startswith("TransparentNoise"):
                            try:
                                row.prop(node.node_tree.nodes["DropDown3"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown3"].use_custom_color else "TRIA_RIGHT", emboss=False)
                                row.label(text="Edge Transparency")
                                if node.node_tree.nodes["DropDown3"].use_custom_color:
                                    row = layout.row()
                                    row.label(text="Edge Transparency (Unbakeable)")
                                    row = layout.row()
                                    row.prop(node.inputs[70], "default_value", text="Enable Edge Transparency?")
                                    if node.inputs[70].default_value > 0.01:
                                        row = layout.row()
                                        row.operator("shaderaddon.maskspeculars", text="Unmask Speculars")
                                        row = layout.row()
                                        row.prop(node.inputs[71], "default_value", text="Blend")
                                        row.prop(node.inputs[72], "default_value", text="Invert?")
                            except:
                                row = layout.row()
                                row.label(text="Edge Transparency (Unbakeable)")
                                row = layout.row()
                                row.prop(node.inputs[70], "default_value", text="Enable Edge Transparency?")
                                if node.inputs[70].default_value > 0.01:
                                    row = layout.row()
                                    row.operator("shaderaddon.maskspeculars", text="Unmask Speculars")
                                    row = layout.row()
                                    row.prop(node.inputs[71], "default_value", text="Blend")
                                    row.prop(node.inputs[72], "default_value", text="Invert?")

                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown4"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown4"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Hand Draw a Mask")
                            if node.node_tree.nodes["DropDown4"].use_custom_color:
                                row = layout.row()
                                row.label(text="Use the New/Open Button below if you want to hand draw a mask.")
                                row = layout.row()
                                drawmask2 = node.node_tree.nodes["DrawMask"]
                                row.template_ID(drawmask2, "image", new="image.new", open="image.open")
                                row = layout.row()
                                row.prop(node.inputs[40], "default_value", text="Enable Drawing Mask?")
                                if node.node_tree.name.startswith("TransparentNoise") and node.inputs[40].default_value > 0.01:
                                    row = layout.row()
                                    row.prop(node.inputs[74], "default_value", text="Mask Location")
                                    row = layout.row()
                                    row.prop(node.inputs[75], "default_value", text="Mask Scale")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["Color Ramp"].color_ramp.elements[0], "position", text="Clamp")
                                    row = layout.row()
                                    row.prop(node.node_tree.nodes["Color Ramp"].color_ramp.elements[1], "position", text="Clamp 2")
                                row = layout.row()
                                row = layout.row()
                        except:
                            row = layout.row()
                            row.label(text="Use the New/Open Button below if you want to hand draw a mask.")
                            row = layout.row()
                            drawmask2 = node.node_tree.nodes["DrawMask"]
                            row.template_ID(drawmask2, "image", new="image.new", open="image.open")
                            row = layout.row()
                            row.prop(node.inputs[40], "default_value", text="Enable Drawing Mask?")
                            if node.node_tree.name.startswith("TransparentNoise") and node.inputs[40].default_value > 0.01:
                                row = layout.row()
                                row.prop(node.inputs[74], "default_value", text="Mask Location")
                                row = layout.row()
                                row.prop(node.inputs[75], "default_value", text="Mask Scale")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["Color Ramp"].color_ramp.elements[0], "position", text="Clamp")
                                row = layout.row()
                                row.prop(node.node_tree.nodes["Color Ramp"].color_ramp.elements[1], "position", text="Clamp 2")
                            row = layout.row()
                            row = layout.row()
                        
                        try:
                            row = layout.row()
                            row.prop(node.node_tree.nodes["DropDown5"], "use_custom_color", text="", icon="TRIA_DOWN" if node.node_tree.nodes["DropDown5"].use_custom_color else "TRIA_RIGHT", emboss=False)
                            row.label(text="Coordinate Settings")
                            if node.node_tree.nodes["DropDown5"].use_custom_color:
                                row = layout.row()
                                row.label(text="MASK TEXTURE COORDINATE SETTINGS")
                                row = layout.row()
                                row.prop(node.inputs[17], "default_value", text="Object Coords (Mask)")
                                row = layout.row()
                                row.prop(node.inputs[18], "default_value", text="UV Coords (Mask)")
                        except:
                            row = layout.row()
                            row.label(text="MASK TEXTURE COORDINATE SETTINGS")
                            row = layout.row()
                            row.prop(node.inputs[17], "default_value", text="Object Coords (Mask)")
                            row = layout.row()
                            row.prop(node.inputs[18], "default_value", text="UV Coords (Mask)")
                        
                        row = layout.row()
                        row.prop(node.node_tree.nodes["ZhaTexture Coordinate"], "object", text="Mask Object")

            
            
            if node.outputs and node.outputs[0].is_linked and nodecount < 9:
                node = node.outputs[0].links[0].to_node
            else:
                break
            

        # if not obj.active_material.name.startswith("Outline for"):
        #     #delete effect
        row = layout.row()
        box = layout.box()
        #     row = box.row()
        #     row.prop(obj, "node_groups_enum", text="")
        #     row.operator("shaderaddon.deleteeffect", text="DELETE")


        modifier_count = 0

        for modifier in obj.modifiers:
            if modifier.name.startswith("SB Disp"):
                modifier_count += 1
                box = layout.box()
                row = box.row()
                row.label(text=f"Displace Effect #{modifier_count}")
                row = layout.row()
                row.prop(modifier, "strength")
                row.prop(modifier, "mid_level")
                row.prop(modifier, "direction")
                row = layout.row()
                row.operator("shaderaddon.addcloudstexture", text="Add Clouds Displace Texture")
                row = layout.row()
                row.prop(modifier, "texture")
                row.prop(modifier, "texture_coords")
                row.prop(modifier, "texture_coords_object")

                

        
        row = layout.row()
        row = box.row()
        row.prop(obj, "node_groups_enum_swap1", text="")
        row.prop(obj, "node_groups_enum_swap2", text="And")
        row.operator("shaderaddon.swapnodes", text="SWAP EFFECTS")
        row = layout.row()
        row = box.row()
        
        # row.prop(obj, "duplicate_group_enum", text="")
        # row.operator("shaderaddon.duplicateeffect", text="DUPLICATE")
        # row = layout.row()
        # row.label(text="Certain effects like Light effects are not duplicatable, add them from effects menu")

        #check for steam/fog objects

        try:
            if bpy.context.object.active_material.node_tree.nodes.get("SB Fog") is not None or bpy.context.object.active_material.name.startswith("SB Fog"):
                row = layout.row()
                box = layout.box()
                row = box.row()
                row.label(text="Fog")
                row = layout.row()
                fognode = bpy.context.object.active_material.node_tree.nodes.get("SB Fog")
                row.prop(fognode.inputs[0], "default_value", text="Scale (Uniform)")
                row = layout.row()
                row.prop(fognode.inputs[1], "default_value", text="Scale")
                row = layout.row()
                row.prop(fognode.inputs[2], "default_value", text="Clamp Fog (Min)")
                row = layout.row()
                row.prop(fognode.inputs[3], "default_value", text="Clamp Fog (Max)")
                row = layout.row()
                row.prop(fognode.inputs[4], "default_value", text="Color")
                row = layout.row()
                row.prop(fognode.inputs[5], "default_value", text="Location")
                row = layout.row()
                row.prop(fognode.inputs[6], "default_value", text="Mask Clamp")
                row = layout.row()
                row.prop(fognode.inputs[7], "default_value", text="Mask Location")
            if bpy.context.object.active_material.node_tree.nodes.get("SB Steam") is not None or bpy.context.object.active_material.name.startswith("SB Steam"):
                row = layout.row()
                box = layout.box()
                row = box.row()
                row.label(text="Steam")
                row = layout.row()
                steamnode = bpy.context.object.active_material.node_tree.nodes.get("SB Steam")
                row.prop(steamnode.inputs[0], "default_value", text="Color")
                row = layout.row()
                row.prop(steamnode.inputs[9], "default_value", text="Steam Location")
                row = layout.row()
                row.prop(steamnode.inputs[4], "default_value", text="Scale (Uniform)")
                row = layout.row()
                row.prop(steamnode.inputs[3], "default_value", text="Scale")
                row = layout.row()
                row.prop(steamnode.inputs[1], "default_value", text="Steam Fade")
                row = layout.row()
                row.prop(steamnode.inputs[5], "default_value", text="Detail")
                row = layout.row()
                row.prop(steamnode.inputs[6], "default_value", text="Roughness")
                row = layout.row()
                row.prop(steamnode.inputs[7], "default_value", text="Spreading")
                row = layout.row()
                row.prop(steamnode.inputs[8], "default_value", text="Bottom")
        except:
            joe = 'kasou'
            




                        

bpy.types.Scene.show_collapsible_section = bpy.props.BoolProperty(name="Show Collapsible Section", default=True)



class CloudsTexture(bpy.types.Operator):
    bl_idname = "shaderaddon.addcloudstexture"
    bl_label = "Add a Clouds Texture"

    def execute(self, context):
        obj = bpy.context.active_object

        if not obj:
            return
        #check if empty
        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        

        texture = bpy.data.textures.new("CloudsTexture", 'CLOUDS')
    
        # Set the texture type to Clouds
        texture.type = 'CLOUDS'
        
        # Set additional settings for the Clouds texture
        texture.noise_scale = 0.25
        texture.noise_depth = 2

        for modifier in obj.modifiers:
            if modifier.name.startswith("SB Disp"):
                modifier.texture = texture
                break

        

        return {'FINISHED'}

class ExecuteOperator(bpy.types.Operator):
    bl_idname = "shaderaddon.execute_operator"
    bl_label = "Add Effect"

    def execute(self, context):
        obj = bpy.context.active_object

        tempobj = None
        if obj.type == 'EMPTY' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj
        elif obj.type == 'MESH' and obj.name.startswith("SB"):
            tempobj = obj.parent
            obj = tempobj

        if not obj or not obj.active_material or not obj.active_material.use_nodes:
            print("No active object or no material with nodes found.")
            return

        material = obj.active_material
        nodes = material.node_tree.nodes
        links = material.node_tree.links
        count = 0
        for node in nodes:
            if node.type == 'GROUP':
                count += 1
        
        if not context.scene.my_operator_enum == 'SOLIDIFYOUTLINE':
            def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):
                def draw(self, context):
                    self.layout.label(text=message)
                
                bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

            if count >= 9:
                ShowMessageBox("Max Layers Reached, Please Upgrade or Join the Masterclass on ukiyogirls.io!", "My Title", 'ERROR')
                return {'FINISHED'}
            
        curcount = 0
        def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):
            def draw(self, context):
                self.layout.label(text=message)
                
            bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)
        for obj in bpy.data.objects:
            try:
                if obj.active_material.node_tree.nodes.get("SAS Point Lights Group #1") is not None:
                    curcount += 1
            except:
                continue
        if curcount >= 25:
            ShowMessageBox(message="Max Objects (25) for using the Stylized Point Light Reached. Please Remove From Some Objects, Or Upgrade", title="Message Box", icon='INFO')
            return {'FINISHED'}

        
        operator = context.scene.my_operator_enum
        if operator == 'LOCALGRADIENT':
            bpy.ops.shaderaddon.addlocalgradient()
        elif operator == 'DIFFUSELIGHTING':
            bpy.ops.shaderaddon.adddiffuselighting()
        elif operator == 'SPECULAR':
            bpy.ops.shaderaddon.addspecularreflection()
        elif operator == 'AO':
            bpy.ops.shaderaddon.addao()
        elif operator == 'CIRCULARLIGHTING':
            bpy.ops.shaderaddon.addcircularlight()
        elif operator == 'TRANSPARENTPAINT':
            bpy.ops.shaderaddon.addtransparentpaint()
        elif operator == 'DRAWPAINT':
            bpy.ops.shaderaddon.addtexturepaint()
        elif operator == 'NOISETEXTURE':
            bpy.ops.shaderaddon.addnoisetexture()
        elif operator == 'LOCALGRADIENTSPHERE':
            bpy.ops.shaderaddon.addlocalgradientsphere()
        elif operator == 'OVERALLTEXTURE':
            bpy.ops.shaderaddon.addoveralltexture()
        elif operator == 'MOODLIGHT':
            bpy.ops.shaderaddon.addcoloredcircularlight()
        elif operator == 'EDGEDETECT':
            bpy.ops.shaderaddon.addedgedetect()
        elif operator == 'COLOREDEDGES':
            bpy.ops.shaderaddon.addcolorededges()
        elif operator == 'SOLIDIFYOUTLINE':
            bpy.ops.shaderaddon.addsolidifyoutline()
        elif operator == 'VERTEXPAINT':
            bpy.ops.shaderaddon.addvertexpaint()
        elif operator == 'DISPLACE':
            bpy.ops.shaderaddon.adddisplace()
        elif operator == 'FAKELIGHT':
            bpy.ops.shaderaddon.addobjectlight()
        elif operator == 'FAKESUNLIGHT':
            bpy.ops.shaderaddon.addsunlight()
        elif operator == 'DRAWONECOLOR':
            bpy.ops.shaderaddon.addsinglecolor()
        elif operator == 'TRANSPARENTNOISE':
            bpy.ops.shaderaddon.addtransparentnoise()
        elif operator == 'STYLIZEDFOAM':
            bpy.ops.shaderaddon.addstylizedfoam()
        elif operator == 'FOG':
            bpy.ops.shaderaddon.addfog()
        elif operator == 'STEAM':
            bpy.ops.shaderaddon.addsteam()
        elif operator == 'HSL':
            bpy.ops.shaderaddon.addhsl()
        elif operator == 'BRUSHSTROKES':
            bpy.ops.shaderaddon.addbrushstrokes()
        elif operator == 'OBJECTRANDOMIZE':
            bpy.ops.shaderaddon.addobjectrandomize()
        elif operator == 'CROSSHATCHING':
            bpy.ops.shaderaddon.addcrosshatch()
        elif operator == 'GODRAYS':
            bpy.ops.shaderaddon.addgodrays()
        elif operator == 'CONTRAST':
            bpy.ops.shaderaddon.addrgbcurves()
        elif operator == 'WORLDSTROKES':
            bpy.ops.shaderaddon.addtransparentworldstrokes()
        elif operator == 'INSTANTWATERCOLOR':
            bpy.ops.shaderaddon.addinstantwatercolor()
        elif operator == 'HAIRCURVES':
            bpy.ops.shaderaddon.addhaircurves()
        elif operator == 'EASYDT':
            bpy.ops.shaderaddon.addeasydt()
        elif operator == 'CURVATURE':
            bpy.ops.shaderaddon.addcurvature()
        elif operator == 'SPLRed':
            bpy.ops.shaderaddon.addredlight()
        return {'FINISHED'}

@persistent
def stimulate(dummy):
    bpy.app.timers.register(timer_function)


bpy.app.handlers.load_post.append(stimulate)
    

def register():
    bpy.utils.register_class(ShaderSetup)
    bpy.utils.register_class(ExecuteOperator)
    bpy.utils.register_class(ShaderPanel)
    bpy.utils.register_class(DeleteMaterial)
    bpy.utils.register_class(AddLocalGradient)
    bpy.utils.register_class(AddDiffuseLighting)
    bpy.utils.register_class(AddAO)
    bpy.utils.register_class(AddCircularLight)
    bpy.utils.register_class(AddTransparentPaint)
    bpy.utils.register_class(AddTexturePaint)
    bpy.utils.register_class(AddNoiseTexture)
    bpy.utils.register_class(AddLocalGradientSphere)
    bpy.utils.register_class(DeleteEffect)
    bpy.utils.register_class(RefreshMaterial)
    bpy.utils.register_class(AddOverallTexture)
    # bpy.utils.register_class(AddMoodLight)
    bpy.utils.register_class(SwapNodes)
    bpy.utils.register_class(AddEdgeDetect)
    bpy.utils.register_class(AddColoredEdges)
    bpy.utils.register_class(AddSolidifyOutline)
    bpy.app.timers.register(timer_function)
    bpy.app.handlers.load_post.append(stimulate)
    bpy.utils.register_class(AppendBrushes)
    bpy.utils.register_class(AddVertexPaint)
    bpy.utils.register_class(AddDisplace)
    bpy.utils.register_class(CloudsTexture)
    bpy.utils.register_class(AddFakeLight)
    bpy.utils.register_class(AddFakeSun)
    bpy.utils.register_class(AddSingleColor)
    bpy.utils.register_class(AddTransparentNoise)

    bpy.utils.register_class(DuplicateMaterial)
    bpy.utils.register_class(AddStylizedFoam)
    
    bpy.utils.register_class(AddCurvature)
    bpy.utils.register_class(AddHSL)
    bpy.utils.register_class(WorldSetup)
    bpy.utils.register_class(WorldPanel)
    bpy.utils.register_class(SwapNodes2)
    bpy.utils.register_class(DuplicateEffect)

    

    bpy.utils.register_class(AddBrushStrokes)
    bpy.utils.register_class(AddObjectRandomize)

    bpy.utils.register_class(SaveImageTextures)

    bpy.utils.register_class(BakeAlphaAnimated)
    bpy.utils.register_class(AddCrossHatch)
    bpy.utils.register_class(AddRGBCurves)
    bpy.utils.register_class(BakeNormals)
    bpy.utils.register_class(MaskSpeculars)
    bpy.utils.register_class(AddTransparentWorldStrokes)
    # bpy.utils.register_class(BakeBounced)
    bpy.utils.register_class(AddInstantWatercolor)
    bpy.utils.register_class(AddHairCurves)
    bpy.utils.register_class(ExternalPaint)
    bpy.utils.register_class(AddEasyDT)
    bpy.utils.register_class(NormalsPaint)
    bpy.utils.register_class(OpenURLOperator)
    bpy.utils.register_class(BakeCurvature)
    bpy.utils.register_class(AddRedLight)
    
    


def unregister():
    bpy.utils.unregister_class(ShaderSetup)
    bpy.utils.unregister_class(ExecuteOperator)
    bpy.utils.unregister_class(ShaderPanel)
    bpy.utils.unregister_class(DeleteMaterial)
    bpy.utils.unregister_class(AddLocalGradient)
    bpy.utils.unregister_class(AddDiffuseLighting)
    bpy.utils.unregister_class(AddAO)
    bpy.utils.unregister_class(AddCircularLight)
    bpy.utils.unregister_class(AddTransparentPaint)
    bpy.utils.unregister_class(AddTexturePaint)
    bpy.utils.unregister_class(AddNoiseTexture)
    bpy.utils.unregister_class(AddLocalGradientSphere)
    bpy.utils.unregister_class(DeleteEffect)
    bpy.utils.unregister_class(RefreshMaterial)
    bpy.utils.unregister_class(AddOverallTexture)
    bpy.utils.unregister_class(AddCurvature)
    # bpy.utils.unregister_class(AddMoodLight)
    bpy.utils.unregister_class(SwapNodes)
    bpy.utils.unregister_class(AddEdgeDetect)
    bpy.utils.unregister_class(AddColoredEdges)
    bpy.utils.unregister_class(AddSolidifyOutline)
    bpy.app.timers.unregister(timer_function)
    bpy.app.handlers.load_post.remove(stimulate)
    bpy.utils.unregister_class(AppendBrushes)
    bpy.utils.unregister_class(AddVertexPaint)
    bpy.utils.unregister_class(AddDisplace)
    bpy.utils.unregister_class(CloudsTexture)
    bpy.utils.unregister_class(AddFakeLight)
    bpy.utils.unregister_class(AddFakeSun)
    bpy.utils.unregister_class(AddSingleColor)
    bpy.utils.unregister_class(AddTransparentNoise)

    bpy.utils.unregister_class(DuplicateMaterial)
    bpy.utils.unregister_class(AddStylizedFoam)
    
    bpy.utils.unregister_class(AddHSL)
    bpy.utils.unregister_class(WorldSetup)
    bpy.utils.unregister_class(WorldPanel)
    bpy.utils.unregister_class(SwapNodes2)
    bpy.utils.unregister_class(DuplicateEffect)

    bpy.utils.unregister_class(AddObjectRandomize)

    


    bpy.utils.unregister_class(SaveImageTextures)

    bpy.utils.unregister_class(BakeAlphaAnimated)
    bpy.utils.unregister_class(AddCrossHatch)
    bpy.utils.unregister_class(AddRGBCurves)
    bpy.utils.unregister_class(BakeNormals)
    bpy.utils.unregister_class(MaskSpeculars)
    bpy.utils.unregister_class(AddTransparentWorldStrokes)
    # bpy.utils.unregister_class(BakeBounced)
    bpy.utils.unregister_class(AddHairCurves)
    bpy.utils.unregister_class(ExternalPaint)
    bpy.utils.unregister_class(AddEasyDT)
    bpy.utils.unregister_class(NormalsPaint)
    bpy.utils.unregister_class(OpenURLOperator)
    bpy.utils.unregister_class(BakeCurvature)
    bpy.utils.unregister_class(AddRedLight)


if __name__ == '__main__' :
    register()